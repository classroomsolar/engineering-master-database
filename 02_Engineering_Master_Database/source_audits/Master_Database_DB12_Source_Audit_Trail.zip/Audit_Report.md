# Master database source review — 25 October 2026

The existing master database has been updated. This is a source and identity audit, with unresolved records explicitly retained as unqualified. It is not a certification that the entire catalogue is error-free or that no semantic duplicate exists anywhere.

| Result | Saved DB12 |
| --- | ---: |
| Manufacturer-publication-scoped PV records updated | 16 |
| Former primary records preserved in history | 33 |
| Primary PV records | 39,400 |
| Primary IBR records | 5,603 |
| Raw CEC listings preserved | 55,018 |
| Native CEC fields preserved | 410 |
| Worksheets / native tables | 117 / 116 |
| Original formulas preserved | 53,117 |
| Record IDs duplicated in the 41 scanned identity tables | 0 |
| Identical typed-specification groups in those tables | 0 |
| New equipment models added during this authentication pass | 0 |

The workbook contains 411,282 nonempty data, reference and audit rows. That total includes source memberships, history and calculation-reference records; it is not a count of unique physical equipment.

## Manufacturer corrections and scope

Fifteen PV records now follow exact, identified manufacturer publications. One additional Midsummer record retains the manufacturer's quoted nominal values under its explicit tolerance footnote. Changes include corrected voltage/current fields, dimension and mass units, temperature coefficients, revision-specific voltage limits, and removal of unsupported values. Raw CEC claims remain intact alongside the manufacturer-scoped primary data.

| Source ID | Publisher | PV records | Publication | Hosting | Source |
| --- | --- | ---: | --- | --- | --- |
| DB12-SRC-008 | Bosch Solar Energy | 3 | Bosch Solar Energy Corp. version1.0 | distributor manufacturer PDF mirror | [Original publication](https://ressupply.com/documents/bosch/c-Si_M_60_NA30119_Manaul.pdf) |
| DB12-SRC-001 | BYD | 1 | MIK-36-SERIES-5BB sheet20200611 in official BYD combined brochure | manufacturer | [Original publication](https://sg.byd.com/wp-content/uploads/2021/07/Combined-Solar-Panel-Brochures.pdf) |
| DB12-SRC-005 | Canadian Solar | 1 | May2020 v5.59_F26_J1_NA | manufacturer | [Original publication](https://www.canadiansolar.com/na/wp-content/uploads/sites/3/2020/09/CanadianSolar-BiHiKu_CS3W-MB-AG_v5.59_F26_J1_NA.pdf) |
| DB12-SRC-011 | Centrosolar America | 1 | Copyright2017 B-Series Monocrystalline BM60 275BB | industry directory manufacturer PDF mirror | [Original publication](https://cdn.enfsolar.com/Product/pdf/Crystalline/59a67244374a6.pdf) |
| DB12-SRC-018 | LG | 1 | LG455N2W-E6 110221,US publication2021 | manufacturer | [Original publication](https://www.lg.com/us/business/download/resources/CT00002151/1104_LG_NeON_H_N2W_E6_455%5B20211123_073543%5D.pdf) |
| DB12-SRC-014 | GCL System Integration | 8 | GCL-EN-M3/72DH-N-2019-V3.0 | industry directory manufacturer PDF mirror | [Original publication](https://cdn.enfsolar.com/Product/pdf/Crystalline/5ec63f0311157.pdf) |
| DB12-SRC-020 | Midsummer AB | 1 | Version6,2023-02-14 | manufacturer | [Original publication](https://midsummer.se/wp-content/uploads/2023/03/Produktblad_MidsummerSLIM_230309eng.pdf) |

Specific corrections include Canadian Solar CS3W-440MB-AG maximum-power voltage 40.7 V; three Bosch NA30119 current tuples; BYD390MIK-36 nominal power 390 W and its matching electrical tuple; Centrosolar BM60 275BB; LG455N2W-E6 under the US 2021 publication; and eight GCL Nova 2019 V3.0 power bins. GCL front-NOCT powers previously associated with PTC were cleared from the primary PTC field. Canadian Solar and LG NMOT values are not relabelled as NOCT.

For Midsummer SLIM 2 × 10, the publication quotes 65 W, 10.2 V and 6.7 A with an explicit ±10% tolerance for the footnoted nominal values. Their product is 68.34 W, 5.13846% above 65 W. The quoted data are retained with a documented nominal-data exception. No measured IV-curve validation is implied.

The seven correction publication families are documented alongside 20 downloaded publication/candidate documents in SOURCE_REGISTER and the evidence index. A candidate publication with a different suffix, revision or construction is not automatically substituted for a suspect record. Distributor or directory copies are labelled as such; manufacturer hosting is not claimed for those mirrors.

## Duplicate and scenario reconciliation

EQUIPMENT_RECORD_HISTORY preserves 33 former primary records and their canonical targets:

- Six SMA reference aliases that duplicated existing model/configuration records.
- One conflicting LG source claim for the same LG455N2W-E6 model.
- Eight alternate GCL specification claims, while canonical entries are explicitly scoped to the selected publication revision.
- Eighteen SunPower rear-irradiance rating scenarios, which are operating-condition claims rather than additional manufactured models.

Original primary records, original row locations, paired PV unit-review records and record fingerprints are retained in DB12_Original_Records.json. Operational CEC links resolve to live primary IDs. Links to manufacturer-updated models explicitly distinguish the primary publication from raw CEC claims; rating/revision/configuration equality is not silently assumed. Historical audit text retains its original locations and context.

The 41-table duplicate scan compares typed specifications after case/whitespace normalization of text, while excluding record IDs and provenance. It preserves physical fields such as source voltage/type and fuse/model identifiers. Repeated names alone do not establish a duplicate: voltage, power bin, phase, curve, revision or equipment role can differ. The scan does not establish that all cross-vendor aliases or underspecified legacy configurations represent different physical products.

## Outstanding source exceptions

All 95 prior electrical flags have an explicit current disposition:

| Outcome | Records |
| --- | ---: |
| Corrected from an exact manufacturer publication | 6 |
| Qualified by the published nominal-data tolerance | 1 |
| Moved to historical rating scenarios | 12 |
| No safe replacement authenticated; electrical values remain withheld | 76 |

Fifteen surviving repeated-name source claims across five groups remain CONFIGURATION_IDENTITY_REVIEW_REQUIRED. They are not certified as distinct physical products or merged on name alone. The 76 electrical records and 15 configuration claims are separate review categories.

No nearby model, arithmetic reconstruction or supplier listing was used to invent a missing specification. RECORD_RECONCILIATION records the scope and result for each of these 110 review decisions.

## CEC source reconciliation

The 13 original downloaded CEC files correspond to 12 datasets and 14 native listing tables. Active, archived, historical and legacy source memberships remain distinguishable. The simplified inverter archive duplicates a view of the full archive and was imported once. Legitimate solar/battery inverter memberships and assembly/component roles remain source relationships, rather than being counted as separate installed units automatically.

All 14 raw listing worksheet parts, CEC_FIELD_MAP, CEC_SOURCE_NOTES and CEC_IMPORT_INDEX are byte-identical to the validated DB11 parent. The 13 original CEC file hashes were checked again. The two PMRS Latura memberships with a blank website remain present. Every one of the 55,018 registry IDs has one operational listing link.

**Your own downloaded CEC files have not yet been supplied in this chat.** CEC_FILE_RECONCILIATION contains 13 AWAITING_USER_CEC_EXPORT records with no fabricated user filename or hash. Their actual contents must be compared after upload; version differences cannot be assumed to be import errors.

## Verification of the saved file

The final independent verification executed 8,601,096 checks with zero failed executions. It checked planned typed values, original cell XML, worksheet features, original style entries, native table identities and ranges, both indexes, all PV/unit pointers, history fingerprints, operational CEC links, source-file hashes, electrical gates, error-cell types and the 41-table duplicate scan.

- 1,935,868 unplanned cells in edited worksheets retained their XML, with cell addresses shifted only for the documented row compaction.
- Original formula-bearing worksheet parts and caches are byte-identical: 53,117 formulas, zero stored Excel error cells.
- All unrelated original package members remain unchanged. Wrapping is explicitly enabled in 170 updated PV source-note/location and unit-review status cells; row heights in edited rows accommodate the revised text.
- Saved worksheets were rendered and visually inspected using style-preserving sample projections, including the source-history, reconciliation and pending-file tables.

These checks establish the stated file/source reconciliation and engineering-data gates. They do not independently certify manufacturer-submitted ratings, reproduce every research paper, prove every legacy record authentic, or validate an external calculator/site's live consumption of the database. Microsoft Excel application recalculation was not available. No VBA or new calculator was added.

## Relevant plugin work and earlier requests

Adobe Acrobat OCR processed the scanned GCL publication. Its available extraction returned source-page figures, so the numerical table was visually checked against the original scan. It is not described as a machine-extracted numeric table. Firecrawl and TinyFish had no usable credit during this review; original-source retrieval continued through the available web/direct-document routes. Earlier vidIQ credit limitations remain recorded. Formula Genius and Coursera stayed excluded as requested.

All native tables remain indexed and their full ranges remain addressable. That establishes database access, not a new claim that every field is consumed by a separate calculator. Existing paper-audit, calculator-key and other equipment reviews are preserved; no new full-catalogue or full-paper certification is claimed.

## File identity and evidence

Master: Engineering_Master_Database_Audited.xlsx  
SHA-256: `ee2903c751861b6f07d537d651fb7e60a22ee8496ac3d5f1748b5ab7a7202cb3`  
Validated parent DB11 SHA-256: `f0214a0823c27994dd9c7090b19f90999eb310fad531a7fb1751409e3d314218`

The companion evidence ZIP contains the 13 original CEC exports, factual source identities, publication-scoped field decisions, original moved records, changes, reconciliation decisions, final validation results and the audit/authoring scripts. Original CEC exports are retained as source files; any source workbook macros are not required by the master. The bundle does not redistribute full manufacturer PDFs or raw search-page bodies. Public source URLs and document hashes identify those publications.
