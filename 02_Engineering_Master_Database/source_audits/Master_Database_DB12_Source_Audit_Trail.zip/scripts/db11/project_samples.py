"""Create small read-only render projections, retaining original source styles."""
from pathlib import Path
import sys,json,zipfile,xml.etree.ElementTree as E,posixpath,re
P=Path(__file__).parent
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';N={'s':NS};RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
E.register_namespace('',NS)
def serial(root):
 E.register_namespace('',root.tag.split('}')[0][1:])
 return E.tostring(root,encoding='utf-8',xml_declaration=True)
src=Path(sys.argv[1]);dest=Path(sys.argv[2]);mode=sys.argv[3] if len(sys.argv)>3 else 'before'
names=['PV_MODULES','IBR','PV_UNIT_REVIEW','CABLES','TERMINATIONS','SOURCE_REGISTER']
if len(sys.argv)>4:names=sys.argv[4].split(',')
target_rows=json.loads(Path(sys.argv[5]).read_text()) if len(sys.argv)>5 else None
snap=json.loads((P/'snapshot.json').read_text());old={d['sheet']:d['last_row'] for d in snap['summary']}
with zipfile.ZipFile(src) as z:
 wr=E.fromstring(z.read('xl/workbook.xml'));rel=E.fromstring(z.read('xl/_rels/workbook.xml.rels'));rm={r.get('Id'):r.get('Target') for r in rel};keep={};selected={}
 for sh in list(wr.find('s:sheets',N)):
  name=sh.get('name')
  if name not in names:wr.find('s:sheets',N).remove(sh);continue
  t=rm[sh.get(RID)];path=t.lstrip('/') if t.startswith('/') else posixpath.normpath('xl/'+t);keep[sh.get(RID)]=path;selected[name]=path
 for node in list(wr):
  if node.tag.split('}')[-1] in ['definedNames','externalReferences']:wr.remove(node)
 for r in list(rel):
  typ=r.get('Type','').split('/')[-1]
  if typ=='worksheet' and r.get('Id') not in keep:rel.remove(r)
  elif typ in ['calcChain','externalLink']:rel.remove(r)
 out={'xl/workbook.xml':serial(wr),'xl/_rels/workbook.xml.rels':serial(rel)}
 for name,path in selected.items():
  rt=E.fromstring(z.read(path));sd=rt.find('s:sheetData',N);rows=list(sd)
  data=[r for r in rows if int(r.get('r'))>old.get(name,1)] if mode=='after' else rows[1:6]
  if target_rows is not None:data=[r for r in rows if int(r.get('r')) in target_rows.get(name,[])]
  chosen=[rows[0]]+data[:5]
  for r in rows:sd.remove(r)
  for i,r in enumerate(chosen,1):
   r.set('r',str(i))
   for c in r:c.set('r',re.sub(r'\d+$',str(i),c.get('r')))
   sd.append(r)
  for node in list(rt):
   if node.tag.split('}')[-1] in ['tableParts','drawing','legacyDrawing','hyperlinks','extLst','autoFilter','conditionalFormatting','dataValidations','mergeCells']:rt.remove(node)
  dim=rt.find('s:dimension',N)
  if dim is not None:dim.set('ref','A1:'+re.sub(r'\d+$',str(len(chosen)),max((c.get('r') for c in rows[0]),key=lambda x:(len(re.sub(r'\d','',x)),x))))
  for p in rt.findall('s:sheetViews/s:sheetView/s:pane',N):p.set('topLeftCell','B2')
  out[path]=serial(rt)
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as o:
  for it in z.infolist():
   n=it.filename
   if n.startswith('xl/worksheets/') and n not in selected.values():continue
   if n.startswith(('xl/tables/','xl/calcChain','xl/externalLinks/')):continue
   b=out.get(n,z.read(n))
   if n=='[Content_Types].xml':
    ct=E.fromstring(b)
    for el in list(ct):
     pn=el.get('PartName','').lstrip('/')
     if pn.startswith('xl/worksheets/') and pn not in selected.values() or pn.startswith(('xl/tables/','xl/calcChain','xl/externalLinks/')):ct.remove(el)
    b=serial(ct)
   o.writestr(it,b)
print(json.dumps({'projection':str(dest),'sheets':list(selected),'mode':mode}))
