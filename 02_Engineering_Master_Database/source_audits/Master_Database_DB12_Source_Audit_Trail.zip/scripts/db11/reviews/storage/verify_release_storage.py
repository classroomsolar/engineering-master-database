"""Read-only final DB11 CEC joins and engineering-boundary verification.

Never imports authoring/assembly code. Refuses to inspect a final workbook
unless assembly_result.json names that file and its SHA256 matches the bytes.
Original CEC workbooks are read as inert OOXML ZIPs, including the XLSM source.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
from itertools import zip_longest
from pathlib import Path
import hashlib
import json
import math
import posixpath
import re
import sys
import traceback
import zipfile

from lxml import etree as E


DB = Path(__file__).resolve().parents[2]
OUTPUT = DB / 'outputs/db11/Engineering_Master_Database_Audited.xlsx'
ASSEMBLY = DB / 'assembly_result.json'
REPORT = DB / 'reviews/review_release_storage.json'
OWN = Path(__file__).parent
NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
N = {'s': NS}
OFFICE_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
RID = '{' + OFFICE_REL + '}id'
PREFIX = ['Registry Record ID', 'CEC List Status', 'Source Dataset', 'Source Worksheet', 'Source Excel Row']

# Independent source row definitions. A nonempty manufacturer and literal
# model constitute an equipment listing; PMRS stops before its utility heading.
RAW_LAYOUT = {
    'CEC_PV_ACTIVE': (18, 'A', 'B', 'ACTIVE'),
    'CEC_SOLAR_INVERTERS': (17, 'A', 'B', 'ACTIVE'),
    'CEC_BATTERY_INVERTERS': (17, 'A', 'B', 'ACTIVE'),
    'CEC_BATTERIES': (13, 'A', 'C', 'ACTIVE'),
    'CEC_ENERGY_STORAGE': (18, 'A', 'C', 'ACTIVE'),
    'CEC_METERS': (9, 'A', 'B', 'ACTIVE'),
    'CEC_LEGACY_PCS': (17, 'A', 'B', 'LEGACY'),
    'CEC_V2G': (6, 'A', 'B', 'ACTIVE'),
    'CEC_BATTERY_ARCHIVE': (6, 'A', 'B', 'ARCHIVED'),
    'CEC_INVERTER_ARCHIVE': (15, 'A', 'B', 'ARCHIVED'),
    'CEC_PV_ARCHIVE': (7, 'A', 'B', 'ARCHIVED'),
    'CEC_POWER_CONTROL': (17, 'A', 'B', 'ACTIVE'),
    'CEC_PMRS': (5, 'A', None, 'ACTIVE'),
    'CEC_PMRS_HISTORICAL': (4, 'A', None, 'HISTORICAL'),
}
EXPECTED_NATIVE_COUNTS = {
    'CEC_PV_ACTIVE': 22424, 'CEC_SOLAR_INVERTERS': 2209,
    'CEC_BATTERY_INVERTERS': 1170, 'CEC_BATTERIES': 999,
    'CEC_ENERGY_STORAGE': 6787, 'CEC_METERS': 802,
    'CEC_LEGACY_PCS': 1715, 'CEC_V2G': 22,
    'CEC_BATTERY_ARCHIVE': 16, 'CEC_INVERTER_ARCHIVE': 3172,
    'CEC_PV_ARCHIVE': 15322, 'CEC_POWER_CONTROL': 103,
    'CEC_PMRS': 131, 'CEC_PMRS_HISTORICAL': 146,
}
EXPECTED_GROUP_COUNTS = {
    'CEC_BAT_ACTIVE': 999, 'CEC_BAT_ARCHIVE': 16, 'CEC_ESS': 6786,
    'CEC_METERS': 802, 'CEC_PCS': 103, 'CEC_PCS_LEGACY': 1683,
    'CEC_V2G': 22, 'CEC_PMRS': 154,
}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def ws(v):
    return ' '.join(str(v or '').split())


def registry_id(dataset, sheet, row):
    return 'DB11-CEC-' + dataset + '-' + re.sub('[^A-Za-z0-9]', '', sheet) + '-' + str(row)


def source_key(v):
    a = v.split(':', 3)
    return a[1], a[2], int(a[3])


def col(n):
    s = ''
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def eq(a, b):
    # Excel has one empty-cell state: Artifact legitimately exports an empty
    # text input as a missing/blank cell. Only None and the zero-length string
    # are equivalent; 0, False, whitespace and nonempty source text are not.
    if (a is None and b == '') or (b is None and a == ''):
        return True
    if isinstance(a, bool) or isinstance(b, bool):
        return type(a) is type(b) and a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12)
    return a == b


def json_safe(value):
    if isinstance(value, set):
        return sorted((json_safe(x) for x in value), key=lambda x: str(x))
    if isinstance(value, dict):
        return {k: json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(x) for x in value]
    return value


class Checks:
    def __init__(self):
        self.counts = Counter()
        self.failures = Counter()
        self.examples = defaultdict(list)

    def test(self, condition, label, detail=None):
        self.counts[label] += 1
        if not condition:
            self.failures[label] += 1
            if len(self.examples[label]) < 12:
                self.examples[label].append(json_safe(detail))
            if self.failures[label] == 1:
                print(json.dumps({'first_failure': label, 'detail': json_safe(detail)}, ensure_ascii=False), flush=True)
        return bool(condition)

    def output(self):
        return {
            'check_executions': sum(self.counts.values()),
            'check_categories': len(self.counts),
            'failed_executions': sum(self.failures.values()),
            'failed_categories': len(self.failures),
            'checks': dict(self.counts),
            'failures': dict(self.failures),
            'failure_examples': dict(self.examples),
        }


class Book:
    """Streaming, read-only OOXML decoder independent of package_helpers.py."""
    def __init__(self, path):
        self.path = Path(path)
        self.z = zipfile.ZipFile(path)
        names = set(self.z.namelist())
        self.shared = []
        if 'xl/sharedStrings.xml' in names:
            with self.z.open('xl/sharedStrings.xml') as f:
                for _, node in E.iterparse(f, events=['end'], tag='{' + NS + '}si'):
                    self.shared.append(''.join(node.xpath('.//s:t/text()', namespaces=N)))
                    node.clear()
                    while node.getprevious() is not None:
                        del node.getparent()[0]
        rels = {r.get('Id'): r.get('Target') for r in E.fromstring(self.z.read('xl/_rels/workbook.xml.rels'))}
        wb = E.fromstring(self.z.read('xl/workbook.xml'))
        self.sheets = {}
        for s in wb.findall('s:sheets/s:sheet', N):
            target = rels[s.get(RID)]
            self.sheets[s.get('name')] = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)

    def value(self, cell):
        typ = cell.get('t')
        if typ == 'inlineStr':
            return ''.join(cell.xpath('./s:is//s:t/text()', namespaces=N))
        v = cell.find('s:v', N)
        if v is None or v.text is None:
            return None
        if typ == 's':
            return self.shared[int(v.text)]
        if typ == 'b':
            return v.text == '1'
        if typ in ('e', 'str', 'd'):
            return v.text
        try:
            n = float(v.text)
            return int(n) if n.is_integer() else n
        except ValueError:
            return v.text

    def rows(self, name):
        with self.z.open(self.sheets[name]) as f:
            for _, row in E.iterparse(f, events=['end'], tag='{' + NS + '}row'):
                cells = {}
                formulas = []
                for c in row:
                    address = c.get('r')
                    cc = re.match('[A-Z]+', address)[0]
                    value = self.value(c)
                    if value is not None:
                        cells[cc] = value
                    if c.find('s:f', N) is not None:
                        formulas.append(address)
                yield int(row.get('r')), cells, formulas
                row.clear()
                while row.getprevious() is not None:
                    del row.getparent()[0]

    def table(self, name, selected=None):
        header = None
        for nr, cells, formulas in self.rows(name):
            if nr == 1:
                header = {c: v for c, v in cells.items()}
                continue
            if not cells:
                continue
            record = {h: cells.get(c) for c, h in header.items() if selected is None or h in selected}
            yield nr, record, formulas

    def close(self):
        self.z.close()


def native_records(book, sheet, layout):
    first, manufacturer_col, model_col, _ = layout
    for nr, cells, formulas in book.rows(sheet):
        if nr < first:
            continue
        if model_col is None:
            text = ws(cells.get(manufacturer_col))
            if text == 'Utility Providers':
                break
            if not text or text in ('Company', 'None at present time.'):
                continue
        elif not ws(cells.get(manufacturer_col)) or not ws(cells.get(model_col)):
            continue
        yield nr, cells, formulas


def verify():
    # Mandatory precondition: no final-package inspection before these agree.
    if not ASSEMBLY.exists() or not OUTPUT.exists():
        raise RuntimeError('Final verification not started: output workbook and assembly_result.json are both required.')
    assembly_bytes = ASSEMBLY.read_bytes()
    assembly = json.loads(assembly_bytes)
    if Path(assembly['output']).resolve() != OUTPUT.resolve():
        raise RuntimeError('Final verification not started: assembly_result.json names a different output file.')
    output_hash = digest(OUTPUT)
    if assembly['sha256'] != output_hash:
        raise RuntimeError('Final verification not started: output SHA256 does not agree with assembly_result.json.')

    checks = Checks()
    test = checks.test
    started = datetime.now(timezone.utc).isoformat()
    frozen_storage = json.loads((OWN / 'rootreview_storage.json').read_text())
    for artifact in frozen_storage['artifacts']:
        test(digest(Path(artifact['file'])) == artifact['sha256'], 'frozen_storage_review_artifact_hash', Path(artifact['file']).name)
    definitions = json.loads((DB / 'reference_tables.json').read_text())
    source_defs = {x['name']: x for x in json.loads((DB / 'source_reference_tables.json').read_text())}
    inventory = json.loads((DB / 'cec_sources/source_inventory.json').read_text())
    inventory_byid = {x['id']: x for x in inventory}
    core = json.loads((OWN / 'core_ibr_proposal.json').read_text())
    dedicated = json.loads((OWN / 'dedicated_canonical_proposal.json').read_text())
    baseline = {r['Record ID']: r for r in json.loads((OWN / 'baseline_domains.json').read_text())['IBR']}
    snapshot = json.loads((DB / 'snapshot.json').read_text())
    ibr_headers = list(next(s for s in snapshot['summary'] if s['sheet'] == 'IBR')['headers'].values())
    master = Book(OUTPUT)
    parent = Book(DB / 'inputs/Engineering_Master_Database_Audited.xlsx')
    metrics = {}
    payload_headers = {}

    # Full equality against frozen, hash-qualified authoring inputs: all 21 new
    # reference sheets, every row and every value, including dates/conditions.
    test(len(definitions) == 21, 'reference_table_count', len(definitions))
    test({r['name'] for r in assembly['new_tables']} == {d['name'] for d in definitions}, 'assembly_table_identities')
    assembly_tables = {r['name']: r for r in assembly['new_tables']}
    for d in definitions:
        pth = Path(d['path'])
        test(digest(pth) == d['sha256'], 'frozen_payload_hash', d['name'])
        payload = json.loads(pth.read_text())
        hs = payload['headers']
        payload_headers[d['name']] = hs
        if not test(d['name'] in master.sheets, 'reference_sheet_exists', d['name']):
            continue
        declared = assembly_tables.get(d['name'])
        if declared:
            table_node = E.fromstring(master.z.read(declared['table_path']))
            expected_range = 'A1:' + col(len(hs)) + str(d['rows'] + 1)
            table_headers = [x.get('name') for x in table_node.findall('s:tableColumns/s:tableColumn', N)]
            auto_filter = table_node.find('s:autoFilter', N)
            test(table_node.get('ref') == expected_range and table_headers == hs and auto_filter is not None and auto_filter.get('ref') == expected_range, 'reference_native_table_full_range_headers_filter', [d['name'], table_node.get('ref'), expected_range])
            test(declared['path'] == master.sheets[d['name']] and table_node.get('name') == 'EDB_' + d['name'], 'reference_native_table_identity', d['name'])
        actual = master.rows(d['name'])
        nr, cells, fs = next(actual)
        test(nr == 1 and [cells.get(col(i + 1)) for i in range(len(hs))] == hs, 'reference_header_exact', d['name'])
        count = 0
        for item, expected in zip_longest(actual, payload['rows']):
            if not test(item is not None and expected is not None, 'reference_row_count_exact', [d['name'], count + 2]):
                continue
            nr, cells, fs = item
            count += 1
            test(nr == count + 1, 'reference_row_sequence', [d['name'], nr])
            test(not fs, 'reference_values_are_literals', [d['name'], fs])
            for i, expected_value in enumerate(expected, 1):
                test(eq(cells.get(col(i)), expected_value), 'reference_value_exact', [d['name'], nr, hs[i - 1], cells.get(col(i)), expected_value])
        test(count == d['rows'], 'reference_definition_row_count', [d['name'], count, d['rows']])
        metrics[d['name']] = count
        del payload
    test(sum(metrics.values()) == 121429 and metrics.get('CEC_SOURCE_NOTES') == 339, 'corrected_reference_rows_and_source_notes_count', {'reference_rows': sum(metrics.values()), 'source_notes': metrics.get('CEC_SOURCE_NOTES')})
    test(sum(metrics.get(n, 0) for n in source_defs) == 55779, 'source_tables_and_metadata_total_rows_55779')

    field_rows = [r for _, r, _ in master.table('CEC_FIELD_MAP')]
    field_maps = defaultdict(list)
    for f in field_rows:
        field_maps[f['Master CEC Table']].append(f)
    test(len(field_rows) == 410, 'native_field_map_count', len(field_rows))
    raw_meta = {}
    raw_source_key_to_id = {}
    source_ibr_cells = {}
    source_ess_cells = {}
    native_counts = Counter()
    source_books = {}

    # Independent comparison to original CEC OOXML, not only the payloads.
    # Source-book rows are filtered by explicit native manufacturer/model
    # columns and start rows, so missing first application rows cannot pass.
    for table, layout in RAW_LAYOUT.items():
        d = source_defs[table]
        ds, sheet = d['source_dataset'], d['source_worksheet']
        src = inventory_byid[ds]
        if ds not in source_books:
            test(digest(Path(src['file'])) == src['sha256'], 'original_source_hash', ds)
            source_books[ds] = Book(src['file'])
        source_book = source_books[ds]
        test(sheet in source_book.sheets, 'native_source_worksheet_exists', [ds, sheet])
        expected = native_records(source_book, sheet, layout)
        actual = master.table(table)
        fields = field_maps[table]
        test(payload_headers[table][:5] == PREFIX, 'native_provenance_headers', table)
        test(len(fields) == len(payload_headers[table]) - 5, 'every_native_field_mapped', table)
        for f in fields:
            test(f['Source Dataset'] == ds and f['Source Worksheet'] == sheet and payload_headers[table][int_col(f['Master Column']) - 1] == f['CEC Field Name'], 'native_field_map_exact', [table, f['Master Column']])
        count = 0
        for a, s in zip_longest(actual, expected):
            if not test(a is not None and s is not None, 'source_export_full_record_coverage', [table, count + 1]):
                continue
            _, row, _ = a
            sn, cells, _ = s
            count += 1
            native_counts[table] += 1
            reg = registry_id(ds, sheet, sn)
            expected_prefix = [reg, layout[3], ds, sheet, sn]
            test([row.get(k) for k in PREFIX] == expected_prefix, 'source_native_row_identity_status', [table, sn, [row.get(k) for k in PREFIX]])
            for f in fields:
                h, c = f['CEC Field Name'], f['Source Column']
                test(eq(row.get(h), cells.get(c)), 'source_native_value_preserved', [table, sn, c, h, row.get(h), cells.get(c)])
            test(reg not in raw_meta, 'unique_native_registry_id', reg)
            meta = {'table': table, 'status': layout[3], 'dataset': ds, 'worksheet': sheet, 'excel_row': sn}
            raw_meta[reg] = meta
            raw_source_key_to_id[(ds, sheet, sn)] = reg
            if ds in ('InvertersList', 'ArchivedInverterFull'):
                source_ibr_cells[(ds, sheet, sn)] = {c: cells.get(c) for c in ['A', 'B', 'D', 'E', 'F', 'L', 'M', 'N', 'O', 'AF', 'AH']}
            if ds == 'EnergyStorage':
                source_ess_cells[(ds, sheet, sn)] = {c: cells.get(c) for c in ['A', 'C', 'Q', 'R', 'S']}
        test(count == EXPECTED_NATIVE_COUNTS[table], 'native_expected_record_count', [table, count, EXPECTED_NATIVE_COUNTS[table]])
    test(dict(native_counts) == EXPECTED_NATIVE_COUNTS and len(raw_meta) == 55018, 'all_55018_native_listing_ids', dict(native_counts))

    # Exact source test-vs-design definitions must survive inside portable notes.
    data_key = {}
    for _, r, _ in master.table('CEC_SOURCE_NOTES'):
        if r['Source Dataset'] == 'InvertersList' and r['Source Worksheet'] == 'Data_Key' and r['Note Type'] == 'native_reference_row':
            note = json.loads(r['Original Source Content'])
            values = {c: v['value'] for c, v in note['cells'].items()}
            if values.get('B'):
                data_key[str(values['B'])] = values.get('D')
    test('not the inverter' in str(data_key.get('L')) and 'nominal AC output power' in str(data_key.get('L')), 'measured_kw_is_not_nameplate_power_definition_retained')
    test('efficiency testing' in str(data_key.get('AF-AH')), 'dc_test_points_are_not_design_limits_definition_retained')
    test(data_key.get('AD') == 'Field not used.', 'unused_40degc_field_boundary_retained')

    # Read stable primary IDs independently from the package, not the manifest.
    ibr = {}
    for nr, row, _ in master.table('IBR'):
        rid = row.get('Record ID')
        test(rid and rid not in ibr, 'ibr_primary_id_unique', [nr, rid])
        ibr[rid] = row
    primary_pv_ids = {r['Record ID'] for _, r, _ in master.table('PV_MODULES', {'Record ID'})}
    test(len(ibr) == 641 + 4968 == 5609, 'ibr_final_primary_count', len(ibr))
    first = next(master.rows('IBR'))
    test([first[1].get(col(i + 1)) for i in range(36)] == ibr_headers, 'ibr_36_existing_headers_preserved')
    new_ids = {r['Record ID'] for r in core['records']}
    test(len(new_ids) == 4968 and {rid for rid in ibr if str(rid).startswith('DB11-IBR-')} == new_ids, 'ibr_new_4968_configurations')
    for r in core['records']:
        actual = ibr.get(r['Record ID'], {})
        for h, v in r.items():
            test(eq(actual.get(h), v), 'ibr_new_frozen_record_exact', [r['Record ID'], h])
    patch_byid = {u['record_id']: u for u in core['updates']}
    test(len(patch_byid) == 352, 'ibr_frozen_update_count', len(patch_byid))
    for rid, u in patch_byid.items():
        for h, v in u['set'].items():
            test(eq(ibr.get(rid, {}).get(h), v), 'ibr_frozen_update_applied', [rid, h, ibr.get(rid, {}).get(h), v])
    for rid, old in baseline.items():
        change = patch_byid.get(rid, {}).get('set', {})
        for h in ibr_headers:
            test(eq(ibr.get(rid, {}).get(h), change.get(h, old.get(h))), 'ibr_existing_all_unwhitelisted_fields_preserved', [rid, h])

    forbidden = ['Rated MVA', 'Max RMS Fault pu', 'RMS Fault kA', 'Peak Fault kA', 'Fault Duration s', 'Positive-Seq Behavior', 'Negative-Seq Behavior', 'Zero-Seq Behavior', 'Reactive Current Priority?', 'LV/MV Transformer ID', 'Rated Current kA', "Initial Sym RMS Ik'' kA", 'Steady RMS Ik kA', 'Imax kA', 'Fault Multiplier x', 'Frequency Hz', 'Maximum DC Open-Circuit Voltage (V)', 'Minimum PV Voltage (V)']
    current_archive = Counter()
    for rid in new_ids:
        row = ibr[rid]
        test(all(row.get(h) is None for h in forbidden), 'ibr_no_inferred_fault_design_or_apparent_rating', rid)
        skey = source_key(row['Source Record ID'])
        cells = source_ibr_cells.get(skey, {})
        current = skey[0] == 'InvertersList'
        pc, vc, ec = ('L', 'M', 'N') if current else ('D', 'E', 'F')
        test(eq(row['CEC Rated Power (W)'], cells.get(pc) * 1000 if isinstance(cells.get(pc), (int, float)) else None), 'ibr_measured_output_kw_to_w_only', [rid, skey])
        if row.get('Terminal kV') is not None:
            test(eq(row['Terminal kV'], cells.get(vc) / 1000), 'ibr_nominal_vac_to_kv_only', [rid, skey])
        test(eq(row['CEC Weighted Efficiency (%)'], cells.get(ec)), 'ibr_efficiency_percent_scale_preserved', [rid, skey])
        test('measured AC power at unity power factor' in row['Notes'] and 'not the manufacturer nominal power rating' in row['Notes'] and 'efficiency-test DC voltage points' in row['Notes'], 'ibr_test_power_and_dc_boundary_labels', rid)
        test(('CURRENT CEC' in row['Record Status']) == current and ('ARCHIVED CEC' in row['Record Status']) != current, 'ibr_current_archived_state_exact', rid)
        current_archive['current' if current else 'archived_only'] += 1
    test(dict(current_archive) == {'current': 2099, 'archived_only': 2869}, 'ibr_new_status_counts', dict(current_archive))
    clear_pairs = []
    for u in core['updates']:
        for h in ('Maximum DC Open-Circuit Voltage (V)', 'Minimum PV Voltage (V)'):
            if h in u['set'] and u['set'][h] is None and u['before'].get(h) is not None:
                clear_pairs.append((u['record_id'], h))
                test(ibr[u['record_id']].get(h) is None and baseline[u['record_id']].get('Source Type') == 'USER DATABASE / CEC REFERENCE', 'confirmed_dc_clear_applied_only_to_legacy_cec', [u['record_id'], h])
    test(len(clear_pairs) == 34 and len({rid for rid, _ in clear_pairs}) == 26, 'legacy_dc_test_limit_clears_34_fields_26_rows', [len(clear_pairs), len({rid for rid, _ in clear_pairs})])
    audit = json.loads((OWN / 'legacy_cec_test_voltage_audit.json').read_text())
    confirmations = {(a['record_id'], c['field']): c for a in audit['audit'] for c in a['field_checks'] if c.get('equals_exact_identity_cec_test_voltage')}
    for pair in clear_pairs:
        c = confirmations.get(pair, {})
        test(bool(c), 'dc_clear_exact_source_confirmation_present', pair)
        for reference in c.get('matching_source_cells', []):
            m = re.fullmatch(r'(.*?) / (.*?)!([A-Z]+)(\d+)', reference)
            test(m is not None, 'dc_clear_qualified_source_cell', reference)
            if m:
                ds, sh, cc, nr = m.groups()
                test(eq(c['before'], source_ibr_cells.get((ds, sh, int(nr)), {}).get(cc)), 'dc_clear_old_value_equals_native_efficiency_test_point', [pair, reference])

    groups = {r['Record ID']: r for _, r, _ in master.table('CEC_MODEL_GROUPS')}
    test(len(groups) == 10565 and Counter(r['CEC Category'] for r in groups.values()) == EXPECTED_GROUP_COUNTS, 'dedicated_model_group_counts', dict(Counter(r['CEC Category'] for r in groups.values())))
    join_rows = [r for _, r, _ in master.table('CEC_LISTING_LINKS')]
    joins = {r['Registry Record ID']: r for r in join_rows}
    test(len(join_rows) == len(joins) == 55018 and set(joins) == set(raw_meta), 'all_listing_foreign_keys_complete_unique')
    allowed_primary = {'PV_MODULES': primary_pv_ids, 'IBR': set(ibr), 'CEC_MODEL_GROUPS': set(groups)}
    for reg, j in joins.items():
        primary = j.get('Primary Record ID')
        if primary is not None:
            test(primary in allowed_primary.get(j['Primary Table'], set()), 'listing_primary_record_fk_valid', [reg, j['Primary Table'], primary])
        else:
            test(bool(j.get('Disposition')) and bool(j.get('Candidate Existing IDs')), 'unmapped_listing_has_explicit_ambiguity', reg)
        if j['Primary Table'] in ('PV_MODULES', 'IBR'):
            candidates = split_ids(j.get('Candidate Existing IDs'))
            test(candidates <= allowed_primary[j['Primary Table']], 'listing_candidate_fk_valid', [reg, sorted(candidates)])

    mapped_ibr = set()
    ambiguous_ibr = set()
    current_identity_ids = defaultdict(set)
    for l in core['listing_links']:
        if l['dataset'] == 'ArchivedInverterSimplified':
            continue
        skey = l['dataset'], l['worksheet'], l['source_excel_row']
        reg = raw_source_key_to_id.get(skey)
        j = joins.get(reg, {})
        test(j.get('Primary Table') == 'IBR' and j.get('Primary Record ID') == l['canonical_ibr_id'] and j.get('Disposition') == l['core_match_status'], 'ibr_source_to_primary_join_exact', [reg, skey])
        test(split_ids(j.get('Candidate Existing IDs')) == set(l.get('existing_candidate_rids', [])), 'ibr_ambiguity_candidates_exact', reg)
        if l['canonical_ibr_id']:
            mapped_ibr.add(l['canonical_ibr_id'])
        else:
            ambiguous_ibr.add(l['source_identity_id'])
        if l['dataset'] == 'InvertersList':
            current_identity_ids[l['source_identity_id']].add(l['worksheet'])
    test(len(mapped_ibr) == 5314 and new_ids <= mapped_ibr and len(ambiguous_ibr) == 84, 'ibr_canonical_and_withheld_identity_counts', {'mapped': len(mapped_ibr), 'withheld': len(ambiguous_ibr)})
    test(len(current_identity_ids) == 2507 and sum(len(s) == 2 for s in current_identity_ids.values()) == 872, 'hybrid_memberships_not_duplicate_equipment', {'current_configuration_identities': len(current_identity_ids), 'hybrid_memberships': sum(len(s) == 2 for s in current_identity_ids.values())})
    test(not any(m['dataset'] == 'ArchivedInverterSimplified' for m in raw_meta.values()) and not any('SIMPLIF' in s.upper() for s in master.sheets if s.startswith('CEC_')), 'simplified_archive_duplicate_view_excluded_from_native_equipment_tables')
    test(sum(m['dataset'] == 'ArchivedInverterFull' for m in raw_meta.values()) == 3172, 'full_archive_imported_once', 3172)

    # Every dedicated group is a complete forward/reverse membership join.
    dc_byid = {g['canonical_id']: g for rr in dedicated['canonical_records'].values() for g in rr}
    test(set(dc_byid) == set(groups), 'dedicated_canonical_group_ids_exact')
    for gid, expected in dc_byid.items():
        g = groups.get(gid, {})
        native = {raw_source_key_to_id.get(source_key(s)) for s in expected['source_record_ids']}
        test(None not in native and split_ids(g.get('All Native Registry IDs')) == native, 'group_complete_reverse_registry_membership', gid)
        primary_reg = g.get('Primary Registry Record ID')
        test(primary_reg in native and raw_meta.get(primary_reg, {}).get('table') == g.get('Primary Registry Table'), 'group_primary_registry_fk_valid', gid)
        states = {raw_meta[x]['status'] for x in native if x in raw_meta}
        test(split_ids(g.get('CEC List States')) == states, 'group_active_archived_historical_legacy_states_exact', [gid, states, g.get('CEC List States')])
        for reg in native:
            j = joins.get(reg, {})
            test(j.get('Primary Table') == 'CEC_MODEL_GROUPS' and j.get('Primary Record ID') == gid and j.get('Disposition') == 'REGISTRY_GROUP_MEMBERSHIP', 'group_forward_registry_join_valid', [gid, reg])
    for l in dedicated['listing_links']:
        reg = raw_source_key_to_id.get((l['source_dataset'], l['source_worksheet'], l['source_excel_row']))
        test(joins.get(reg, {}).get('Primary Record ID') == l['canonical_id'], 'dedicated_frozen_canonical_membership_exact', [reg, l['canonical_id']])

    # Assembly/component-role identity is deliberately a relation, not another
    # physical equipment count or an inferred exact bill of materials.
    relations = [r for _, r, _ in master.table('CEC_ASSEMBLY_RELATIONS')]
    frozen_relations = {r['ess_canonical_id']: r for r in dedicated['assembly_component_relations']}
    test(len(relations) == len(frozen_relations) == 51, 'assembly_role_relation_count_51')
    test(len({r['ESS Record ID'] for r in relations}) == 51, 'assembly_relation_ess_identity_unique')
    for r in relations:
        gid = r['ESS Record ID']
        frozen = frozen_relations.get(gid, {})
        core_ids = split_ids(r.get('Inverter Role IDs'))
        test(gid in groups and groups[gid]['CEC Category'] == 'CEC_ESS' and core_ids <= set(ibr) and gid not in core_ids, 'assembly_component_role_fks_valid', [gid, sorted(core_ids)])
        test(core_ids == set(frozen.get('inverter_canonical_ids', [])), 'assembly_inverter_role_set_exact', gid)
        test(r['Observed Relation'] == frozen.get('relationship') and r['Counting / Integration Rule'] == frozen.get('integration_policy') and 'DO_NOT_SUM_ASSEMBLY_AND_COMPONENT' in r['Counting / Integration Rule'] and 'BOM' in r['Counting / Integration Rule'], 'assembly_no_double_count_or_inferred_bom_boundary', gid)
        if frozen:
            ss = source_ess_cells.get(source_key(frozen['ess_source_record_id']), {})
            test(eq(r['ESS Nameplate Energy (kWh)'], ss.get('Q')) and eq(r['ESS Nameplate Power (kW)'], ss.get('R')) and eq(r['Nominal Voltage (Vac)'], ss.get('S')), 'assembly_native_energy_power_voltage_units', gid)

    # Capacity and PCS data remain in role-specific native tables; no Ah,
    # apparent-power, fault, or generic no-export model is synthesized.
    batteries_final = {r['Record ID']: r for _, r, _ in master.table('BATTERIES')}
    batteries_parent = {r['Record ID']: r for _, r, _ in parent.table('BATTERIES')}
    test(len(batteries_final) == len(batteries_parent) == 865 and set(batteries_final) == set(batteries_parent), 'no_cec_kwh_rows_appended_to_legacy_ah_fault_table')
    for rid, old in batteries_parent.items():
        test(eq(batteries_final[rid].get('Capacity (Ah)'), old.get('Capacity (Ah)')), 'legacy_battery_ah_preserved_without_inference', rid)
    test(all(not any(x in str(ibr[rid].get('Source Dataset')) for x in ('CurrentPCS', 'PowerControlSystem', 'BatteryList', 'V2G')) for rid in new_ids), 'new_ibr_only_from_inverter_listing_not_control_or_battery_evidence')
    test(all(g['CEC List States'] == 'LEGACY' for g in groups.values() if g['CEC Category'] == 'CEC_PCS_LEGACY'), 'legacy_pcs_never_relabelled_current_ul3141')
    test(sum(r['CEC List Status'] == 'HISTORICAL' for _, r, _ in master.table('CEC_PMRS_HISTORICAL')) == 146 and sum(r['CEC List Status'] == 'ACTIVE' for _, r, _ in master.table('CEC_PMRS')) == 131, 'pmrs_current_and_2019_history_distinct')
    latura = groups.get('DB11-PMRS-00154', {})
    test(latura.get('Manufacturer / Provider') == 'Latura Builders' and split_ids(latura.get('CEC List States')) == {'ACTIVE', 'HISTORICAL'} and split_ids(latura.get('All Native Registry IDs')) == {'DB11-CEC-PMRS-PMRS-67', 'DB11-CEC-PMRS-20191004-72'}, 'pmrs_latura_blank_website_provider_retained_in_both_states')
    test(all(g['CEC List States'] == 'ARCHIVED' for g in groups.values() if g['CEC Category'] == 'CEC_BAT_ARCHIVE'), 'battery_archive_never_active')
    index = {r['Dataset']: r for _, r, _ in master.table('CEC_IMPORT_INDEX')}
    test(set(index) == set(inventory_byid) - {'ArchivedInverterSimplified'} and len(index) == 12, 'source_import_index_excludes_equivalent_view_only')
    for ds, row in index.items():
        src = inventory_byid[ds]
        test(row['SHA256'] == src['sha256'] and row['Download URL'] == src['download_url'] and row['CEC List Status'] == src['status'], 'source_import_identity_hash_status_exact', ds)
    source_register = defaultdict(list)
    for _, r, _ in master.table('SOURCE_REGISTER'):
        if str(r.get('Source ID')).startswith('DB11-CEC-'):
            source_register[r['Source ID']].append(r)
    for ds, src in inventory_byid.items():
        rows = source_register.get('DB11-CEC-' + ds, [])
        test(len(rows) == 1 and rows[0]['Location / DOI / URL'] == src['download_url'] and src['sha256'] in rows[0]['Notes'], 'all_cec_sources_registered_with_hash', ds)
        if ds == 'ArchivedInverterSimplified' and rows:
            test('equivalent' in rows[0]['Used By'] and 'not imported twice' in rows[0]['Used By'], 'duplicate_view_equivalence_registered')

    # File/hash race guard: a release report is valid only for these exact bytes.
    for b in source_books.values():
        b.close()
    master.close()
    parent.close()
    test(ASSEMBLY.read_bytes() == assembly_bytes and digest(OUTPUT) == output_hash, 'final_package_hash_stable_during_verification')
    test(digest(DB / 'inputs/Engineering_Master_Database_Audited.xlsx') == snapshot['sha256'], 'parent_master_unchanged')
    result = {
        'status': 'PASS' if not checks.failures else 'FAIL',
        'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
        'reviewer': 'Independent storage/CEC final-package reviewer',
        'workbook': str(OUTPUT), 'workbook_sha256': output_hash,
        'assembly_result_sha256': hashlib.sha256(assembly_bytes).hexdigest(),
        'assembly_sha256_agreed_before_inspection': True,
        'core_proposal_sha256': digest(OWN / 'core_ibr_proposal.json'),
        'dedicated_proposal_sha256': digest(OWN / 'dedicated_canonical_proposal.json'),
        'native_listing_rows': len(raw_meta), 'native_counts': dict(native_counts),
        'listing_join_rows': len(joins), 'model_group_rows': len(groups),
        'model_group_categories': dict(Counter(r['CEC Category'] for r in groups.values())),
        'assembly_role_relations': len(relations), 'new_ibr_configurations': len(new_ids),
        'updated_ibr_records': len(patch_byid), 'dc_design_limit_cleared_fields': len(clear_pairs),
        'dc_design_limit_cleared_legacy_rows': len({rid for rid, _ in clear_pairs}),
        'native_table_and_payload_rows': metrics, **checks.output(),
        'scope': 'Read-only original-source and final-OOXML join/semantics verification. No workbook, payload, assembly script or manifest edited. Numeric/typed source values, metadata, registry states and explicit engineering boundaries checked; no native Microsoft Excel runtime claim.'
    }
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'workbook_sha256', 'native_listing_rows', 'listing_join_rows', 'model_group_rows', 'assembly_role_relations', 'new_ibr_configurations', 'dc_design_limit_cleared_fields', 'check_executions', 'check_categories', 'failed_executions', 'failed_categories']}, indent=2))
    return 0 if not checks.failures else 1


def int_col(s):
    n = 0
    for c in s:
        n = n * 26 + ord(c) - 64
    return n


def split_ids(v):
    return {x.strip() for x in str(v or '').split(';') if x.strip()}


if __name__ == '__main__':
    try:
        sys.exit(verify())
    except Exception as exc:
        # A missing/mismatched assembly is a precondition, not a claim that the
        # package was checked. Any later exception remains a failed review.
        error = {'status': 'NOT_RUN_PRECONDITION_BLOCKED' if str(exc).startswith('Final verification not started:') else 'ERROR',
                 'completed_utc': datetime.now(timezone.utc).isoformat(), 'error': str(exc),
                 'traceback': traceback.format_exc(), 'workbook': str(OUTPUT)}
        REPORT.write_text(json.dumps(error, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps(error, ensure_ascii=False, indent=2))
        sys.exit(2)
