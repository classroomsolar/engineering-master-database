"""Mechanical OOXML assembly of verified Artifact-authored values."""
from lxml import etree as E
from copy import deepcopy
from xml.sax.saxutils import escape,quoteattr
import re,html,math
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';N={'s':NS};REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships';PKG='http://schemas.openxmlformats.org/package/2006/relationships'
def value(c,ss):
 t=c.get('t');v=c.find('s:v',N)
 if t=='inlineStr':return ''.join(c.find('s:is',N).itertext())
 if v is None or v.text is None:return None
 if t=='s':return ss[int(v.text)]
 if t=='b':return v.text=='1'
 if t in ['str','e','d']:return v.text
 n=float(v.text);return int(n) if n.is_integer() else n
def ci(a):
 n=0
 for c in re.match('[A-Z]+',a)[0]:n=n*26+ord(c)-64
 return n
def col(n):
 s=''
 while n:n,k=divmod(n-1,26);s=chr(k+65)+s
 return s
def attrs(s):return dict(re.findall(r'([\w:.-]+)="([^"]*)"',s))
def change_sheet(raw,obj,values):
 prefix=re.search(r'<((?:[\w.-]+:)?)(?:worksheet)\b',raw)[1];tag=lambda s:prefix+s
 rows=re.compile(r'<(?P<q>(?:[\w.-]+:)?row)\b(?P<a>[^>]*?)(?:\s*/>|>(?P<b>.*?)</(?P=q)>)',re.S);cells=re.compile(r'<(?P<q>(?:[\w.-]+:)?c)\b(?P<a>[^>]*?)(?:\s*/>|>(?P<b>.*?)</(?P=q)>)',re.S)
 sd=re.search(r'<((?:[\w.-]+:)?sheetData)\b[^>]*>(.*?)</\1>',raw,re.S);assert sd
 existing={int(attrs(r['a'])['r']):r for r in rows.finditer(sd[2])}
 def cell(a,v,old=None):
  if v is None:return ''
  at=attrs(old['a']) if old else {'r':a,'s':'5'};at.pop('t',None)
  if isinstance(v,str):at['t']='inlineStr';content=f'<{tag("is")}><{tag("t")} xml:space="preserve">{escape(v)}</{tag("t")}></{tag("is")}>'
  elif isinstance(v,bool):at['t']='b';content=f'<{tag("v")}>{int(v)}</{tag("v")}>'
  else:content=f'<{tag("v")}>{repr(v)}</{tag("v")}>'
  return '<'+tag('c')+' '+ ' '.join(k+'='+quoteattr(html.unescape(x)) for k,x in at.items())+'>'+content+'</'+tag('c')+'>'
 byrow={}
 for a,v in values.items():byrow.setdefault(int(re.search(r'\d+$',a)[0]),{})[a]=v
 def edit(r):
  nr=int(attrs(r['a'])['r']);todo=dict(byrow.get(nr,{}))
  if not todo:return r[0]
  body=r['b'] or '';out=[];pos=0
  for cm in cells.finditer(body):
   a=attrs(cm['a'])['r'];out.append(body[pos:cm.start()])
   for na in sorted([x for x in todo if ci(x)<ci(a)],key=ci):out.append(cell(na,todo.pop(na)))
   out.append(cell(a,todo.pop(a),cm) if a in todo else cm[0]);pos=cm.end()
  out.append(body[pos:]);out.extend(cell(a,todo[a]) for a in sorted(todo,key=ci));return '<'+r['q']+r['a']+'>'+''.join(out)+'</'+r['q']+'>'
 body=rows.sub(edit,sd[2]);body+=''.join('<'+tag('row')+' r="'+str(nr)+'" ht="'+str(obj.get('new_row_heights',{}).get(str(nr),48))+'" customHeight="1">'+''.join(cell(a,byrow[nr][a]) for a in sorted(byrow[nr],key=ci))+'</'+tag('row')+'>' for nr in sorted(set(byrow)-set(existing)))
 raw=raw[:sd.start(2)]+body+raw[sd.end(2):]
 raw=re.sub(r'(<(?:[\w.-]+:)?dimension\b[^>]*\bref=")([^"]+)(")',lambda m:m[1]+re.sub(r'\d+$',str(obj['new_last_row']),m[2])+m[3],raw,count=1)
 return raw
def change_table(raw,t):
 raw=re.sub(r'<(?:[\w.-]+:)?(?:table|autoFilter)\b[^>]*>',lambda m:m[0].replace('ref="'+t['old_ref']+'"','ref="'+t['new_ref']+'"'),raw)
 for old,new in t.get('headers',{}).items():raw=raw.replace('name="'+old+'"','name="'+new+'"')
 return raw
class Styles:
 def __init__(self,raw):self.root=E.fromstring(raw);self.original_counts={x.tag.split('}')[-1]:len(x) for x in self.root};self.usedformats={int(x.get('numFmtId')) for x in self.root.findall('s:numFmts/s:numFmt',N)}
 def collection(self,name):
  n=self.root.find('s:'+name,N)
  if n is None:
   n=E.Element('{'+NS+'}'+name,count='0');self.root.insert(0,n)
  return n
 def append(self,name,node):
  coll=self.collection(name);key=E.tostring(node,method='c14n')
  for i,old in enumerate(coll):
   if E.tostring(old,method='c14n')==key:return i
  coll.append(node);coll.set('count',str(len(coll)));return len(coll)-1
 def merge(self,raw):
  rt=E.fromstring(raw);mp={}
  for name in ['fonts','fills','borders']:
   mp[name]={i:self.append(name,deepcopy(n)) for i,n in enumerate(rt.find('s:'+name,N))}
  fm={}
  for n in rt.findall('s:numFmts/s:numFmt',N):
   old=int(n.get('numFmtId'));fmt=n.get('formatCode');found=next((x for x in self.root.findall('s:numFmts/s:numFmt',N) if x.get('formatCode')==fmt),None)
   if found is not None:fm[old]=int(found.get('numFmtId'));continue
   fresh=max({163}|self.usedformats)+1;self.usedformats.add(fresh);nn=deepcopy(n);nn.set('numFmtId',str(fresh));coll=self.collection('numFmts');coll.append(nn);coll.set('count',str(len(coll)));fm[old]=fresh
  def xf(n,stylemap=None):
   n=deepcopy(n)
   for a,typ in [('fontId','fonts'),('fillId','fills'),('borderId','borders')]:
    if a in n.attrib:n.set(a,str(mp[typ][int(n.get(a))]))
   if 'numFmtId' in n.attrib:n.set('numFmtId',str(fm.get(int(n.get('numFmtId')),int(n.get('numFmtId')))))
   if stylemap is not None and 'xfId' in n.attrib:n.set('xfId',str(stylemap[int(n.get('xfId'))]))
   return n
  sx={i:self.append('cellStyleXfs',xf(n)) for i,n in enumerate(rt.find('s:cellStyleXfs',N))}
  return {i:self.append('cellXfs',xf(n,sx)) for i,n in enumerate(rt.find('s:cellXfs',N))}
 def xml(self):return E.tostring(self.root,encoding='utf-8',xml_declaration=True)
def imported_cell(c,ss,stylemap,newrow,expected=None):
 c=deepcopy(c);v=value(c,ss);address=re.sub(r'\d+$',str(newrow),c.get('r'));c.set('r',address);c.set('s',str(stylemap[int(c.get('s','0'))]))
 if isinstance(expected,str) and v=="'"+expected and (expected.startswith('=') or re.match(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:',expected)):v=v[1:]
 if c.get('t')=='s' or isinstance(v,str) and expected is not None:
  for ch in list(c):c.remove(ch)
  c.set('t','inlineStr');is_=E.SubElement(c,'{'+NS+'}is');t=E.SubElement(is_,'{'+NS+'}t');t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=v
 return c
