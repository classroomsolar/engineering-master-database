"""Package the actual release checks and factual source-review decisions."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,zipfile
from urllib.parse import urlsplit
P=Path(__file__).resolve().parent
M=json.loads((P/'manifest.json').read_text());A=json.loads((P/'assembly_result.json').read_text());V=json.loads((P/'validation.json').read_text())
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert V['status']=='PASS' and V['failed_executions']==0 and V['sha256']==A['sha256']==digest(A['output'])
assert A['manifest_sha256']==digest(P/'manifest.json')
out=Path(A['output']).parent
docs=json.loads((P/'source_identity_manifest.json').read_text());facts=json.loads((P/'manufacturer_facts.json').read_text())
docmap={d['id']:d for d in docs}
source_rows=[]
for key,f in facts.items():
    d=docmap[key];source_rows.append(f"| {d['source_id']} | {d['publisher']} | {len(f['models'])} | {f['revision']} | {d['hosting']} | [Original publication]({d['url']}) |")
history_roles=Counter(t[3] for t in M['new_tables'][0]['rows'])
text=f'''# Master database source review — 25 October 2026

The existing master database has been updated. This is a source and identity audit, with unresolved records explicitly retained as unqualified. It is not a certification that the entire catalogue is error-free or that no semantic duplicate exists anywhere.

| Result | Saved DB12 |
| --- | ---: |
| Manufacturer-publication-scoped PV records updated | 16 |
| Former primary records preserved in history | 33 |
| Primary PV records | 39,400 |
| Primary IBR records | 5,603 |
| Raw CEC listings preserved | 55,018 |
| Native CEC fields preserved | 410 |
| Worksheets / native tables | 117 / 116 |
| Original formulas preserved | 53,117 |
| Record IDs duplicated in the 41 scanned identity tables | 0 |
| Identical typed-specification groups in those tables | 0 |
| New equipment models added during this authentication pass | 0 |

The workbook contains {V['total_nonempty_data_audit_reference_rows']:,} nonempty data, reference and audit rows. That total includes source memberships, history and calculation-reference records; it is not a count of unique physical equipment.

## Manufacturer corrections and scope

Fifteen PV records now follow exact, identified manufacturer publications. One additional Midsummer record retains the manufacturer's quoted nominal values under its explicit tolerance footnote. Changes include corrected voltage/current fields, dimension and mass units, temperature coefficients, revision-specific voltage limits, and removal of unsupported values. Raw CEC claims remain intact alongside the manufacturer-scoped primary data.

| Source ID | Publisher | PV records | Publication | Hosting | Source |
| --- | --- | ---: | --- | --- | --- |
{chr(10).join(source_rows)}

Specific corrections include Canadian Solar CS3W-440MB-AG maximum-power voltage 40.7 V; three Bosch NA30119 current tuples; BYD390MIK-36 nominal power 390 W and its matching electrical tuple; Centrosolar BM60 275BB; LG455N2W-E6 under the US 2021 publication; and eight GCL Nova 2019 V3.0 power bins. GCL front-NOCT powers previously associated with PTC were cleared from the primary PTC field. Canadian Solar and LG NMOT values are not relabelled as NOCT.

For Midsummer SLIM 2 × 10, the publication quotes 65 W, 10.2 V and 6.7 A with an explicit ±10% tolerance for the footnoted nominal values. Their product is 68.34 W, 5.13846% above 65 W. The quoted data are retained with a documented nominal-data exception. No measured IV-curve validation is implied.

The seven correction publication families are documented alongside 20 downloaded publication/candidate documents in SOURCE_REGISTER and the evidence index. A candidate publication with a different suffix, revision or construction is not automatically substituted for a suspect record. Distributor or directory copies are labelled as such; manufacturer hosting is not claimed for those mirrors.

## Duplicate and scenario reconciliation

EQUIPMENT_RECORD_HISTORY preserves 33 former primary records and their canonical targets:

- Six SMA reference aliases that duplicated existing model/configuration records.
- One conflicting LG source claim for the same LG455N2W-E6 model.
- Eight alternate GCL specification claims, while canonical entries are explicitly scoped to the selected publication revision.
- Eighteen SunPower rear-irradiance rating scenarios, which are operating-condition claims rather than additional manufactured models.

Original primary records, original row locations, paired PV unit-review records and record fingerprints are retained in DB12_Original_Records.json. Operational CEC links resolve to live primary IDs. Links to manufacturer-updated models explicitly distinguish the primary publication from raw CEC claims; rating/revision/configuration equality is not silently assumed. Historical audit text retains its original locations and context.

The 41-table duplicate scan compares typed specifications after case/whitespace normalization of text, while excluding record IDs and provenance. It preserves physical fields such as source voltage/type and fuse/model identifiers. Repeated names alone do not establish a duplicate: voltage, power bin, phase, curve, revision or equipment role can differ. The scan does not establish that all cross-vendor aliases or underspecified legacy configurations represent different physical products.

## Outstanding source exceptions

All 95 prior electrical flags have an explicit current disposition:

| Outcome | Records |
| --- | ---: |
| Corrected from an exact manufacturer publication | 6 |
| Qualified by the published nominal-data tolerance | 1 |
| Moved to historical rating scenarios | 12 |
| No safe replacement authenticated; electrical values remain withheld | 76 |

Fifteen surviving repeated-name source claims across five groups remain CONFIGURATION_IDENTITY_REVIEW_REQUIRED. They are not certified as distinct physical products or merged on name alone. The 76 electrical records and 15 configuration claims are separate review categories.

No nearby model, arithmetic reconstruction or supplier listing was used to invent a missing specification. RECORD_RECONCILIATION records the scope and result for each of these 110 review decisions.

## CEC source reconciliation

The 13 original downloaded CEC files correspond to 12 datasets and 14 native listing tables. Active, archived, historical and legacy source memberships remain distinguishable. The simplified inverter archive duplicates a view of the full archive and was imported once. Legitimate solar/battery inverter memberships and assembly/component roles remain source relationships, rather than being counted as separate installed units automatically.

All 14 raw listing worksheet parts, CEC_FIELD_MAP, CEC_SOURCE_NOTES and CEC_IMPORT_INDEX are byte-identical to the validated DB11 parent. The 13 original CEC file hashes were checked again. The two PMRS Latura memberships with a blank website remain present. Every one of the 55,018 registry IDs has one operational listing link.

**Your own downloaded CEC files have not yet been supplied in this chat.** CEC_FILE_RECONCILIATION contains 13 AWAITING_USER_CEC_EXPORT records with no fabricated user filename or hash. Their actual contents must be compared after upload; version differences cannot be assumed to be import errors.

## Verification of the saved file

The final independent verification executed {V['check_executions']:,} checks with zero failed executions. It checked planned typed values, original cell XML, worksheet features, original style entries, native table identities and ranges, both indexes, all PV/unit pointers, history fingerprints, operational CEC links, source-file hashes, electrical gates, error-cell types and the 41-table duplicate scan.

- {V['original_unplanned_cells_xml_checked']:,} unplanned cells in edited worksheets retained their XML, with cell addresses shifted only for the documented row compaction.
- Original formula-bearing worksheet parts and caches are byte-identical: 53,117 formulas, zero stored Excel error cells.
- All unrelated original package members remain unchanged. Wrapping is explicitly enabled in {sum(len(o.get('wrap_updates',[])) for o in M['sheets'].values())} updated PV source-note/location and unit-review status cells; row heights in edited rows accommodate the revised text.
- Saved worksheets were rendered and visually inspected using style-preserving sample projections, including the source-history, reconciliation and pending-file tables.

These checks establish the stated file/source reconciliation and engineering-data gates. They do not independently certify manufacturer-submitted ratings, reproduce every research paper, prove every legacy record authentic, or validate an external calculator/site's live consumption of the database. Microsoft Excel application recalculation was not available. No VBA or new calculator was added.

## Relevant plugin work and earlier requests

Adobe Acrobat OCR processed the scanned GCL publication. Its available extraction returned source-page figures, so the numerical table was visually checked against the original scan. It is not described as a machine-extracted numeric table. Firecrawl and TinyFish had no usable credit during this review; original-source retrieval continued through the available web/direct-document routes. Earlier vidIQ credit limitations remain recorded. Formula Genius and Coursera stayed excluded as requested.

All native tables remain indexed and their full ranges remain addressable. That establishes database access, not a new claim that every field is consumed by a separate calculator. Existing paper-audit, calculator-key and other equipment reviews are preserved; no new full-catalogue or full-paper certification is claimed.

## File identity and evidence

Master: Engineering_Master_Database_Audited.xlsx  
SHA-256: `{V['sha256']}`  
Validated parent DB11 SHA-256: `{V['parent_sha256']}`

The companion evidence ZIP contains the 13 original CEC exports, factual source identities, publication-scoped field decisions, original moved records, changes, reconciliation decisions, final validation results and the audit/authoring scripts. Original CEC exports are retained as source files; any source workbook macros are not required by the master. The bundle does not redistribute full manufacturer PDFs or raw search-page bodies. Public source URLs and document hashes identify those publications.
'''
report=out/'Master_Database_Source_Review_2026-10-25.md';report.write_text(text)

search_index=[]
for f in sorted(P.glob('search_??.json')):
    raw=json.loads(f.read_text());body='\n'.join(c.get('text','') for c in raw.get('content',[]) if c.get('type')=='text');urls=[]
    for u in re.findall(r'https?://[^\s<>\[\]()]+',body):
        u=u.rstrip('.,;');query=urlsplit(u).query.lower()
        if not any(k in query for k in ['token=','signature=','sig=','credential=','auth=']):urls.append(u)
    search_index.append({'retrieval_file':f.name,'sha256':digest(f),'candidate_urls':list(dict.fromkeys(urls)),'scope':'Search discovery candidates only; numeric authentication requires an applicable original publication.'})
(P/'search_source_index.json').write_text(json.dumps(search_index,ensure_ascii=False,indent=2))
duplicate=json.loads((P/'duplicate_candidates.json').read_text())
(P/'duplicate_scan_summary.json').write_text(json.dumps({'criteria':duplicate['criteria'],'baseline_tables':duplicate['summary'],'final_tables':V['duplicate_scan'],'limits':V['limits']},ensure_ascii=False,indent=2))

bundle=out/'Master_Database_DB12_Source_Audit_Trail.zip'
temporary_bundle=out/'DB12_Audit_Trail_Packaging.zip'
selected=['DB12_Original_Records.json','record_decisions.json','manufacturer_facts.json','source_identity_manifest.json','change_evidence.json','manifest.json','prepared_summary.json','formula_dependency_scan.json','assembly_result.json','validation.json','duplicate_scan_summary.json','search_source_index.json','visual_review.json']
scripts=['audit_existing.py','prepare_changes.py','assemble_master.py','verify_release.py','prepare_render.py','package_evidence.py','download_sources.py']
with zipfile.ZipFile(temporary_bundle,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(report,'Audit_Report.md')
    for f in selected:z.write(P/f,'evidence/'+f)
    for f in scripts:z.write(P/f,'scripts/db12/'+f)
    for f in sorted(P.glob('download_batch_??.json')):z.write(f,'scripts/db12/'+f.name)
    z.write('/tmp/2b67ca9a1d0b_db12_artifact/artifact_builder.mjs','scripts/db12/artifact_builder.mjs')
    for f in ['package_helpers.py','project_samples.py','validation.json','snapshot.json']:z.write(P.parent/'db11'/f,'scripts/db11/'+f)
    z.write(P.parent/'db11/reviews/storage/verify_release_storage.py','scripts/db11/reviews/storage/verify_release_storage.py')
    z.write(P.parent/'db11/reviews/plan_validation/guard_patch.json','scripts/db11/reviews/plan_validation/guard_patch.json')
    z.write(P.parent/'db11/reviews/pv/existing_duplicate_keys.json','scripts/db11/reviews/pv/existing_duplicate_keys.json')
    z.write(P.parent/'db11/reviews/storage/secondary_existing_cec_duplicate_references.json','scripts/db11/reviews/storage/secondary_existing_cec_duplicate_references.json')
    z.write(P.parent/'db11/reviews/review_release_storage.json','evidence/DB11_Direct_Source_Comparison.json')
    z.write(P/'authored/artifact_index.json','evidence/artifact_index.json')
    for f in P.glob('previews/*.png'):z.write(f,'visual_samples/'+f.name)
    source_ledger=next(t for t in M['new_tables'] if t['name']=='CEC_FILE_RECONCILIATION')
    z.writestr('evidence/Original_CEC_File_Ledger.json',json.dumps(source_ledger,ensure_ascii=False,indent=2))
    for s in json.loads((P.parent/'db11/cec_sources/source_inventory.json').read_text()):
        original=Path(s['file']);assert digest(original)==s['sha256']
        z.write(original,'cec_original_exports/'+original.name)
    z.writestr('README.txt','Read Audit_Report.md first. The master XLSX is supplied separately. Evidence files preserve factual claims and review decisions. Scripts retain the original run layout and require the validated parent master, original CEC exports, original publication files and bundled Codex primary runtime. Obtain those inputs from the recorded URLs and verify hashes before reproducing. Search retrieval candidates do not by themselves authenticate a model. User-supplied CEC comparison remains pending.\n')
with zipfile.ZipFile(temporary_bundle) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    inventory=json.loads((P.parent/'db11/cec_sources/source_inventory.json').read_text())
    assert len([n for n in z.namelist() if n.startswith('cec_original_exports/')])==13
    for s in inventory:
        assert hashlib.sha256(z.read('cec_original_exports/'+Path(s['file']).name)).hexdigest()==s['sha256']
temporary_bundle.replace(bundle)
result={'master':A['output'],'master_sha256':V['sha256'],'report':str(report),'evidence':str(bundle),'evidence_sha256':digest(bundle),'report_sha256':digest(report),'validation_status':V['status']}
(P/'delivery_manifest.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
