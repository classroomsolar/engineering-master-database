"""Merge verified Artifact-authored values, retaining unrelated native OOXML."""
from pathlib import Path
from copy import deepcopy
from collections import defaultdict
import bisect, hashlib, html, importlib.util, json, math, posixpath, re, zipfile
from xml.sax.saxutils import escape, quoteattr
from lxml import etree as E

P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('package_helpers',P.parent/'db11/package_helpers.py')
H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)
NS,N,REL,PKG=H.NS,H.N,H.REL,H.PKG
M=json.loads((P/'manifest.json').read_text());I=json.loads((P/'authored/artifact_index.json').read_text())
SRC=Path(M['parent']);DST=P/'outputs/db12/Engineering_Master_Database_Audited.xlsx'
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(SRC)==M['parent_sha256']
assert digest(P/'manifest.json')==I['manifest_sha256']
assert digest(I['output'])==I['output_sha256']

def shared(z):
    return [''.join(t.itertext()) for t in E.fromstring(z.read('xl/sharedStrings.xml'))] if 'xl/sharedStrings.xml' in z.namelist() else []
def paths(z):
    rs={r.get('Id'):r.get('Target') for r in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    return {s.get('name'):(rs[s.get('{'+REL+'}id')].lstrip('/') if rs[s.get('{'+REL+'}id')].startswith('/') else posixpath.normpath('xl/'+rs[s.get('{'+REL+'}id')])) for s in E.fromstring(z.read('xl/workbook.xml')).find('s:sheets',N)}
def eq(a,b):
    if a is None and b=='':return True
    if isinstance(a,bool) or isinstance(b,bool):return type(a) is type(b) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)
    return a==b
def literal(actual,expected):
    if isinstance(expected,str) and actual=="'"+expected and (expected.startswith('=') or re.match(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:',expected)):return expected
    return actual

ROWS=re.compile(r'<(?P<q>(?:[\w.-]+:)?row)\b(?P<a>[^>]*?)(?:\s*/>|>(?P<b>.*?)</(?P=q)>)',re.S)
CELLS=re.compile(r'<(?P<q>(?:[\w.-]+:)?c)\b(?P<a>[^>]*?)(?:\s*/>|>(?P<b>.*?)</(?P=q)>)',re.S)
def patch_sheet(raw,o,vals):
    prefix=re.search(r'<((?:[\w.-]+:)?)(?:worksheet)\b',raw)[1]
    tag=lambda x:prefix+x
    sd=re.search(r'<((?:[\w.-]+:)?sheetData)\b[^>]*>(.*?)</\1>',raw,re.S);assert sd
    byrow=defaultdict(dict)
    for a,v in vals.items():byrow[int(re.search(r'\d+$',a)[0])][a]=v
    def cell(a,v,cm=None):
        if v is None and cm is None:return ''
        at=H.attrs(cm['a']) if cm else {'r':a,'s':'5'}
        at.pop('t',None)
        if a in o.get('authored_wrap_styles',{}):at['s']=str(o['authored_wrap_styles'][a])
        if v is None:body=''
        elif isinstance(v,str):
            at['t']='inlineStr';body=f'<{tag("is")}><{tag("t")} xml:space="preserve">{escape(v)}</{tag("t")}></{tag("is")}>'
        elif isinstance(v,bool):at['t']='b';body=f'<{tag("v")}>{int(v)}</{tag("v")}>'
        else:body=f'<{tag("v")}>{repr(v)}</{tag("v")}>'
        return '<'+tag('c')+' '+' '.join(k+'='+quoteattr(html.unescape(x)) for k,x in at.items())+'>'+body+'</'+tag('c')+'>'
    removed=o['delete_rows'];seen=set();out=[]
    for rm in ROWS.finditer(sd[2]):
        old=int(H.attrs(rm['a'])['r']);seen.add(old)
        if old in removed:continue
        nr=old-bisect.bisect_left(removed,old);todo=dict(byrow.get(old,{}));body=rm['b'] or ''
        if todo:
            fragments=[];pos=0
            for cm in CELLS.finditer(body):
                a=H.attrs(cm['a'])['r'];fragments.append(body[pos:cm.start()])
                for na in sorted([x for x in todo if H.ci(x)<H.ci(a)],key=H.ci):fragments.append(cell(na,todo.pop(na)))
                fragments.append(cell(a,todo.pop(a),cm) if a in todo else cm[0]);pos=cm.end()
            fragments.append(body[pos:]);fragments.extend(cell(a,todo[a]) for a in sorted(todo,key=H.ci));body=''.join(fragments)
        if nr!=old:
            body=re.sub(r'(<(?:[\w.-]+:)?c\b[^>]*\br="[A-Z]+)\d+(\")',lambda m:m[1]+str(nr)+m[2],body)
        at=rm['a'];at=re.sub(r'\br="\d+"','r="'+str(nr)+'"',at,count=1)
        ht=o['row_heights'].get(str(old))
        if ht is not None:
            at=re.sub(r'\s(?:ht|customHeight)="[^"]*"','',at);at+=' ht="'+str(ht)+'" customHeight="1"'
        out.append('<'+rm['q']+at+'>'+body+'</'+rm['q']+'>')
    for old in sorted(set(byrow)-seen):
        assert old>o['old_last_row']
        nr=old-bisect.bisect_left(removed,old);ht=o['row_heights'].get(str(old),48)
        body=''.join(cell(a,byrow[old][a]) for a in sorted(byrow[old],key=H.ci))
        if nr!=old:body=re.sub(r'(<(?:[\w.-]+:)?c\b[^>]*\br="[A-Z]+)\d+(\")',lambda m:m[1]+str(nr)+m[2],body)
        out.append(f'<{tag("row")} r="{nr}" ht="{ht}" customHeight="1">'+body+f'</{tag("row")}>')
    raw=raw[:sd.start(2)]+''.join(out)+raw[sd.end(2):]
    raw=re.sub(r'(<(?:[\w.-]+:)?dimension\b[^>]*\bref=")[^"]+(\")',lambda m:m[1]+o['new_ref']+m[2],raw,count=1)
    return raw.encode()

with zipfile.ZipFile(I['output']) as authored,zipfile.ZipFile(SRC) as original:
    ap=paths(authored);ass=shared(authored);auth=defaultdict(dict)
    authored_xfs=E.fromstring(authored.read('xl/styles.xml')).find('s:cellXfs',N)
    for entry in I['patches']:
        sh=entry['sheet'];o=M['sheets'][sh]
        rt=E.fromstring(authored.read(ap[sh]));cs={c.get('r'):H.value(c,ass) for c in rt.findall('s:sheetData/s:row/s:c',N)}
        rowmap={r:i+2 for i,r in enumerate(entry['original_rows'])}
        for a,expected in o['cells'].items():
            nr=int(re.search(r'\d+$',a)[0]);local=re.sub(r'\d+$',str(rowmap[nr]),a)
            actual=literal(cs.get(local),expected);assert eq(actual,expected),(sh,a,expected,actual)
            auth[sh][a]=actual
            if a in o.get('wrap_updates',[]):
                node=rt.find('s:sheetData/s:row/s:c[@r="'+local+'"]',N)
                alignment=authored_xfs[int(node.get('s','0'))].find('s:alignment',N)
                assert alignment is not None and alignment.get('wrapText') in {'1','true'},('Artifact wrap format missing',sh,a)
        assert len(auth[sh])==len(o['cells'])
    styles=H.Styles(original.read('xl/styles.xml'));stylemap=styles.merge(authored.read('xl/styles.xml'))
    for sh,o in M['sheets'].items():
        if not o.get('wrap_updates'):continue
        wanted=set(o['wrap_updates']);found={}
        for cm in CELLS.finditer(original.read(o['path']).decode()):
            at=H.attrs(cm['a']);a=at['r']
            if a not in wanted:continue
            xf=deepcopy(styles.root.find('s:cellXfs',N)[int(at.get('s','0'))]);align=xf.find('s:alignment',N)
            if align is None:align=E.SubElement(xf,'{'+NS+'}alignment')
            align.set('wrapText','1');found[a]=styles.append('cellXfs',xf)
        for a in wanted-set(found):
            # Previously absent source-location cells use the retained body style.
            assert a in o['cells'] and o['cells'][a] is not None
            xf=deepcopy(styles.root.find('s:cellXfs',N)[5]);align=xf.find('s:alignment',N)
            if align is None:align=E.SubElement(xf,'{'+NS+'}alignment')
            align.set('wrapText','1');found[a]=styles.append('cellXfs',xf)
        assert set(found)==wanted
        o['authored_wrap_styles']=found
    wb=E.fromstring(original.read('xl/workbook.xml'));rels=E.fromstring(original.read('xl/_rels/workbook.xml.rels'));ct=E.fromstring(original.read('[Content_Types].xml'))
    sheetnumber=max(int(re.search(r'sheet(\d+)\.xml$',n)[1]) for n in original.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',n))
    tablenumber=max((int(re.search(r'table(\d+)\.xml$',n)[1]) for n in original.namelist() if re.fullmatch(r'xl/tables/table\d+\.xml',n)),default=0)
    sheetid=max(int(s.get('sheetId')) for s in wb.find('s:sheets',N))
    tableid=max(int(E.fromstring(original.read(n)).get('id')) for n in original.namelist() if n.startswith('xl/tables/') and n.endswith('.xml'))
    fresh={};added=[];ridused={r.get('Id') for r in rels}
    for d in M['new_tables']:
        name=d['name'];rt=E.fromstring(authored.read(ap[name]));sd=rt.find('s:sheetData',N)
        for row in sd:
            nr=int(row.get('r'));expected=d['headers'] if nr==1 else d['rows'][nr-2]
            for c in list(row):
                actual=literal(H.value(c,ass),expected[H.ci(c.get('r'))-1]);assert eq(actual,expected[H.ci(c.get('r'))-1]),(name,c.get('r'))
                row.replace(c,H.imported_cell(c,ass,stylemap,nr,expected[H.ci(c.get('r'))-1]))
        ref='A1:'+H.col(len(d['headers']))+str(len(d['rows'])+1)
        dim=rt.find('s:dimension',N)
        if dim is None:dim=E.Element('{'+NS+'}dimension');rt.insert(1 if rt.find('s:sheetPr',N) is not None else 0,dim)
        dim.set('ref',ref)
        for c in rt.findall('s:cols/s:col',N):
            if c.get('style') is not None:c.set('style',str(stylemap[int(c.get('style'))]))
        sheetnumber+=1;tablenumber+=1;sheetid+=1;tableid+=1
        sp=f'xl/worksheets/sheet{sheetnumber}.xml';tp=f'xl/tables/table{tablenumber}.xml';rp=f'xl/worksheets/_rels/sheet{sheetnumber}.xml.rels'
        pr=E.fromstring(authored.read(posixpath.dirname(ap[name])+'/_rels/'+posixpath.basename(ap[name])+'.rels'))
        target=next(r.get('Target') for r in pr if r.get('Type').endswith('/table'));pt=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.dirname(ap[name])+'/'+target)
        table=E.fromstring(authored.read(pt));table.set('id',str(tableid));table.set('ref',ref)
        af=table.find('s:autoFilter',N)
        if af is None:af=E.Element('{'+NS+'}autoFilter');table.insert(0,af)
        af.set('ref',ref)
        tableparts=rt.find('s:tableParts',N);assert len(tableparts)==1;tableparts[0].set('{'+REL+'}id','rId1')
        tr=E.Element('{'+PKG+'}Relationships',nsmap={None:PKG});E.SubElement(tr,'{'+PKG+'}Relationship',Id='rId1',Type=REL+'/table',Target='../tables/'+posixpath.basename(tp))
        rid='rIdDB12_'+str(sheetid);assert rid not in ridused;ridused.add(rid)
        E.SubElement(wb.find('s:sheets',N),'{'+NS+'}sheet',name=name,sheetId=str(sheetid),attrib={'{'+REL+'}id':rid})
        E.SubElement(rels,'{'+PKG+'}Relationship',Id=rid,Type=REL+'/worksheet',Target='worksheets/'+posixpath.basename(sp))
        for part,typ in [(sp,'worksheet'),(tp,'table')]:E.SubElement(ct,'{http://schemas.openxmlformats.org/package/2006/content-types}Override',PartName='/'+part,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.'+typ+'+xml')
        for part,node in [(sp,rt),(tp,table),(rp,tr)]:fresh[part]=E.tostring(node,encoding='utf-8',xml_declaration=True)
        added.append({'name':name,'path':sp,'table_path':tp,'table_name':table.get('name'),'records':len(d['rows']),'fields':len(d['headers']),'ref':ref})
    special={'xl/workbook.xml':E.tostring(wb,encoding='utf-8',xml_declaration=True),'xl/_rels/workbook.xml.rels':E.tostring(rels,encoding='utf-8',xml_declaration=True),'[Content_Types].xml':E.tostring(ct,encoding='utf-8',xml_declaration=True),'xl/styles.xml':styles.xml()}
    if 'docProps/app.xml' in original.namelist():
        app=E.fromstring(original.read('docProps/app.xml'));an={'a':'http://schemas.openxmlformats.org/officeDocument/2006/extended-properties','vt':'http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes'}
        titles=app.find('a:TitlesOfParts/vt:vector',an)
        if titles is not None:
            for x in added:E.SubElement(titles,'{'+an['vt']+'}lpstr').text=x['name']
            titles.set('size',str(len(titles)))
            for v in app.findall('a:HeadingPairs/vt:vector/vt:variant',an):
                n=v.find('vt:i4',an)
                if n is not None and int(n.text)==114:n.text='117'
            special['docProps/app.xml']=E.tostring(app,encoding='utf-8',xml_declaration=True)
    changes={o['path']:(sh,o) for sh,o in M['sheets'].items()};tablechanges={o['table_path']:o for o in M['sheets'].values()}
    DST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DST,'w',zipfile.ZIP_DEFLATED) as out:
        for it in original.infolist():
            b=original.read(it.filename)
            if it.filename in special:b=special[it.filename]
            elif it.filename in changes:
                sh,o=changes[it.filename];b=patch_sheet(b.decode(),o,auth[sh])
            elif it.filename in tablechanges:
                o=tablechanges[it.filename];b=H.change_table(b.decode(),{'old_ref':o['old_ref'],'new_ref':o['new_ref'],'headers':o.get('table_header_renames',{})}).encode()
            out.writestr(it,b)
        for name,b in fresh.items():out.writestr(name,b)
    result={'output':str(DST),'sha256':digest(DST),'new_tables':added,'original_styles_counts':styles.original_counts,'artifact_cells_verified':sum(len(v) for v in auth.values()),'parent_sha256':M['parent_sha256'],'manifest_sha256':digest(P/'manifest.json')}
    (P/'assembly_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
