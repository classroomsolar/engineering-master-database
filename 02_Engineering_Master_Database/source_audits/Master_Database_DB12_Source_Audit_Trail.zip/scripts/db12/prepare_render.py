"""Plan read-only views of the saved DB12, preserving its displayed cell styles."""
from pathlib import Path
import bisect,json,subprocess,os
P=Path(__file__).resolve().parent
M=json.loads((P/'manifest.json').read_text());A=json.loads((P/'assembly_result.json').read_text())
proof=json.loads((P/'change_evidence.json').read_text())
ids=['PVM-011547','PVM-012429','PVM-025065','PVM-025125','DB11-PV-04822']
rows={}
baseline=json.loads((P/'baseline_records.json').read_text())['records']
for sh in ['PV_MODULES','PV_UNIT_REVIEW']:
    removed=M['sheets'][sh]['delete_rows']
    rows[sh]=[r['_row']-bisect.bisect_left(removed,r['_row']) for r in baseline[sh] if r['Record ID'] in ids]
rows['AUDIT_README']=list(range(M['counts']['AUDIT_README']-2,M['counts']['AUDIT_README']+2))
rows['SOURCE_REGISTER']=list(range(M['counts']['SOURCE_REGISTER']-3,M['counts']['SOURCE_REGISTER']+2))
for sh in ['EQUIPMENT_RECORD_HISTORY','RECORD_RECONCILIATION','CEC_FILE_RECONCILIATION']:rows[sh]=[2,3,4,5,6]
rows['REQUEST_AUDIT']=[M['counts']['REQUEST_AUDIT']+1]
rows['DATABASE_TABLE_INDEX']=list(range(M['counts']['DATABASE_TABLE_INDEX']-1,M['counts']['DATABASE_TABLE_INDEX']+2))
(P/'render_rows.json').write_text(json.dumps(rows))
dest=P/'authored/final_view_projection.xlsx'
subprocess.run([os.environ['CODEX_PRIMARY_RUNTIME_PYTHON'],str(P.parent/'db11/project_samples.py'),A['output'],str(dest),'before',','.join(rows),str(P/'render_rows.json')],check=True)
views=[('PV_MODULES','A1:K6','pv_electrical'),('PV_MODULES','M1:S4','pv_physical_scope'),('PV_UNIT_REVIEW','A1:K6','pv_units'),('PV_UNIT_REVIEW','L1:Q6','pv_unit_gates'),('EQUIPMENT_RECORD_HISTORY','A1:F4','record_history_identity'),('EQUIPMENT_RECORD_HISTORY','G1:J4','record_history_evidence'),('RECORD_RECONCILIATION','A1:K4','record_reconciliation'),('CEC_FILE_RECONCILIATION','A1:G4','cec_original_files'),('CEC_FILE_RECONCILIATION','H1:J6','cec_pending_user_files'),('AUDIT_README','A1:B5','readme'),('SOURCE_REGISTER','A1:F4','source_register'),('REQUEST_AUDIT','A1:E2','request_scope'),('DATABASE_TABLE_INDEX','A1:F4','database_index')]
(P/'render_spec.json').write_text(json.dumps({'input':str(dest),'tag':'db12_saved','views':[{'sheet':s,'range':r,'name':n,'scale':1} for s,r,n in views]},indent=2))
