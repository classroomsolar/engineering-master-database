"""Read-only DB11 inventory and duplicate candidate scan for DB12 review."""
from pathlib import Path
from collections import defaultdict, Counter
import hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / 'db11'
SOURCE = PARENT / 'outputs/db11/Engineering_Master_Database_Audited.xlsx'
spec = importlib.util.spec_from_file_location('independent_reader', PARENT / 'reviews/storage/verify_release_storage.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)

EXCLUDE = set('SOURCE_REGISTER FIELD_AUDIT SHEET_MAP DATABASE_TABLE_INDEX DATA_ISSUES RESEARCH_GUIDANCE MODEL_REQUIREMENTS PV_UNIT_REVIEW PLUGIN_LOG CHANGE_LOG AUDIT_README OPTIMIZER_REVIEW PAPER_AUDIT CALCULATOR_KEY_AUDIT CABLE_NORMALIZATION NUMERIC_BENCHMARKS REQUEST_AUDIT'.split())
META = re.compile(r'^(Record ID|IBR ID|Source Record ID|Source Dataset|Source Row|Source Excel Row|Source Reference.*|Source Document.*|Source Revision.*|Verification.*|Data Status|Record Status|Available|Notes?|Audit.*|Selection Gate|Provenance.*|Retrieved.*|Source URL|Source File.*|Source Sheet.*)$', re.I)
IDENTITY = re.compile(r'Manufacturer|Vendor|Model|Catalog|Part Number|Series', re.I)

def normal(v):
    if isinstance(v, str):
        return ('text', ' '.join(v.split()).casefold())
    if v is None or v == '':
        return ('blank', '')
    if isinstance(v, bool):
        return ('bool', v)
    return ('number', v)

def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2))

ROOT.mkdir(parents=True, exist_ok=True)
sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
book = reader.Book(SOURCE)
summary = {}
examples = {}
target = {}
duplicate_ids = {}
for name in book.sheets:
    if name.startswith('CEC_') or name in EXCLUDE:
        if name in {'DATA_ISSUES', 'SOURCE_REGISTER', 'FIELD_AUDIT', 'PV_UNIT_REVIEW', 'CHANGE_LOG', 'AUDIT_README', 'SHEET_MAP', 'DATABASE_TABLE_INDEX', 'CEC_LISTING_LINKS', 'CEC_MODEL_GROUPS', 'CEC_ASSEMBLY_RELATIONS', 'REQUEST_AUDIT'}:
            target[name] = [dict(r, _row=nr) for nr, r, _ in book.table(name)]
        continue
    rows = [dict(r, _row=nr) for nr, r, _ in book.table(name)]
    if name in {'PV_MODULES', 'IBR', 'CABLES', 'TERMINATIONS'}:
        target[name] = rows
    if not rows:
        continue
    hs = [h for h in rows[0] if h != '_row']
    ih = [h for h in hs if IDENTITY.search(h) and not META.search(h)]
    if not ih:
        continue
    keys = defaultdict(list)
    full = defaultdict(list)
    ids = defaultdict(list)
    # Fields such as Max Rated Voltage Source, Source Type, Fuse Size Or Id
    # and Model Id are equipment/configuration evidence, not audit metadata.
    fields = [h for h in hs if not META.search(h)]
    for r in rows:
        rid = r.get('Record ID')
        if rid:
            ids[rid].append(r['_row'])
        key = tuple((h, normal(r.get(h))) for h in ih)
        if not any(r.get(h) for h in ih):
            continue
        keys[key].append(r)
        full[tuple((h, normal(r.get(h))) for h in fields)].append(r)
    exact = [v for v in full.values() if len(v) > 1]
    repeated = [v for v in keys.values() if len(v) > 1]
    duplicate_ids[name] = {k: v for k, v in ids.items() if len(v) > 1}
    summary[name] = {'rows': len(rows), 'identity_fields': ih, 'compared_spec_fields': fields,
        'repeated_identity_groups': len(repeated), 'identical_specification_groups': len(exact),
        'identical_specification_extra_rows': sum(len(g)-1 for g in exact), 'duplicate_record_ids': len(duplicate_ids[name])}
    examples[name] = {'identical_specification_groups': exact, 'repeated_identity_groups': repeated}
    print(json.dumps({'sheet': name, **{k: v for k, v in summary[name].items() if not isinstance(v, list)}}), flush=True)
book.close()
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == sha
dump('baseline_records.json', {'source': str(SOURCE), 'sha256': sha, 'records': target})
dump('duplicate_candidates.json', {'source_sha256': sha, 'criteria': 'Exact typed specification comparisons after case/whitespace normalization of text. Excludes provenance, record IDs and notes. Repeated names alone are candidates, not proof of identical equipment. Performance/curve/configuration roles can legitimately repeat models.', 'summary': summary, 'groups': examples, 'duplicate_record_ids': duplicate_ids})
dump('baseline_identity.json', {'library_file_id': 'libfile_e64f5592fd9c8191b228ec9f0e0f3926', 'version_id': 11, 'file_id': 'file_0000000054c081fd8d2897ee10181b89', 'path': str(SOURCE), 'sha256': sha, 'size_bytes': SOURCE.stat().st_size})
print(json.dumps({'status': 'READ_ONLY_SCAN_COMPLETE', 'sha256': sha, 'scanned_identity_tables': len(summary), 'target_tables': len(target)}), flush=True)
