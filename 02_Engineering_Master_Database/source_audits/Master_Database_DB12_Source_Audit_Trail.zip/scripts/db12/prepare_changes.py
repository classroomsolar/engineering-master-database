"""Prepare source-qualified DB12 corrections and explicit history, without editing XLSX."""
from pathlib import Path
from collections import defaultdict, Counter
from copy import deepcopy
from datetime import datetime
import hashlib, importlib.util, json, math, posixpath, re, zipfile
from lxml import etree as E

P = Path(__file__).resolve().parent
OLD = P.parent / 'db11'
SRC = OLD / 'outputs/db11/Engineering_Master_Database_Audited.xlsx'
DATE = '2026-10-25'
NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
N = {'s': NS}
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def col(i):
    s = ''
    while i: i, k = divmod(i-1, 26); s = chr(65+k)+s
    return s
def js(v): return json.dumps(v, ensure_ascii=False, separators=(',', ':'))
def save(n, v): (P/n).write_text(json.dumps(v, ensure_ascii=False, indent=2))

baseline = json.loads((P/'baseline_records.json').read_text())
assert sha(SRC) == baseline['sha256'] == 'f0214a0823c27994dd9c7090b19f90999eb310fad531a7fb1751409e3d314218'
D = baseline['records']
spec = importlib.util.spec_from_file_location('ro', OLD/'reviews/storage/verify_release_storage.py')
ro = importlib.util.module_from_spec(spec); spec.loader.exec_module(ro)
book = ro.Book(SRC)
for sh in ['PLUGIN_LOG', 'REQUEST_AUDIT', 'CEC_IMPORT_INDEX']:
    if sh not in D: D[sh] = [dict(r, _row=nr) for nr, r, _ in book.table(sh)]
headers, meta = {}, {}
with zipfile.ZipFile(SRC) as z:
    for sh, path in book.sheets.items():
        first = next(book.rows(sh))[1]
        hs = [first[col(i)] for i in range(1, len(first)+1)]
        headers[sh] = hs
        relpath = posixpath.dirname(path)+'/_rels/'+posixpath.basename(path)+'.rels'
        if relpath in z.namelist():
            rels = E.fromstring(z.read(relpath))
            target = next((r.get('Target') for r in rels if r.get('Type', '').endswith('/table')), None)
            if target:
                tp = target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.dirname(path)+'/'+target)
                tab = E.fromstring(z.read(tp))
                meta[sh] = {'path': path, 'table_path': tp, 'table_name': tab.get('name'), 'table_id': tab.get('id'), 'old_ref': tab.get('ref')}
book.close()
records = {sh: {r['_row']: r for r in rs} for sh, rs in D.items()}
original_counts = json.loads((OLD/'validation.json').read_text())['counts']
changes, reasons, heights = defaultdict(dict), {}, defaultdict(dict)
deleted, history, originals = defaultdict(set), [], {}
decisions = []
facts = json.loads((P/'manufacturer_facts.json').read_text())
sources = []
for f in sorted(P.glob('download_batch_*_results.json')):
    sources.extend(x for x in json.loads(f.read_text()) if x.get('status') == 'DOWNLOADED')
by_doc = {x['id']: x for x in sources}
for k in facts: assert k in by_doc, ('Missing original publication', k)
source_ids = {s['id']: 'DB12-SRC-'+str(i+1).zfill(3) for i, s in enumerate(sources)}

def setv(sh, row, h, value, why, evidence):
    assert h in headers[sh], (sh, h)
    r = records[sh][row]
    old = r.get(h)
    if old == value and type(old) == type(value): return
    a = col(headers[sh].index(h)+1)+str(row)
    key = sh+'!'+a
    if key not in reasons: reasons[key] = {'before': old, 'reason': why, 'evidence': evidence}
    changes[sh][a] = value
    r[h] = value

def append(sh, values, why, evidence):
    row = max(records[sh], default=1)+1
    r = dict(zip(headers[sh], values)) if isinstance(values, list) else dict(values)
    r['_row'] = row; records[sh][row] = {h: None for h in headers[sh]} | {'_row': row}
    for h in headers[sh]: setv(sh, row, h, r.get(h), why, evidence)
    return row

pv = {r['Record ID']: r for r in D['PV_MODULES']}
units = {r['Record ID']: r for r in D['PV_UNIT_REVIEW']}
ibr = {r['Record ID']: r for r in D['IBR']}
aliases = {}

def move_to_history(sh, rid, canonical, role, why, evidence):
    r = pv[rid] if sh == 'PV_MODULES' else ibr[rid]
    original = deepcopy(r); original.pop('_row', None)
    originals[rid] = {'table': sh, 'excel_row': r['_row'], 'record': original}
    if sh == 'PV_MODULES':
        original_unit = deepcopy(units[rid]); original_unit.pop('_row', None)
        originals[rid]['paired_unit_review'] = {'excel_row': units[rid]['_row'], 'record': original_unit}
    fingerprint = hashlib.sha256(js(original).encode()).hexdigest()
    history.append([rid, sh, canonical, role, r.get('Manufacturer'), r.get('Model') or r.get('Description / Model'), why, evidence, fingerprint, 'DB12_Original_Records.json / '+rid])
    aliases[rid] = canonical; deleted[sh].add(r['_row'])
    if sh == 'PV_MODULES': deleted['PV_UNIT_REVIEW'].add(units[rid]['_row'])

# Preserve original claims in history and retain one canonical model/configuration.
for x in json.loads((OLD/'reviews/storage/secondary_existing_cec_duplicate_references.json').read_text()):
    move_to_history('IBR', x['record_id'], x['canonical_ibr_id'], 'DUPLICATE_SOURCE_REFERENCE',
        'Exact existing SMA model and480V configuration. Reference alias moved out of the primary IBR equipment table. Canonical manufacturer fault record retained.', source_ids['SMA_original_short_circuit_TI23'])
move_to_history('PV_MODULES', 'PVM-025389', 'PVM-013805', 'CONFLICTING_DUPLICATE_SOURCE_CLAIM',
    'Manufacturer publishes LG455N2W-E6 as455W. Prior450W row is retained here as an unverified conflicting claim.', source_ids['LG455N2W_E6_US_2021'])
for n in range(25125, 25140, 2):
    move_to_history('PV_MODULES', f'PVM-{n+1:06}', f'PVM-{n:06}', 'OLDER_SPECIFICATION_SOURCE_CLAIM',
        'One canonical model/power-bin record is scoped to GCL2019V3.0Nova. Alternate dimensions/ratings remain a historical claim and are not silently merged into that revision.', source_ids['GCL_M3_72DH_Nova_original'])
for rid, r in pv.items():
    m = re.fullmatch(r'(SPR-P5-5\d\d-UPP) \((5|10|20)%\)', r.get('Model') or '', re.I)
    if m:
        canonical = next(k for k,v in pv.items() if (v.get('Model') or '').casefold() == m[1].casefold())
        move_to_history('PV_MODULES', rid, canonical, 'HISTORICAL_BIFACIAL_RATING_SCENARIO',
            '5/10/20% rear-irradiance rating scenario, not a separate manufactured model. Older RevA powers are source-supported, but the legacy row mixes revisions/operating data. Do not apply this scenario to the canonical newer revision without matching the publication.', source_ids['SunPower_P5_RevA_mirror'])
assert len(history) == 33 and len(deleted['PV_MODULES']) == 27 and len(deleted['IBR']) == 6

corrected = {}
for doc, f in facts.items():
    source = by_doc[doc]; sid = source_ids[doc]
    for rid, values in f['models'].items():
        r, u = pv[rid], units[rid]
        patch = f['common'] | values
        for h, v in patch.items(): setv('PV_MODULES', r['_row'], h, v, 'Exact manufacturer publication field reconciliation.', sid)
        if doc == 'Midsummer_SLIM_2023_v6':
            state = 'MANUFACTURER_NOMINAL_TOLERANCE_SCOPED'
            gate = 'Published nominal data with explicit±10%Pmax/Voc/Isc tolerance.65W remains the catalogue nominal power.68.34W voltage-current product is inside that power band. This is a documented nominal-data exception, not a measuredIVcurve validation.'
        else:
            state = 'MANUFACTURER_PUBLICATION_SCOPED'
            gate = 'Verified fields follow '+f['revision']+'. Match the purchased revision and explicit voltage/certification conditions. Separate CEC/PTC data remain registry claims.'
        note = 'DB12 current publication: '+f['revision']+', page(s)'+','.join(map(str,f['source_pages']))+'. '+f['scope']+' '+f['notes']+' Source: '+source['url']+'. Original values and superseded guard text are preserved in the change evidence. CEC raw listing tables were not changed.'
        setv('PV_MODULES', r['_row'], 'Note', note, 'Replace superseded active warning with current field-specific publication scope.', sid)
        setv('PV_MODULES', r['_row'], 'Source Dataset', (r.get('Source Dataset') or 'Legacy source')+'; '+sid+' | '+source['url'], 'Identify manufacturer field override separately from CEC registry.', sid)
        setv('PV_MODULES', r['_row'], 'Source Row', str(r.get('Source Row') or '')+'; manufacturerPDFp'+','.join(map(str,f['source_pages'])), 'Retain both registry and manufacturer source location.', sid)
        for h, v in {'Dimension Source Unit':'mm','Weight Source Unit':'kg','Coefficient Source Unit':'%/°C','Length mm':patch.get('Length Source'),'Width mm':patch.get('Width Source'),'Depth mm':patch.get('Depth Source'),'Weight kg':patch.get('Weight Source'),'Audit State':state,'Selection Gate':gate}.items():
            setv('PV_UNIT_REVIEW', u['_row'], h, v, 'Use explicit publication units and qualification.', sid)
        corrected[rid] = {'source_id': sid, 'document': doc, 'revision': f['revision'], 'fields': patch, 'power_product_tolerance': f.get('power_product_tolerance', 0.05)}

# Every original electrical flag receives an explicit, non-invented disposition.
flags = json.loads((OLD/'reviews/plan_validation/guard_patch.json').read_text())['source_review']
queries = {
 'tsec':[3,8,9], 'kisco':[3,5,6,9], 'ritek':[8], 'avancis':[7,9], 'heliene':[3,6,21],
 'miasole':[8], 'sunpower':[3,4,11,14], 'sunarray':[12], 'apos energy':[8,19], 'gintech energy':[10,19],
 'hc solar power':[12], 'perlight solar':[10], 'et solar industry':[7,12], 'bosch solar energy':[5,10,21],
 'byd company limited':[1,2,4,11,14], 'centrosolar america':[15,18], 'lg electronics inc.':[1,2,4,5,6,9,10,17,20,21,23],
 'et solar new energy':[7,12], 'helios energy europe':[23], 'jinko solar co., ltd':[13], 'axuntek solar energy':[13,18,19],
 'united renewable energy':[12,18,23], 'general energy solutions':[12,18], 'solarworld industries gmbh':[15],
 'united renewable energy co':[12,18,23], 'ningbo ulica solar sci&tech':[13,18,19], 'atersa (aplicaciones tecnicas)':[13],
 'canadian solar':[7], 'elin energy (sirius pv)':[16], 'ergosun holdings, llc':[16,17], 'kosol energie pvt. ltd.':[16],
 'maxeon solar technologies ltd.':[16,17], 'midsummer ab':[17], 'qcells north america':[1,4,5,17]
}
candidate_docs = {
 'heliene':['Heliene_72P_ENF_manufacturer_copy','Heliene_installation_guide_mirror'],
 'hc solar power':['HC_Solar_HCP_D_2012'], 'perlight solar':['Perlight_PLM_250M_60_Delta'],
 'solarworld industries gmbh':['SolarWorld_SW275_2014_US','SolarWorld_SW275_2016_EN']
}
for flag in flags:
    rid = flag['record_id']; r = pv[rid]; vendor = flag['manufacturer'].casefold()
    query_files = ['search_'+str(i).zfill(2)+'.json' for i in queries[vendor]]
    assert all((P/q).exists() for q in query_files)
    evidence = '; '.join(source_ids[x] for x in candidate_docs.get(vendor, [])) or 'Exact-model research retained in DB12 review evidence'
    if rid in aliases:
        outcome, state = 'MOVED_TO_RATING_HISTORY', 'NOT_INDEPENDENT_EQUIPMENT'
        scope = 'Original mixed-condition claim retained in history. No operating voltage/current is fabricated for a rear-irradiance scenario.'
    elif rid in corrected:
        outcome = 'PUBLISHED_NOMINAL_TOLERANCE_QUALIFIED' if rid == 'DB11-PV-04822' else 'CORRECTED_FROM_EXACT_MANUFACTURER_PUBLICATION'
        state = units[rid]['Audit State']; evidence = corrected[rid]['source_id']; scope = facts[corrected[rid]['document']]['scope']
    else:
        outcome, state = 'NO_SAFE_REPLACEMENT_AUTHENTICATED', 'ELECTRICAL_CONSISTENCY_REVIEW_REQUIRED'
        scope = 'Exact suffix, revision, rating condition or conflicting field could not be qualified from the original publications found. Retain the joint numeric withhold. Registry copies, nearby variants and arithmetic reconstruction are not replacement specifications.'
        if vendor in candidate_docs:
            scope = 'Original manufacturer publication located, but its revision/variant or physical specification differs from the legacy claim. '+scope
        for h in flag['withheld_fields']: assert r.get(h) is None, (rid,h)
        note = 'DB12 source recheck: '+scope+' Reported legacy combination: '+js(flag['reported_values'])+'. Review evidence: '+evidence+'. Original detailed DB11 note retained in the change evidence. CEC raw source values are unchanged.'
        setv('PV_MODULES', r['_row'], 'Note', note, 'Record original-source search result without inventing a correction.', evidence)
        setv('PV_UNIT_REVIEW', units[rid]['_row'], 'Selection Gate', state+'. '+scope, 'Keep unqualified electrical data unavailable.', evidence)
    decisions.append({'record_id':rid,'table':'PV_MODULES','manufacturer':flag['manufacturer'],'model':flag['model'],'issue':'DB11 electrical consistency flag','outcome':outcome,'state':state,'source_ids':evidence,'scope':scope,'query_files':query_files})
assert len(decisions)==95

# Inspect all14 prior repeated-name groups; configuration differences are explicit.
for group in json.loads((OLD/'reviews/pv/existing_duplicate_keys.json').read_text()):
    ids = [x['Record ID'] for x in group['records']]
    live = [rid for rid in ids if rid not in aliases]
    if len(live)<=1: continue
    for rid in live:
        r,u=pv[rid],units[rid]
        scope='Repeated manufacturer/model label. Power and/or system-voltage claims differ. Exact configuration identity remains unresolved; these rows are not certified as distinct physical products and are not merged by name alone.'
        setv('PV_MODULES',r['_row'],'Note',(r.get('Note') or '')+' DB12 identity review: '+scope,'Qualify underspecified repeated names rather than certifying distinct equipment.', 'DB12-IDENTITY-REVIEW')
        setv('PV_UNIT_REVIEW',u['_row'],'Audit State','CONFIGURATION_IDENTITY_REVIEW_REQUIRED','Require precise variant identity for repeated labels.','DB12-IDENTITY-REVIEW')
        setv('PV_UNIT_REVIEW',u['_row'],'Selection Gate','CONFIGURATION_IDENTITY_REVIEW_REQUIRED. '+scope,'Keep unresolved variants outside a verified selection claim.','DB12-IDENTITY-REVIEW')
        decisions.append({'record_id':rid,'table':'PV_MODULES','manufacturer':r.get('Manufacturer'),'model':r.get('Model'),'issue':'Repeated-name configuration identity','outcome':'DISTINCT_SOURCE_CLAIMS_NOT_PHYSICAL_PRODUCT_CERTIFICATION','state':'CONFIGURATION_IDENTITY_REVIEW_REQUIRED','source_ids':'Original legacy records and exact-model review evidence','scope':scope,'query_files':['search_22.json','search_23.json']})

# Redirect operational listing foreign keys. Original raw registry tables are immutable.
redirected=0
for r in D['CEC_LISTING_LINKS']:
    for h in ['Primary Record ID','Candidate Existing IDs']:
        old=r.get(h)
        if not old: continue
        new=old
        for a,b in aliases.items(): new=re.sub(r'(?<![A-Za-z0-9_-])'+re.escape(a)+r'(?![A-Za-z0-9_-])',b,new)
        if h=='Candidate Existing IDs' and new!=old:
            new='; '.join(dict.fromkeys(x.strip() for x in re.split(r';\s*',new) if x.strip()))
        if new!=old: setv('CEC_LISTING_LINKS',r['_row'],h,new,'Redirect a moved legacy alias to its canonical primary identity.','DB12-IDENTITY-REVIEW');redirected+=1
    qualification = corrected.get(r.get('Primary Record ID'))
    if qualification:
        existing_scope = r.get('Scope')
        try: scopes = json.loads(existing_scope) if existing_scope else []
        except (TypeError,ValueError): scopes = [{'legacy_scope':existing_scope}]
        if not isinstance(scopes,list): scopes = [scopes]
        scopes.append({'code':'PRIMARY_MANUFACTURER_PUBLICATION_SCOPE','source_id':qualification['source_id'],'revision':qualification['revision'],'primary_fields':'Manufacturer-publication-scoped; raw registry values can differ.','boundary':'Raw CEC listing retained unchanged. This model-name link does not certify rating equality, revision equality or physical configuration equivalence.'})
        setv('CEC_LISTING_LINKS',r['_row'],'Scope',js(scopes),'Expose manufacturer field overrides at the registry-to-primary boundary.',qualification['source_id'])

# Unit-review Source Row is a current master-PV row pointer, not source-publication row.
final_pv_rows={r['Record ID']:i+2 for i,r in enumerate(r for r in D['PV_MODULES'] if r['_row'] not in deleted['PV_MODULES'])}
for rid,nr in final_pv_rows.items(): setv('PV_UNIT_REVIEW',units[rid]['_row'],'Source Row',nr,'Keep unit review joined to the current compacted primary row.','DB12-ROW-RECONCILIATION')

for s in sources:
    sid=source_ids[s['id']]; f=facts.get(s['id'])
    append('SOURCE_REGISTER',{'Source ID':sid,'Type':'Manufacturer publication' if f else 'Manufacturer publication candidate','Title / Description':s['id'].replace('_',' '),'Edition / Rev':f['revision'] if f else 'See original publication; candidate applicability not generalized','Status':'PUBLICATION_FIELDS_CHECKED' if f else 'PUBLICATION_INSPECTED_LIMITED_SCOPE','Used By':'; '.join(f['models']) if f else 'DB12 record/identity review','Original / Scoped Verification Claim':f['scope'] if f else 'Candidate publication or model identity evidence only. No blanket field authentication.','Location / DOI / URL':s['url'],'Notes':'Publisher: '+s['publisher']+'. Hosting: '+s['hosting']+'. SHA256 '+s['sha256']+'. Original PDFs inspected; evidence bundle records facts/identity rather than redistributing full publications.','Record ID':sid,'Independent Audit State':'EXACT_PUBLICATION_FIELDS_AND_SCOPE_CHECKED' if f else 'CANDIDATE_OR_IDENTITY_ONLY','Evidence / Applicable Scope':f['notes'] if f else s['description']},'Register inspected original publication and exact limits.',sid)

# Compact affected primary tables. No original formula/name depends on them.
dep=json.loads((P/'formula_dependency_scan.json').read_text());assert dep['affected_formulas_and_names']==[]
for d in decisions:
    append('DATA_ISSUES',{'Sheet':d['table'],'Cell / Row':d['record_id'],'Issue':d['issue'],'Original Value / Reference':'DB11 guard/legacy source claim; review by stable Record ID','Status':d['outcome'],'Required Action':d['scope']},'Publish current record review outcome.',d['source_ids'])

# Native-table source-file comparison is explicitly pending user-supplied exports.
original_sources=json.loads((OLD/'cec_sources/source_inventory.json').read_text())
source_tables={
 'PVModuleList':['CEC_PV_ACTIVE'],'InvertersList':['CEC_SOLAR_INVERTERS','CEC_BATTERY_INVERTERS'],
 'BatteryList':['CEC_BATTERIES'],'EnergyStorage':['CEC_ENERGY_STORAGE'],'MeterList':['CEC_METERS'],
 'CurrentPCS':['CEC_LEGACY_PCS'],'V2G':['CEC_V2G'],'ArchivedBattery':['CEC_BATTERY_ARCHIVE'],
 'ArchivedInverterFull':['CEC_INVERTER_ARCHIVE'],'ArchivedInverterSimplified':[],
 'ArchivedPV':['CEC_PV_ARCHIVE'],'PowerControlSystem':['CEC_POWER_CONTROL'],'PMRS':['CEC_PMRS','CEC_PMRS_HISTORICAL']}
compare=[]
for s in original_sources:
    p=Path(s['file']); assert sha(p)==s['sha256']
    tables=source_tables[s['id']]
    compare.append([p.name,s['download_url'],s['sha256'],'; '.join(tables) or 'Equivalent simplified archive view; full imported once',sum(original_counts[t] for t in tables),sum(len(headers[t])-5 for t in tables), 'DB11 direct-source field comparison PASS; DB12 raw source tables unchanged',None,None,'AWAITING_USER_CEC_EXPORT'])
assert sum(r[4] for r in compare)==55018 and sum(r[5] for r in compare)==410

new_tables=[
 {'name':'EQUIPMENT_RECORD_HISTORY','headers':['Former Record ID','Canonical Table','Canonical Record ID','Record Role','Manufacturer','Model / Condition','Resolution','Evidence Source ID','Original Record SHA256','Original Record Evidence'],'rows':history},
 {'name':'RECORD_RECONCILIATION','headers':['Review ID','Equipment Table','Record ID','Manufacturer','Model','Issue','Review Outcome','Source IDs','Applicable Scope','Engineering State','Review Date'],'rows':[[f'DB12-REV-{i+1:04}',d['table'],d['record_id'],d['manufacturer'],d['model'],d['issue'],d['outcome'],d['source_ids'],d['scope'],d['state'],DATE] for i,d in enumerate(decisions)]},
 {'name':'CEC_FILE_RECONCILIATION','headers':['Original CEC Filename','Official Source URL','Original File SHA256','Native Master Tables','Imported Listing Rows','Native Fields','Available Original Comparison','User Supplied Filename','User File SHA256','User File Comparison Status'],'rows':compare}]

append('AUDIT_README',['DB12 source corrections','Exact manufacturer publications support 16 primary PV records. This includes one nominal-data tolerance exception. 33 legacy duplicate/source/scenario rows move to EQUIPMENT_RECORD_HISTORY with stable-ID redirects. Alternate unverified claims remain evidence, not additional verified physical models.'],'Document DB12 scope.','DB12-REVIEW')
append('AUDIT_README',['DB12 unresolved records','95 prior electrical flags: 7 publication-qualified outcomes, 12 rating scenarios moved out of the equipment table, 76 retain joint numeric withholds. Older repeated-name configurations remain explicitly unqualified. Original CEC registry rows are source evidence and may repeat across statuses/configurations.'],'Do not claim zero unresolved records.','DB12-REVIEW')
append('AUDIT_README',['DB12 CEC user-file comparison','All 55,018 original imported listings and 410 native fields remain available. CEC_FILE_RECONCILIATION records the 13 original downloads and explicitly awaits the user-supplied copies. No comparison with absent user files is claimed.'],'Track the user-file dependency concretely.','DB12-CEC-COMPARE')
append('AUDIT_README',['DB12 identity and unit pointers','PV_UNIT_REVIEW.Source Row points to the current master PV row. Former IDs moved out of primary equipment tables resolve through EQUIPMENT_RECORD_HISTORY. Historical audit/source notes keep original row locations and original claim wording. Manufacturer field overrides do not rewrite raw CEC data or establish installed-product equivalence.'],'Explain stable identity and source semantics.','DB12-IDENTITY-REVIEW')
append('PLUGIN_LOG',{'Plugin':'Adobe Acrobat','Outcome':'DB12 OCR_COMPLETED_EXTRACTION_FIGURES_ONLY','Work Performed':'OCR of original scanned GCL manufacturer publication. Direct extraction returned source-page figures. URN handoff failed at the file-parameter adapter.','Contribution':'Numeric table manually checked against rendered original, revisionGCL-EN-M3/72DH-N-2019-V3.0.','Limit / Artifact':'No machine-extracted numeric table or independent manufacturer certification claimed. '+DATE},'Record actual relevant plugin use and limits.','DB12-ACROBAT')
append('REQUEST_AUDIT',{'Request':'Recheck suspect records and compare user-downloaded CEC files','Disposition':'SOURCE_REVIEW_PERFORMED_USER_CEC_FILES_PENDING','Work Completed':'Exact publication corrections, stable-ID history and listing redirects, explicit unresolved-review outcomes and13file comparison records.','Evidence':'RECORD_RECONCILIATION; EQUIPMENT_RECORD_HISTORY; CEC_FILE_RECONCILIATION; original publications and review evidence.','Remaining Boundary':'User-supplied CEC downloads have not yet arrived. Whole-catalogue manufacturer certification and independent physical/engine validation are not claimed.'},'Record current authorized request without false completion.','DB12-REVIEW')

# Log each material field change; row-only unit pointers are a documented batch.
for key, proof in list(reasons.items()):
    sh,a=key.split('!');
    if sh in {'CHANGE_LOG','FIELD_AUDIT','SHEET_MAP','DATABASE_TABLE_INDEX','AUDIT_README','PLUGIN_LOG','DATA_ISSUES','SOURCE_REGISTER','REQUEST_AUDIT'}: continue
    if sh=='PV_UNIT_REVIEW' and a.startswith('B'): continue
    append('CHANGE_LOG',{'Change':'DB12-'+str(len(records['CHANGE_LOG'])+1),'Sheet':sh,'Cell / Range':a,'Before':proof['before'],'After / Formula':changes[sh][a],'Reason':proof['reason'],'Evidence ID':proof['evidence'],'Review Date':DATE},'Record source-authenticated change.','DB12-CHANGELOG')
append('CHANGE_LOG',{'Change':'DB12-IDENTITY-CONSOLIDATION','Sheet':'PV_MODULES / IBR / PV_UNIT_REVIEW','Cell / Range':'33 former IDs in EQUIPMENT_RECORD_HISTORY','Before':'27 PV model/source/scenario rows plus6IBRreference aliases;27paired unit rows','After / Formula':'33 original claims preserved with canonical redirects; primary and unit tables compacted','Reason':'Separate source history and rating scenarios from independent equipment model records. Internal formula/name dependency scan found no affected references.','Evidence ID':'DB12-IDENTITY-REVIEW','Review Date':DATE},'Record table compaction and canonical pointer batch.','DB12-CHANGELOG')

# Reconcile metadata, using the actual final row ranges.
counts=dict(original_counts)
for sh,rs in records.items(): counts[sh]=len(rs)-len(deleted[sh])
for t in new_tables: counts[t['name']]=len(t['rows']);headers[t['name']]=t['headers']
for t in new_tables:
    append('SHEET_MAP',{'Sheet':t['name'],'Data rows (2026-10-24)':len(t['rows']),'Fields':len(t['headers']),'Join Key':t['headers'][0],'Applicable Calculator Uses':'Source/identity audit; not additive installed-equipment quantities','Integration State':'DATABASE_ONLY_REFERENCE','Selection / Release Requirements':'Apply documented role and scope; userCECfilecomparison remains pending.'},'Index new audit/history table.','DB12-INDEX')
    append('DATABASE_TABLE_INDEX',{'Database Sheet':t['name'],'Structured Table Name':'EDB_'+t['name'],'Full Table Range':'A1:'+col(len(t['headers']))+str(len(t['rows'])+1),'Database Records':len(t['rows']),'Lookup Availability':'ALL_ROWS_AND_FIELDS_ADDRESSABLE','Engineering Release Gate':'History and audit rows do not represent additional independent equipment.'},'Index new native table.','DB12-INDEX')
counts['SHEET_MAP']=len(records['SHEET_MAP']);counts['DATABASE_TABLE_INDEX']=len(records['DATABASE_TABLE_INDEX'])
for r in records['SHEET_MAP'].values():
    if r.get('Sheet') in counts: setv('SHEET_MAP',r['_row'],'Data rows (2026-10-24)',counts[r['Sheet']],'Reconcile actual final data row count.','DB12-INDEX')
for r in records['DATABASE_TABLE_INDEX'].values():
    sh=r.get('Database Sheet')
    if sh in counts:
        setv('DATABASE_TABLE_INDEX',r['_row'],'Database Records',counts[sh],'Reconcile final native-table count.','DB12-INDEX')
        setv('DATABASE_TABLE_INDEX',r['_row'],'Full Table Range','A1:'+col(len(headers[sh]))+str(counts[sh]+1),'Reconcile final native-table range.','DB12-INDEX')
for r in records['AUDIT_README'].values():
    if r.get('Topic')=='Audit date': setv('AUDIT_README',r['_row'],'Details',DATE,'Current audit date.','DB12-REVIEW')
    if r.get('Topic')=='Coverage': setv('AUDIT_README',r['_row'],'Details',f'Current master: 117 worksheets, 116 native tables and {sum(counts.values()):,} nonempty data/audit/reference rows. These are not unique equipment counts. 33 former records remain in history rather than the primary model tables.','Reconcile current coverage.','DB12-INDEX')
    if r.get('Topic')=='Structured database access': setv('AUDIT_README',r['_row'],'Details','All 117 worksheets and 116 native tables are indexed. Original worksheet/table identities remain. EQUIPMENT_RECORD_HISTORY resolves the 33 moved source/scenario IDs.','Refresh current structured database description.','DB12-INDEX')

for r in records['FIELD_AUDIT'].values():
    sh,h=r.get('Sheet'),r.get('Field')
    if sh not in records or h not in headers.get(sh,[]): continue
    if sh not in changes: continue
    rows=[v for nr,v in records[sh].items() if nr not in deleted[sh]]
    vals=[v.get(h) for v in rows];pop=[v for v in vals if v is not None and v!='']
    stats={'Records':len(rows),'Populated':len(pop),'Blank':len(rows)-len(pop),'Completeness':len(pop)/len(rows) if rows else 0,'Numeric':sum(isinstance(v,(int,float)) and not isinstance(v,bool) for v in pop),'Numeric Text':sum(isinstance(v,str) and bool(re.fullmatch(r'[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?',v.strip())) for v in pop),'Zeros':sum(isinstance(v,(int,float)) and not isinstance(v,bool) and v==0 for v in pop)}
    for hh,v in stats.items(): setv('FIELD_AUDIT',r['_row'],hh,v,'Refresh diagnostics for edited table.','DB12-FIELD-AUDIT')

width_cache = {}
def column_widths(sh):
    if sh in width_cache: return width_cache[sh]
    with zipfile.ZipFile(SRC) as package:
        with package.open(meta[sh]['path']) as stream: header_xml = stream.read(65536).decode()
    widths = {i: 8.43 for i in range(1,len(headers[sh])+1)}
    for match in re.finditer(r'<(?:[\w.-]+:)?col\b[^>]*/>',header_xml):
        at=dict(re.findall(r'([\w:.-]+)="([^"]*)"',match[0]))
        for i in range(int(at['min']),int(at['max'])+1):
            if i in widths: widths[i]=float(at.get('width',8.43))
    width_cache[sh] = widths
    return widths

for sh,cs in changes.items():
    rowids={int(re.search(r'\d+$',a)[0]) for a in cs}
    headers_by_col = {col(i+1): h for i,h in enumerate(headers[sh])}
    row_changed_headers = defaultdict(set)
    for a in cs:
        row_changed_headers[int(re.search(r'\d+$',a)[0])].add(headers_by_col[re.sub(r'\d+$', '', a)])
    for nr in rowids:
        if nr in deleted[sh]: continue
        changed_headers = row_changed_headers[nr]
        if sh == 'PV_UNIT_REVIEW' and changed_headers == {'Source Row'}:
            continue
        r=records[sh][nr]
        widths = column_widths(sh)
        lines = max((max((math.ceil(len(part)/max(6,widths[i+1]-2)) for part in str(r.get(h) or '').split('\n')),default=1) for i,h in enumerate(headers[sh])),default=1)
        heights[sh][str(nr)]=min(409,max(32,(lines+1)*15+8))

changes['SHEET_MAP']['B1']='Data rows (2026-10-25)'
reasons['SHEET_MAP!B1']={'before':'Data rows (2026-10-24)','reason':'Current review-date header.','evidence':'DB12-INDEX'}
headers['SHEET_MAP'][1]='Data rows (2026-10-25)'
manifest={'parent':str(SRC),'parent_sha256':sha(SRC),'parent_library_version':11,'review_date':DATE,'sheets':{},'new_tables':new_tables,'aliases':aliases,'corrected_manufacturer_records':corrected,'history_count':len(history),'outcomes':dict(Counter(d['outcome'] for d in decisions)),'original_electrical_flag_outcomes':dict(Counter(d['outcome'] for d in decisions[:95])),'redirected_listing_cells':redirected,'counts':counts,'total_rows':sum(counts.values()),'headers_total':sum(map(len,headers.values())),'formula_dependency_scan':dep}
for sh,cs in changes.items():
    oldlast=original_counts[sh]+1
    manifest['sheets'][sh]={**meta[sh],'headers':headers[sh],'old_rows':original_counts[sh],'new_rows':counts[sh],'old_last_row':oldlast,'new_last_row':counts[sh]+1,'cells':cs,'delete_rows':sorted(deleted[sh]),'row_heights':heights[sh],'new_ref':'A1:'+col(len(headers[sh]))+str(counts[sh]+1)}
    if sh == 'PV_UNIT_REVIEW':
        manifest['sheets'][sh]['wrap_updates'] = [a for a in cs if re.fullmatch(r'L\d+',a)]
    if sh == 'PV_MODULES':
        manifest['sheets'][sh]['wrap_updates'] = [a for a,v in cs.items() if isinstance(v,str) and re.fullmatch(r'(S|Z|AA)\d+',a)]
    if sh=='SHEET_MAP':manifest['sheets'][sh]['table_header_renames']={'Data rows (2026-10-24)':'Data rows (2026-10-25)'}
for sh in deleted:
    if deleted[sh] and sh not in manifest['sheets']:
        manifest['sheets'][sh]={**meta[sh],'headers':headers[sh],'old_rows':original_counts[sh],'new_rows':counts[sh],'old_last_row':original_counts[sh]+1,'new_last_row':counts[sh]+1,'cells':{},'delete_rows':sorted(deleted[sh]),'row_heights':{},'new_ref':'A1:'+col(len(headers[sh]))+str(counts[sh]+1)}
save('manifest.json',manifest);save('change_evidence.json',reasons);save('DB12_Original_Records.json',originals);save('record_decisions.json',decisions)
save('source_identity_manifest.json',[{k:v for k,v in s.items() if k in {'id','url','publisher','hosting','description','sha256','bytes','status'}} | {'source_id':source_ids[s['id']]} for s in sources])
save('prepared_summary.json',{k:v for k,v in manifest.items() if k in ['parent_sha256','parent_library_version','review_date','history_count','outcomes','original_electrical_flag_outcomes','redirected_listing_cells','counts','total_rows','headers_total']})
print(js({'status':'PLAN_PREPARED','changed_sheets':len(manifest['sheets']),'planned_cells':sum(len(x['cells']) for x in manifest['sheets'].values()),'history':len(history),'corrected_primary_PV':len(corrected),'original_flag_outcomes':manifest['original_electrical_flag_outcomes'],'counts':{k:counts[k] for k in ['PV_MODULES','PV_UNIT_REVIEW','IBR']},'total_rows':manifest['total_rows']}))
