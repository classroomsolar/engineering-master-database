import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {Workbook, SpreadsheetFile, FileBlob} from '@oai/artifact-tool';

const mode=process.argv[2], root=path.resolve(process.argv[3]);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const safe=v=>typeof v==='string'&&(v.startsWith('=')||/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:/.test(v))?`'${v}`:v;
function col(n){let s='';while(n){let k=(n-1)%26;s=String.fromCharCode(65+k)+s;n=Math.floor((n-1)/26);}return s;}
function columnIndex(a){let n=0;for(const c of a.match(/^[A-Z]+/)[0])n=n*26+c.charCodeAt(0)-64;return n;}
function tableStyle(s,d){
 const end=col(d.headers.length),n=d.rows.length+1;
 s.showGridLines=false;s.tabColor='#1F4E78';s.freezePanes.freezeRows(1);s.freezePanes.freezeColumns(1);
 const all=s.getRange(`A1:${end}${n}`);all.format.font={name:'Calibri',size:11,color:'#17212B'};all.format.verticalAlignment='top';all.format.wrapText=true;
 const h=s.getRange(`A1:${end}1`);h.format.fill='#1F4E78';h.format.font={name:'Calibri',size:11,bold:true,color:'#FFFFFF'};h.format.rowHeight=64;h.format.horizontalAlignment='center';
 const widths=d.headers.map(h=>/Scope|Resolution|Comparison|Evidence$/.test(h)?62:/URL/.test(h)?68:/Model|Manufacturer|Role|Outcome|State|Native Master/.test(h)?38:/SHA256/.test(h)?70:/Source IDs|Source ID/.test(h)?34:Math.max(20,Math.min(36,h.length+2)));
 widths.forEach((w,i)=>s.getRange(`${col(i+1)}1:${col(i+1)}${n}`).format.columnWidth=w);
 d.rows.forEach((r,i)=>{let lines=1;r.forEach((v,c)=>{if(typeof v==='string')lines=Math.max(lines,...v.split('\n').map(t=>Math.ceil(t.length/Math.max(12,widths[c]-3))));});s.getRange(`A${i+2}`).format.rowHeight=Math.min(409,Math.max(42,lines*16+8));});
 s.tables.add(`A1:${end}${n}`,true,'EDB_'+d.name);
}

if(mode==='author'){
 const raw=await fs.readFile(path.join(root,'manifest.json')),m=JSON.parse(raw),w=Workbook.create(),index=[];
 for(const [name,o] of Object.entries(m.sheets)){
  const s=w.worksheets.add(name),rows=[...new Set(Object.keys(o.cells).map(a=>Number(a.match(/\d+$/)[0])))].sort((a,b)=>a-b);
  const rowMap=new Map(rows.map((r,i)=>[r,i+2])),matrix=rows.map(()=>Array(o.headers.length).fill(null));
  for(const [a,v] of Object.entries(o.cells))matrix[rowMap.get(Number(a.match(/\d+$/)[0]))-2][columnIndex(a)-1]=safe(v);
  s.getRange('A1').write([o.headers,...matrix]);
  for(const a of o.wrap_updates||[]){const local=a.replace(/\d+$/,String(rowMap.get(Number(a.match(/\d+$/)[0]))));s.getRange(local).format.wrapText=true;}
  index.push({sheet:name,original_rows:rows,planned_cells:Object.keys(o.cells).length});
 }
 for(const d of m.new_tables){const s=w.worksheets.add(d.name);s.getRange('A1').write([d.headers,...d.rows].map(r=>r.map(safe)));tableStyle(s,d);}
 w.recalculate();
 const inspect=await w.inspect({kind:'region',sheetId:'EQUIPMENT_RECORD_HISTORY',range:'A1:D4',maxChars:1800});
 const out=path.join(root,'authored/DB12_Artifact_Values.xlsx');await fs.mkdir(path.dirname(out),{recursive:true});await(await SpreadsheetFile.exportXlsx(w)).save(out);
 const result={manifest_sha256:hash(raw),output:out,output_sha256:hash(await fs.readFile(out)),patches:index,new_tables:m.new_tables.map(d=>({sheet:d.name,rows:d.rows.length,columns:d.headers.length})),inspect};
 await fs.writeFile(path.join(root,'authored/artifact_index.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify({status:'ARTIFACT_AUTHORED',patch_cells:index.reduce((n,x)=>n+x.planned_cells,0),new_tables:result.new_tables,sha256:result.output_sha256}));
}else if(mode==='render'){
 const spec=JSON.parse(await fs.readFile(process.argv[4],'utf8')),w=await SpreadsheetFile.importXlsx(await FileBlob.load(spec.input));
 await fs.mkdir(path.join(root,'previews'),{recursive:true});
 for(const d of spec.views){const b=await w.render({sheetName:d.sheet,range:d.range,scale:d.scale||1,format:'png'});await fs.writeFile(path.join(root,'previews',d.name+'.png'),new Uint8Array(await b.arrayBuffer()));}
 await fs.writeFile(path.join(root,'previews',spec.tag+'_inspect.json'),JSON.stringify(await w.inspect({kind:'sheet,table',maxChars:3000,tableMaxRows:2,tableMaxCols:4}),null,2));
 console.log(JSON.stringify({status:'RENDERED',views:spec.views.map(d=>d.name)}));
}else throw Error('author|render');
