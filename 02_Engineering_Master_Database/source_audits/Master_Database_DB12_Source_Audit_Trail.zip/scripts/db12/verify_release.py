"""Read-only DB12 verification, independent of its authoring and assembly code."""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import zip_longest
from copy import deepcopy
import bisect, hashlib, importlib.util, json, math, posixpath, re, zipfile
from lxml import etree as E

P=Path(__file__).resolve().parent
M=json.loads((P/'manifest.json').read_text());A=json.loads((P/'assembly_result.json').read_text())
SRC=Path(M['parent']);DST=Path(A['output'])
spec=importlib.util.spec_from_file_location('read_only',P.parent/'db11/reviews/storage/verify_release_storage.py')
RO=importlib.util.module_from_spec(spec);spec.loader.exec_module(RO)
N=RO.N;NS=RO.NS;RID=RO.RID
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(SRC)==M['parent_sha256'] and digest(DST)==A['sha256'] and digest(P/'manifest.json')==A['manifest_sha256']
checks=RO.Checks();check=checks.test
ROW=re.compile(r'<(?P<q>(?:[\w.-]+:)?row)\b[^>]*?(?:\s*/>|>.*?</(?P=q)>)',re.S)
CELL=re.compile(r'<(?P<q>(?:[\w.-]+:)?c)\b[^>]*?(?:\s*/>|>.*?</(?P=q)>)',re.S)
def address(s):return re.search(r'\br="([A-Z]+\d+)"',s)[1]
def attrs(s):return dict(re.findall(r'([\w:.-]+)="([^"]*)"',s.split('>',1)[0]))
def rownum(s):return int(re.search(r'\br="(\d+)"',s)[1])
def surround(s):
    s=re.sub(r'<(?P<q>(?:[\w.-]+:)?sheetData)\b[^>]*>.*?</(?P=q)>','SHEETDATA',s,flags=re.S)
    return re.sub(r'<(?:[\w.-]+:)?dimension\b[^>]*/>','DIMENSION',s)
def shifted(c,nr):return re.sub(r'(<(?:[\w.-]+:)?c\b[^>]*\br="[A-Z]+)\d+(\")',lambda m:m[1]+str(nr)+m[2],c,count=1)
def col(n):return RO.col(n)
def norm(v):
    if isinstance(v,str):return ('text',' '.join(v.split()).casefold())
    if v is None:return ('blank','')
    if isinstance(v,bool):return ('bool',v)
    return ('number',v)
META=re.compile(r'^(Record ID|IBR ID|Source Record ID|Source Dataset|Source Row|Source Excel Row|Source Reference.*|Source Document.*|Source Revision.*|Verification.*|Data Status|Record Status|Available|Notes?|Audit.*|Selection Gate|Provenance.*|Retrieved.*|Source URL|Source File.*|Source Sheet.*)$',re.I)
IDENTITY=re.compile(r'Manufacturer|Vendor|Model|Catalog|Part Number|Series',re.I)
baseline_scan=json.loads((P/'duplicate_candidates.json').read_text())['summary']
formula_count=error_count=unplanned_cells=unchanged_parts=0
new_names={t['name'] for t in M['new_tables']}
with zipfile.ZipFile(SRC) as old,zipfile.ZipFile(DST) as new:
    check(old.testzip() is None and new.testzip() is None,'ZIP_CRC')
    check(len(new.namelist())==len(set(new.namelist())),'UNIQUE_PACKAGE_MEMBERS')
    check(new.namelist()[:len(old.namelist())]==old.namelist(),'ORIGINAL_MEMBER_ORDER')
    expected_new_parts=set()
    for t in A['new_tables']:
        expected_new_parts.update([t['path'],t['table_path'],posixpath.dirname(t['path'])+'/_rels/'+posixpath.basename(t['path'])+'.rels'])
    check(set(new.namelist())-set(old.namelist())==expected_new_parts,'ONLY_REQUESTED_NEW_PACKAGE_PARTS')
    allowed={v['path'] for v in M['sheets'].values()}|{v['table_path'] for v in M['sheets'].values()}|{'xl/workbook.xml','xl/_rels/workbook.xml.rels','[Content_Types].xml','xl/styles.xml','docProps/app.xml'}
    for part in old.namelist():
        same=old.read(part)==new.read(part)
        if same:unchanged_parts+=1
        check(same or part in allowed,'NO_UNPLANNED_PACKAGE_CHANGE',part)
    ow=E.fromstring(old.read('xl/workbook.xml'));nw=E.fromstring(new.read('xl/workbook.xml'))
    os=list(ow.find('s:sheets',N));ns=list(nw.find('s:sheets',N))
    check(len(os)==114 and len(ns)==117,'WORKSHEET_COUNT')
    for a,b in zip(os,ns):check(E.tostring(a)==E.tostring(b),'ORIGINAL_SHEET_IDENTITY',a.get('name'))
    for a in ow:
        if a.tag.endswith('}sheets'):continue
        check(E.tostring(a)==E.tostring(nw.find(a.tag)),'WORKBOOK_FEATURE_PRESERVED',a.tag)
    ost=E.fromstring(old.read('xl/styles.xml'));nst=E.fromstring(new.read('xl/styles.xml'))
    for coll in ost:
        fresh=nst.find(coll.tag)
        check(fresh is not None and len(fresh)>=len(coll),'STYLE_COLLECTION_PRESERVED',coll.tag)
        for i,x in enumerate(coll):check(E.tostring(x,method='c14n')==E.tostring(fresh[i],method='c14n'),'ORIGINAL_STYLE_ENTRY_PRESERVED',(coll.tag,i))
    nxfs=len(nst.find('s:cellXfs',N))
    for sh,o in M['sheets'].items():
        x=old.read(o['path']).decode();y=new.read(o['path']).decode()
        check(surround(x)==surround(y),'WORKSHEET_FEATURE_PRESERVED',sh)
        planned_by_row=defaultdict(set)
        for a in o['cells']:planned_by_row[int(re.search(r'\d+$',a)[0])].add(a)
        rows_new=iter(ROW.finditer(y));last=1
        for rm in ROW.finditer(x):
            oldnr=rownum(rm[0])
            if oldnr in o['delete_rows']:continue
            nr=oldnr-bisect.bisect_left(o['delete_rows'],oldnr);nm=next(rows_new,None)
            check(nm is not None and rownum(nm[0])==nr,'ROW_ORDER_AFTER_COMPACTION',(sh,oldnr,nr))
            if nm is None:continue
            last=nr;oldcells={address(c[0]):c[0] for c in CELL.finditer(rm[0])};newcells={address(c[0]):c[0] for c in CELL.finditer(nm[0])}
            expected_additions=set()
            for a,c in oldcells.items():
                na=re.sub(r'\d+$',str(nr),a)
                if a not in o['cells']:
                    check(shifted(c,nr)==newcells.get(na),'UNPLANNED_CELL_XML_PRESERVED',(sh,a,na));unplanned_cells+=1
                else:
                    oi=int(attrs(c).get('s','0'));ni=int(attrs(newcells.get(na,'')).get('s','0'))
                    if a in o.get('wrap_updates',[]):
                        expected_xf=deepcopy(ost.find('s:cellXfs',N)[oi]);align=expected_xf.find('s:alignment',N)
                        if align is None:align=E.SubElement(expected_xf,'{'+NS+'}alignment')
                        align.set('wrapText','1')
                        check(E.tostring(expected_xf,method='c14n')==E.tostring(nst.find('s:cellXfs',N)[ni],method='c14n'),'ONLY_AUTHORED_WRAP_FORMAT_CHANGED',(sh,a))
                    else:check(oi==ni,'EDITED_CELL_STYLE_PRESERVED',(sh,a))
            for a in planned_by_row[oldnr]:expected_additions.add(re.sub(r'\d+$',str(nr),a))
            mapped_old={re.sub(r'\d+$',str(nr),a) for a in oldcells}
            check(set(newcells)<=mapped_old|expected_additions,'NO_UNPLANNED_ADDED_CELL',(sh,nr))
            oa=attrs(rm[0]);na=attrs(nm[0]);oa['r']=str(nr)
            if str(oldnr) in o['row_heights']:oa['ht']=str(o['row_heights'][str(oldnr)]);oa['customHeight']='1'
            check(oa==na,'ROW_ATTRIBUTES_PRESERVED',(sh,nr))
        for nm in rows_new:check(rownum(nm[0])>last and rownum(nm[0])<=o['new_last_row'],'APPENDED_ROW_RANGE',(sh,rownum(nm[0])))
        ot=E.fromstring(old.read(o['table_path']));nt=E.fromstring(new.read(o['table_path']))
        ot.set('ref',o['new_ref'])
        for af in ot.findall('s:autoFilter',N):af.set('ref',o['new_ref'])
        for c in ot.findall('s:tableColumns/s:tableColumn',N):
            if c.get('name') in o.get('table_header_renames',{}):c.set('name',o['table_header_renames'][c.get('name')])
        check(E.tostring(ot)==E.tostring(nt),'ORIGINAL_TABLE_FEATURES_PRESERVED',sh)
    # The formula-bearing original sheets are unaffected and remain byte-identical.
    for part,n in M['formula_dependency_scan']['formula_counts'].items():
        check(old.read(part)==new.read(part),'FORMULAS_AND_CACHES_BYTE_IDENTICAL',part)
        rt=E.fromstring(new.read(part));actual=len(rt.findall('.//s:c/s:f',N));formula_count+=actual
        check(actual==n,'FORMULA_COUNT',part)

book=RO.Book(DST);oldbook=RO.Book(SRC)
counts={};headers={};records={};duplicate_summary={};all_ids={};tablemap={};table_ids=[];table_names=[];registry_ids=Counter()
keep={'PV_MODULES','PV_UNIT_REVIEW','IBR','SOURCE_REGISTER','SHEET_MAP','DATABASE_TABLE_INDEX','CEC_LISTING_LINKS','CEC_ASSEMBLY_RELATIONS','CEC_MODEL_GROUPS','CEC_IMPORT_INDEX'}|new_names
for sh,part in book.sheets.items():
    rs=[];n=0;id_counts=Counter();ident_counts=Counter();spec_counts=Counter();hs=None
    for nr,cells,formulas in book.rows(sh):
        if nr==1:
            hs=[cells[col(i)] for i in range(1,len(cells)+1)];headers[sh]=hs
            ih=[h for h in hs if IDENTITY.search(h) and not META.search(h)]
            fields=[h for h in hs if not META.search(h)]
            continue
        if not cells and not formulas:continue
        n+=1;r={h:cells.get(col(i+1)) for i,h in enumerate(hs)}
        if sh in RO.RAW_LAYOUT:registry_ids[r['Registry Record ID']]+=1
        if sh in keep:rs.append(dict(r,_row=nr))
        rid=r.get('Record ID') or r.get('IBR ID') or r.get('Equipment Record ID')
        if rid:id_counts[rid]+=1
        if sh in baseline_scan and any(r.get(h) for h in ih):
            ident_counts[tuple((h,norm(r.get(h))) for h in ih)]+=1
            spec_counts[tuple((h,norm(r.get(h))) for h in fields)]+=1
    counts[sh]=n;all_ids[sh]=set(id_counts)
    check(n==M['counts'][sh],'FINAL_SHEET_ROW_COUNT',(sh,n,M['counts'][sh]))
    if id_counts:check(max(id_counts.values())==1,'UNIQUE_RECORD_IDS',sh)
    if sh in baseline_scan:
        duplicate_summary[sh]={'rows':n,'repeated_identity_groups':sum(v>1 for v in ident_counts.values()),'identical_specification_groups':sum(v>1 for v in spec_counts.values()),'duplicate_record_ids':sum(v>1 for v in id_counts.values())}
        check(not any(v>1 for v in spec_counts.values()),'NO_IDENTICAL_TYPED_SPECIFICATION_ROWS',sh)
    if sh in keep:records[sh]=rs
    # Validate table, style and error types using inert XML.
    scope=M['sheets'].get(sh,{})
    wrapped={re.sub(r'\d+$',str(int(re.search(r'\d+$',a)[0])-bisect.bisect_left(scope.get('delete_rows',[]),int(re.search(r'\d+$',a)[0]))),a) for a in scope.get('wrap_updates',[])}
    with book.z.open(part) as f:
        for _,c in E.iterparse(f,events=['end'],tag='{'+NS+'}c'):
            check(int(c.get('s','0'))<nxfs,'VALID_STYLE_REFERENCE',(sh,c.get('r')))
            if c.get('r') in wrapped:
                align=nst.find('s:cellXfs',N)[int(c.get('s','0'))].find('s:alignment',N)
                check(align is not None and align.get('wrapText') in {'1','true'},'NEW_SOURCE_TEXT_AND_STATUS_WRAPS',(sh,c.get('r')))
            if c.get('t')=='e':error_count+=1
            c.clear()
            while c.getprevious() is not None:del c.getparent()[0]
    rp=posixpath.dirname(part)+'/_rels/'+posixpath.basename(part)+'.rels'
    if rp in book.z.namelist():
        rels={r.get('Id'):r for r in E.fromstring(book.z.read(rp))}
        rt=E.fromstring(book.z.read(part))
        for tr in rt.findall('s:tableParts/s:tablePart',N):
            target=rels[tr.get(RID)].get('Target');tp=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.dirname(part)+'/'+target)
            t=E.fromstring(book.z.read(tp));tablemap[sh]=dict(t.attrib);table_ids.append(t.get('id'));table_names.append(t.get('name').casefold())
            check([c.get('name') for c in t.findall('s:tableColumns/s:tableColumn',N)]==hs,'NATIVE_TABLE_HEADERS',sh)
            check(t.get('ref')=='A1:'+col(len(hs))+str(n+1),'NATIVE_TABLE_RANGE',sh)
    print(json.dumps({'verified_sheet':sh,'rows':n}),flush=True)

check(len(counts)==117 and sum(counts.values())==M['total_rows'],'FINAL_TOTAL_ROWS')
check(sum(map(len,headers.values()))==1822,'FINAL_HEADER_COUNT')
check(len(table_ids)==len(set(table_ids))==len(set(table_names))==116,'UNIQUE_NATIVE_TABLE_IDENTITIES')
check(formula_count==53117 and error_count==0,'FORMULA_TOTAL_AND_NO_ERROR_CELLS')
sm={r['Sheet']:r for r in records['SHEET_MAP']};ti={r['Database Sheet']:r for r in records['DATABASE_TABLE_INDEX']}
check(set(sm)==set(counts),'SHEET_MAP_COVERAGE');check(set(ti)==set(tablemap),'TABLE_INDEX_COVERAGE')
for sh,n in counts.items():check(sm[sh]['Data rows (2026-10-25)']==n,'SHEET_MAP_COUNT',sh)
for sh,t in tablemap.items():check(ti[sh]['Database Records']==counts[sh] and ti[sh]['Structured Table Name']==t['name'] and ti[sh]['Full Table Range']==t['ref'],'TABLE_INDEX_DETAILS',sh)

# Compare every intended typed field at its final compacted address.
for sh,o in M['sheets'].items():
    expected={re.sub(r'\d+$',str(int(re.search(r'\d+$',a)[0])-bisect.bisect_left(o['delete_rows'],int(re.search(r'\d+$',a)[0]))),a):v for a,v in o['cells'].items()}
    for nr,cells,_ in book.rows(sh):
        for cc,v in cells.items():
            a=cc+str(nr)
            if a in expected:check(RO.eq(v,expected.pop(a)),'PLANNED_TYPED_CELL_VALUE',(sh,a))
    for a,v in expected.items():check(v is None or v=='','PLANNED_BLANK_CELL_VALUE',(sh,a,v))
for t in M['new_tables']:
    actual=records[t['name']]
    check(len(actual)==len(t['rows']),'NEW_TABLE_ROWS',t['name'])
    for r,vals in zip(actual,t['rows']):
        for h,v in zip(t['headers'],vals):check(RO.eq(r.get(h),v),'NEW_TABLE_TYPED_VALUE',(t['name'],r['_row'],h))

pv={r['Record ID']:r for r in records['PV_MODULES']};unit={r['Record ID']:r for r in records['PV_UNIT_REVIEW']};ibr={r['Record ID']:r for r in records['IBR']}
check(len(pv)==len(unit)==39400 and set(pv)==set(unit),'PV_UNIT_ONE_TO_ONE')
for rid,r in pv.items():check(unit[rid]['Source Row']==r['_row'],'PV_UNIT_CURRENT_ROW_POINTER',rid)
facts=json.loads((P/'manufacturer_facts.json').read_text())
for rid,correction in M['corrected_manufacturer_records'].items():
    for h,v in correction['fields'].items():check(RO.eq(pv[rid].get(h),v),'MANUFACTURER_PUBLICATION_FIELD',(rid,h))
    for source,dest in [('Length Source','Length mm'),('Width Source','Width mm'),('Depth Source','Depth mm'),('Weight Source','Weight kg')]:check(RO.eq(pv[rid].get(source),unit[rid].get(dest)),'PUBLISHED_DIMENSION_UNIT_MATCH',(rid,source))
flags=json.loads((P.parent/'db11/reviews/plan_validation/guard_patch.json').read_text())['source_review']
decisions=json.loads((P/'record_decisions.json').read_text());ds={d['record_id']:d for d in decisions[:95]}
check(Counter(d['outcome'] for d in decisions[:95])==Counter(M['original_electrical_flag_outcomes']),'ALL_ORIGINAL_FLAG_DISPOSITIONS')
for q in flags:
    rid=q['record_id'];d=ds[rid]
    if d['outcome']=='NO_SAFE_REPLACEMENT_AUTHENTICATED':
        for h in q['withheld_fields']:check(pv[rid].get(h) is None,'UNRESOLVED_ELECTRICAL_VALUE_WITHHELD',(rid,h))
        check(unit[rid]['Audit State']=='ELECTRICAL_CONSISTENCY_REVIEW_REQUIRED','UNRESOLVED_ELECTRICAL_GATE',rid)
for d in decisions[95:]:check(unit[d['record_id']]['Audit State']=='CONFIGURATION_IDENTITY_REVIEW_REQUIRED','REPEATED_NAME_VARIANT_GATE',d['record_id'])
for rid,r in pv.items():
    v,i,p,vo,sc=[r.get(h) for h in ['Vmp (V)','Imp (A)','Pmp (W)','Voc (V)','Isc (A)']]
    if all(isinstance(x,(int,float)) and x>0 for x in [v,i,p]):
        tolerance=.1 if rid=='DB11-PV-04822' else .05
        check(abs(v*i/p-1)<=tolerance+1e-10,'PV_POWER_PRODUCT_OR_SCOPED_TOLERANCE',rid)
    if all(isinstance(x,(int,float)) and x>0 for x in [v,vo]):check(v<vo,'PV_VOLTAGE_ORDER',rid)
    if all(isinstance(x,(int,float)) and x>0 for x in [i,sc]):check(i<=sc*1.02,'PV_CURRENT_ORDER',rid)
slim=pv['DB11-PV-04822'];check(unit['DB11-PV-04822']['Audit State']=='MANUFACTURER_NOMINAL_TOLERANCE_SCOPED' and slim['Pmp (W)']==65 and .05<abs(slim['Vmp (V)']*slim['Imp (A)']/65-1)<.1,'EXPLICIT_MIDSUMMER_PUBLICATION_EXCEPTION')

originals=json.loads((P/'DB12_Original_Records.json').read_text());history=records['EQUIPMENT_RECORD_HISTORY'];oldrecords={s:{r['Record ID']:r for _,r,_ in oldbook.table(s)} for s in ['PV_MODULES','PV_UNIT_REVIEW','IBR']}
check(len(history)==len({r['Former Record ID'] for r in history})==33,'UNIQUE_HISTORY_IDENTITIES')
for h in history:
    rid=h['Former Record ID'];sh=h['Canonical Table'];proof=originals[rid]
    check(rid not in all_ids[sh] and h['Canonical Record ID'] in all_ids[sh],'HISTORY_CANONICAL_TARGET',rid)
    check(proof['record']==oldrecords[sh][rid],'ORIGINAL_HISTORY_RECORD_PRESERVED',rid)
    fingerprint=hashlib.sha256(json.dumps(proof['record'],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    check(fingerprint==h['Original Record SHA256'],'HISTORY_RECORD_HASH',rid)
    if sh=='PV_MODULES':check(proof['paired_unit_review']['record']==oldrecords['PV_UNIT_REVIEW'][rid],'ORIGINAL_PAIRED_UNIT_HISTORY',rid)

for r in records['CEC_LISTING_LINKS']:
    sh=r['Primary Table'];rid=r.get('Primary Record ID')
    if rid:check(rid in all_ids.get(sh,set()),'CEC_PRIMARY_FOREIGN_KEY',(sh,rid))
    if rid in M['corrected_manufacturer_records']:
        qualification=M['corrected_manufacturer_records'][rid]
        scopes=json.loads(r['Scope'])
        check(any(s.get('code')=='PRIMARY_MANUFACTURER_PUBLICATION_SCOPE' and s.get('source_id')==qualification['source_id'] and s.get('revision')==qualification['revision'] for s in scopes if isinstance(s,dict)),'CEC_LINK_MANUFACTURER_OVERRIDE_QUALIFIED',rid)
    for candidate in str(r.get('Candidate Existing IDs') or '').split(';'):
        candidate=candidate.strip()
        if candidate:check(candidate not in M['aliases'],'NO_MOVED_ALIAS_IN_OPERATIONAL_CANDIDATES',candidate)
check(len(registry_ids)==55018 and max(registry_ids.values())==1,'UNIQUE_RAW_CEC_REGISTRY_IDENTITIES')
link_ids=[r['Registry Record ID'] for r in records['CEC_LISTING_LINKS']]
check(len(link_ids)==len(set(link_ids))==55018 and set(link_ids)==set(registry_ids),'EVERY_CEC_LISTING_HAS_ONE_OPERATIONAL_LINK')
raw_names={'CEC_PV_ACTIVE','CEC_PV_ARCHIVE','CEC_SOLAR_INVERTERS','CEC_BATTERY_INVERTERS','CEC_INVERTER_ARCHIVE','CEC_BATTERIES','CEC_BATTERY_ARCHIVE','CEC_ENERGY_STORAGE','CEC_METERS','CEC_LEGACY_PCS','CEC_POWER_CONTROL','CEC_PMRS','CEC_PMRS_HISTORICAL','CEC_V2G'}
for sh in raw_names|{'CEC_FIELD_MAP','CEC_SOURCE_NOTES','CEC_IMPORT_INDEX'}:check(oldbook.z.read(oldbook.sheets[sh])==book.z.read(book.sheets[sh]),'RAW_CEC_AND_SOURCE_METADATA_BYTE_IDENTICAL',sh)
check(sum(counts[s] for s in raw_names)==55018,'CEC_LISTING_TOTAL');check(counts['CEC_FIELD_MAP']==410,'CEC_NATIVE_FIELD_TOTAL')
for r in records['CEC_FILE_RECONCILIATION']:check(r['User File Comparison Status']=='AWAITING_USER_CEC_EXPORT' and r.get('User Supplied Filename') is None and r.get('User File SHA256') is None,'ABSENT_USER_CEC_FILES_NOT_CLAIMED',r['Original CEC Filename'])
source_ids={r['Source ID'] for r in records['SOURCE_REGISTER']}
for c in M['corrected_manufacturer_records'].values():check(c['source_id'] in source_ids,'SOURCE_REGISTER_FOREIGN_KEY',c['source_id'])
for manifest in sorted(P.glob('download_batch_*_results.json')):
    for s in json.loads(manifest.read_text()):
        if s.get('status')=='DOWNLOADED':
            check(digest(s['path'])==s['sha256'],'DOWNLOADED_MANUFACTURER_PUBLICATION_HASH',s['id'])
            check(Path(s['path']).read_bytes().startswith(b'%PDF-'),'ORIGINAL_PUBLICATION_PDF_HEADER',s['id'])
for s in json.loads((P.parent/'db11/cec_sources/source_inventory.json').read_text()):check(digest(s['file'])==s['sha256'],'ORIGINAL_CEC_EXPORT_FILE_HASH',s['id'])

result={'status':'PASS' if not checks.failures else 'FAIL','sha256':digest(DST),'parent_sha256':digest(SRC),'worksheets':117,'native_tables':116,'total_nonempty_data_audit_reference_rows':sum(counts.values()),'header_fields':sum(map(len,headers.values())),'formulas_preserved':formula_count,'cached_excel_errors':error_count,'original_unplanned_cells_xml_checked':unplanned_cells,'unchanged_package_parts':unchanged_parts,'manufacturer_scoped_PV_records':16,'historical_records':33,'original_flag_outcomes':M['original_electrical_flag_outcomes'],'CEC_raw_listings':55018,'CEC_native_fields':410,'CEC_user_comparison':'AWAITING_USER_CEC_EXPORT','identity_tables_scanned':len(duplicate_summary),'duplicate_scan':duplicate_summary,'counts':counts,'limits':['Exact typed-specification and record-ID scans do not prove the absence of all semantic or cross-vendor duplicates.','76 original electrical records remain withheld; 15 repeated-name configuration claims remain unqualified.','Publication-specific manufacturer claims were checked against their exact documents; physical product certification and whole-catalogue manufacturer authentication are not claimed.','User-supplied CEC downloads have not been received; no comparison with those copies is claimed.','Original formula text and caches were preserved. Microsoft Excel application recalculation was not available.'],**checks.output()}
(P/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));oldbook.close();book.close()
print(json.dumps({k:result[k] for k in ['status','sha256','check_executions','failed_executions','worksheets','native_tables','formulas_preserved','cached_excel_errors','original_unplanned_cells_xml_checked','identity_tables_scanned']},ensure_ascii=False),flush=True)
assert result['status']=='PASS',result['failure_examples']
