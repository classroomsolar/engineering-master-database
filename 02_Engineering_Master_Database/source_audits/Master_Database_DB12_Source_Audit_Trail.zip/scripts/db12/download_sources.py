"""Fetch observed original-publication URLs and retain hashes for curation."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request, json, hashlib, sys, subprocess, shutil

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'source_documents'
OUT.mkdir(exist_ok=True)
specs = json.loads(Path(sys.argv[1]).read_text())

def fetch(s):
    p = OUT / (s['id'] + '.pdf')
    try:
        if p.exists() and p.read_bytes().startswith(b'%PDF'):
            b = p.read_bytes()
            info = {'reused_download': True}
        else:
            req = urllib.request.Request(s['url'], headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=35) as r:
                b = r.read(25 * 1024 * 1024)
                info = {'http_status': r.status, 'final_url': r.url, 'content_type': r.headers.get('Content-Type')}
            if not b.startswith(b'%PDF'):
                return {**s, **info, 'status': 'NOT_PDF', 'bytes': len(b)}
            p.write_bytes(b)
        if shutil.which('pdftotext'):
            subprocess.run(['pdftotext', '-layout', str(p), str(p.with_suffix('.txt'))], check=True, capture_output=True, timeout=30)
        else:
            from pypdf import PdfReader
            p.with_suffix('.txt').write_text('\n\f\n'.join(x.extract_text() or '' for x in PdfReader(p).pages))
        return {**s, **info, 'status': 'DOWNLOADED', 'path': str(p), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
    except Exception as e:
        return {**s, 'status': 'FAILED', 'error': type(e).__name__ + ': ' + str(e)}

with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(fetch, specs))
target = ROOT / (Path(sys.argv[1]).stem + '_results.json')
target.write_text(json.dumps(results, ensure_ascii=False, indent=2))
for r in results:
    print(json.dumps({k: v for k, v in r.items() if k not in ['url', 'final_url', 'path', 'description']}), flush=True)
