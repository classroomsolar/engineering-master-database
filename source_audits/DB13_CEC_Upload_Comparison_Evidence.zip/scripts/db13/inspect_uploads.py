"""Read uploaded CEC workbooks as inert OOXML; no workbook authoring."""
from pathlib import Path
import hashlib,importlib.util,json
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('reader',P.parent/'db11/reviews/storage/verify_release_storage.py')
R=importlib.util.module_from_spec(spec);spec.loader.exec_module(R)
items=[]
for path in sorted((P.parents[1]/'upload').glob('*')):
    if path.suffix.lower() not in {'.xlsx','.xlsm'}:continue
    book=R.Book(path);sheets=[]
    for name in book.sheets:
        preview=[];n=0;last=0
        for nr,cells,formulas in book.rows(name):
            if not cells:continue
            n+=1;last=nr
            if len(preview)<22:preview.append({'row':nr,'values':{k:v if not isinstance(v,str) else v[:220] for k,v in cells.items()}})
        sheets.append({'name':name,'nonempty_rows':n,'last_row':last,'preview':preview})
    item={'filename':path.name,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'sheets':sheets}
    items.append(item);book.close()
    print(json.dumps({'file':path.name,'sha256':item['sha256'],'sheets':[{'name':x['name'],'nonempty_rows':x['nonempty_rows'],'last_row':x['last_row']} for x in sheets]}),flush=True)
(P/'upload_inventory.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
