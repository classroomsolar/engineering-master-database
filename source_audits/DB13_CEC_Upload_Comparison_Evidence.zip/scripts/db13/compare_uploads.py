"""Compare every uploaded CEC listing field with current native master records."""
from pathlib import Path
from collections import defaultdict,deque,Counter
from itertools import zip_longest
import hashlib,importlib.util,json,sys
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('reader',P.parent/'db11/reviews/storage/verify_release_storage.py')
R=importlib.util.module_from_spec(spec);spec.loader.exec_module(R)
MASTER=Path(sys.argv[1]) if len(sys.argv)>1 else P/'recovered/Engineering_Master_Database_Audited.xlsx'
SOURCE=P/'prior_evidence/cec_original_exports'
book=R.Book(MASTER);checks=R.Checks();test=checks.test
inventory=json.loads((P/'upload_inventory.json').read_text())
ledger_headers=list(next(book.rows('CEC_FILE_RECONCILIATION'))[1].values())
ledger={'headers':ledger_headers,'rows':[[r.get(h) for h in ledger_headers] for _,r,_ in book.table('CEC_FILE_RECONCILIATION')]}
maps=defaultdict(list)
for _,r,_ in book.table('CEC_FIELD_MAP'):maps[r['Master CEC Table']].append(r)
source_meta={}
for table,fields in maps.items():
    ds={f['Source Dataset'] for f in fields};sh={f['Source Worksheet'] for f in fields}
    assert len(ds)==len(sh)==1
    source_meta[table]={'dataset':next(iter(ds)),'worksheet':next(iter(sh)),'fields':len(fields)}
original_inventory=json.loads((P.parent/'db11/cec_sources/source_inventory.json').read_text())
original_by_ds={s['id']:s for s in original_inventory}
source_matches={};by_hash=defaultdict(list)
for item in inventory:by_hash[item['sha256']].append(item['filename'])

def typed(v):
    if v is None or v=='':return ('blank',None)
    if isinstance(v,bool):return ('boolean',v)
    if isinstance(v,(int,float)):return ('number',float(v))
    return ('text',v)
raw={};match_index={}
for table in maps:
    raw[table]=[r for _,r,_ in book.table(table)]
    fields=maps[table];index=defaultdict(list)
    for r in raw[table]:index[tuple(typed(r.get(f['CEC Field Name'])) for f in fields)].append(r)
    match_index[table]=index
links={r['Registry Record ID']:r for _,r,_ in book.table('CEC_LISTING_LINKS')}
report=[];new_rows=[];different_rows=[];all_registry_ids=set();unique_field_comparisons=0;table_counts=Counter();seen_hashes=set();existing_withheld={}
for item in inventory:
    duplicate=item['sha256'] in seen_hashes;seen_hashes.add(item['sha256'])
    upload=R.Book(item['path']);sheet_results=[];matched_tables=[];matched_datasets=[];non_equipment=[]
    for sheet in upload.sheets:
        candidates=[t for t,m in source_meta.items() if m['worksheet']==sheet]
        if not candidates:non_equipment.append(sheet);continue
        assert len(candidates)==1,(item['filename'],sheet,candidates)
        table=candidates[0];fields=maps[table];matched_tables.append(table);matched_datasets.append(source_meta[table]['dataset'])
        available={k:deque(v) for k,v in match_index[table].items()}
        found=compared=0;used=set();missing=[]
        for nr,cells,_ in R.native_records(upload,sheet,R.RAW_LAYOUT[table]):
            sig=tuple(typed(cells.get(f['Source Column'])) for f in fields)
            while available.get(sig) and available[sig][0]['Registry Record ID'] in used:available[sig].popleft()
            if available.get(sig):row=available[sig].popleft()
            else:
                # A changed order, blank representation or floating-point encoding
                # must not turn an existing model into a new equipment record.
                row=next((r for r in raw[table] if r['Registry Record ID'] not in used and all(R.eq(r.get(f['CEC Field Name']),cells.get(f['Source Column'])) for f in fields)),None)
            if row is None:
                keycols=R.RAW_LAYOUT[table][1:3]
                identity=[cells.get(c) for c in keycols if c]
                same_identity=[r for r in raw[table] if all(R.eq(r.get(next(f['CEC Field Name'] for f in fields if f['Source Column']==c)),cells.get(c)) for c in keycols if c)]
                exception={'file':item['filename'],'worksheet':sheet,'excel_row':nr,'table':table,'identity':identity,'cells':cells,'same_identity_candidates':[r['Registry Record ID'] for r in same_identity]}
                (different_rows if same_identity else new_rows).append(exception);missing.append(nr);continue
            rid=row['Registry Record ID'];used.add(rid);found+=1
            for f in fields:
                compared+=1;test(R.eq(row.get(f['CEC Field Name']),cells.get(f['Source Column'])),'UPLOADED_NATIVE_FIELD_MATCH',(item['filename'],sheet,nr,f['CEC Field Name']))
            test(rid in links,'EXISTING_LISTING_LINK',rid)
            link=links[rid]
            if link['Primary Record ID'] is None:
                candidates=[x.strip() for x in (link.get('Candidate Existing IDs') or '').split(';') if x.strip()]
                test(link['Disposition'] in {'WITHHELD_MANUFACTURER_IDENTITY_REVIEW','WITHHELD_EXISTING_VARIANT_REVIEW','AMBIGUOUS_EXISTING'} and bool(candidates),'EXPLICIT_EXISTING_IDENTITY_REVIEW_WITH_CANDIDATES',rid)
                if not duplicate:existing_withheld[rid]={'table':link['Primary Table'],'disposition':link['Disposition'],'candidate_ids':candidates}
            if not duplicate:all_registry_ids.add(rid)
        source_count=found+len(missing)
        test(len(used)==found,'NO_REUSED_EXISTING_LISTING_WITHIN_INPUT',(item['filename'],table))
        test(source_count==len(raw[table]),'SUPPLIED_LISTING_TABLE_COMPLETE',(item['filename'],table,source_count,len(raw[table])))
        if not duplicate:unique_field_comparisons+=compared;table_counts[table]+=source_count
        sheet_results.append({'worksheet':sheet,'master_table':table,'dataset':source_meta[table]['dataset'],'listings':source_count,'already_present_exact_fields':found,'field_comparisons':compared,'missing_or_changed_rows':missing,'native_fields':len(fields)})
    test(bool(sheet_results),'FILE_HAS_RECOGNIZED_EQUIPMENT_LIST',item['filename'])
    assert len(set(matched_datasets))==1,(item['filename'],matched_datasets)
    ds=matched_datasets[0];original=original_by_ds[ds];original_file=SOURCE/Path(original['file']).name
    assert hashlib.sha256(original_file.read_bytes()).hexdigest()==original['sha256']
    original_book=R.Book(original_file);header_differences=[]
    for sr in sheet_results:
        t=sr['master_table'];start=R.RAW_LAYOUT[t][0];sh=sr['worksheet']
        before={nr:cs for nr,cs,_ in original_book.rows(sh) if nr<start}
        after={nr:cs for nr,cs,_ in upload.rows(sh) if nr<start}
        for nr in sorted(set(before)|set(after)):
            for cc in sorted(set(before.get(nr,{}))|set(after.get(nr,{}))):
                a=before.get(nr,{}).get(cc);b=after.get(nr,{}).get(cc)
                if not R.eq(a,b):header_differences.append({'sheet':sh,'cell':cc+str(nr),'original':a,'uploaded':b})
    original_book.close();upload.close()
    status='DUPLICATE_UPLOAD_ALREADY_COVERED' if duplicate else 'ALL_LISTINGS_AND_FIELDS_ALREADY_PRESENT'
    if any(s['missing_or_changed_rows'] for s in sheet_results):status='SOURCE_DIFFERENCES_REQUIRE_RECONCILIATION'
    report.append({'filename':item['filename'],'path':item['path'],'sha256':item['sha256'],'bytes':item['bytes'],'duplicate_input':duplicate,'same_content_uploads':by_hash[item['sha256']],'source_dataset':ds,'original_filename':original_file.name,'original_sha256':original['sha256'],'byte_identical_to_original':item['sha256']==original['sha256'],'status':status,'tables':sheet_results,'reference_worksheets_not_imported_as_equipment':non_equipment,'header_differences':header_differences})
    print(json.dumps({'file':item['filename'],'status':status,'listings':sum(s['listings'] for s in sheet_results),'tables':matched_tables,'original_file':original_file.name,'byte_identical':item['sha256']==original['sha256']}),flush=True)

# Validate actual primary targets once for all matched registry references.
target_ids=defaultdict(set)
for rid in all_registry_ids:
    r=links[rid]
    if r['Primary Record ID'] is not None:target_ids[r['Primary Table']].add(r['Primary Record ID'])
    else:target_ids[r['Primary Table']].update(existing_withheld[rid]['candidate_ids'])
for table,wanted in target_ids.items():
    actual=set()
    for _,r,_ in book.table(table):
        value=r.get('Record ID') or r.get('IBR ID') or r.get('Equipment Record ID')
        if value:actual.add(value)
    test(wanted<=actual,'ALL_CURRENT_PRIMARY_TARGETS_EXIST',(table,sorted(wanted-actual)[:10]))

# Derive source-file categories from actual CEC_FIELD_MAP dataset identities.
# Do not infer category from an ambiguous exported filename.
correct_ledger=[];ledger_repairs=[]
for old in ledger['rows']:
    r=dict(zip(ledger['headers'],old));ds=next(s['id'] for s in original_inventory if Path(s['file']).name==r['Original CEC Filename'])
    tables=[t for t,m in source_meta.items() if m['dataset']==ds]
    if tables:
        desired={'Native Master Tables':'; '.join(tables),'Imported Listing Rows':sum(len(raw[t]) for t in tables),'Native Fields':sum(len(maps[t]) for t in tables)}
        for h,v in desired.items():
            if h=='Native Master Tables' and set(str(r[h]).split('; '))==set(tables):continue
            if r[h]!=v:ledger_repairs.append({'file':r['Original CEC Filename'],'field':h,'before':r[h],'after':v});r[h]=v
    correct_ledger.append(r)

test(len(all_registry_ids)==sum(table_counts.values()),'ALL_UNIQUE_SUPPLIED_LISTINGS_MATCH_DISTINCT_REGISTRY_IDS')
result={'status':'PASS' if not checks.failures and not new_rows and not different_rows else 'RECONCILIATION_REQUIRED','master_sha256':hashlib.sha256(MASTER.read_bytes()).hexdigest(),'files':report,'files_received':len(report),'unique_file_contents':len(seen_hashes),'duplicate_input_files':len(report)-len(seen_hashes),'unique_listing_memberships_compared':sum(table_counts.values()),'unique_native_fields_compared':sum(len(maps[t]) for t in table_counts),'field_comparisons_excluding_duplicate_upload':unique_field_comparisons,'matched_registry_ids':len(all_registry_ids),'categories':dict(table_counts),'new_equipment_rows':new_rows,'changed_source_rows':different_rows,'existing_withheld_links':existing_withheld,'existing_withheld_link_counts':dict(Counter(x['disposition'] for x in existing_withheld.values())),'correct_source_ledger':correct_ledger,'source_ledger_repairs':ledger_repairs,**checks.output()}
output=Path(sys.argv[2]) if len(sys.argv)>2 else P/'comparison.json'
output.write_text(json.dumps(result,ensure_ascii=False,indent=2));book.close()
print(json.dumps({k:result[k] for k in ['status','files_received','unique_file_contents','duplicate_input_files','unique_listing_memberships_compared','unique_native_fields_compared','field_comparisons_excluding_duplicate_upload','failed_executions','categories','source_ledger_repairs']}),flush=True)
