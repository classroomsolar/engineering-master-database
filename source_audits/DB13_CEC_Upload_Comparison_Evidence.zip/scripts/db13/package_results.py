"""Create a concise comparison report and an auditable proof bundle."""
from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parent;O=P/'outputs'
C=json.loads((P/'final_comparison.json').read_text());V=json.loads((P/'validation.json').read_text());A=json.loads((P/'assembly_result.json').read_text())
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert C['status']==V['status']=='PASS' and V['master_sha256']==C['master_sha256']==digest(A['output']) and V['failed_executions']==0
identities=json.loads((P/'upload_library_identities.json').read_text());rows=[]
for f in C['files']:
    count=sum(t['listings'] for t in f['tables']);tables=', '.join(t['master_table'] for t in f['tables'])
    result='Duplicate copy of Grid Support (1); no additional import' if f['duplicate_input'] else 'All listing fields already present; no addition'
    source=f"[{f['filename']}](https://chatgpt.com/library?file_id={identities[f['filename']]}&account_id=personal)"
    rows.append(f'| {source} | {count:,} | {tables} | {result} |')
report=f'''# CEC uploaded-file comparison — 26 October 2026

All 10 uploaded files have been checked against the current master. Their 9 unique file contents contain 32,295 listing memberships across 10 native CEC tables. Every supplied listing and native field value is already present. **No equipment records were added or changed.**

| Uploaded file | Listing rows in file | Existing category | Result |
| --- | ---: | --- | --- |
{chr(10).join(rows)}

The Grid Support (1) and (2) files have the same SHA-256, so the second copy is not counted again. The 32,295 total excludes that duplicate upload. These are registry memberships, not a count of unique physical installations or equipment assemblies.

## What was checked

- 845,792 native field values across the 9 unique input contents, with all 313 native fields in the supplied categories covered. The second identical Grid Support file was also recognized and compared.
- Full listing coverage by native source rows, one-to-one matches to distinct existing registry IDs, and existing primary records or explicit candidate-ID review states.
- No missing listing rows and no changed listing values. The supplied listing headers also match the corresponding original exports.
- File names and hashes are recorded in CEC_FILE_RECONCILIATION. Data_Key, Dropdown and other reference worksheets were not imported as equipment.

Five unique input files are byte-identical to the original exports already used by the master. Four have different file hashes, while their listing headers and native equipment values still match. A different file hash alone was not treated as new equipment.

## Corrected source-file mapping

The earlier comparison ledger had two PCS source-file mappings swapped. The native equipment tables were already categorized correctly. The ledger now follows actual source dataset and worksheet identities:

| Original source file | Correct native category | Listing rows | Native fields |
| --- | --- | ---: | ---: |
| PowerControlSystem.xlsx | CEC_LEGACY_PCS | 1,715 | 23 |
| CurrentPCS.xlsx | CEC_POWER_CONTROL | 103 | 20 |

The uploaded Inverter_and_Energy_Storage_System_PCS_List_ADA file matches the legacy PCS source. The uploaded Power_Control_System_List_ADA file matches the current PCS source. No equipment records were moved or duplicated for this correction.

## Preserved review boundaries

{len(C['existing_withheld_links'])} matched registry listings already have explicit manufacturer/variant ambiguity dispositions. Their existing candidate IDs were verified and their review states preserved. Finding the listing in a source table does not resolve those physical-model identities. The existing electrical and manufacturer-publication qualifications also remain in place.

This batch did not include the active PV-module export, V2G export or PMRS export. It also did not include a separate simplified inverter archive; the full inverter archive was supplied and checked. Those distinctions are recorded in the existing file ledger. They do not represent missing entries found in the supplied files.

## Saved-master verification

The update changes comparison/audit metadata only: 85 authored cells and 3 appended audit rows. All equipment tables, raw CEC tables, listing links, model groups, source definitions and unrelated package members are byte-identical to the previous master. All 53,117 original formulas and their stored results are preserved.

The saved master was compared again against the uploads, and the independent preservation checks passed with zero failed checks. It retains 117 worksheets, 116 native tables, all 55,018 original CEC listings and 411,285 data/reference/audit rows. The last figure is not an equipment count.

Master SHA-256: `{V['master_sha256']}`  
Parent master SHA-256: `{V['parent_sha256']}`

The evidence ZIP contains the comparison results, input identities/hashes, exact audit changes, preservation results, render samples and the scripts used. Uploaded source files remain unchanged.
'''
path=O/'DB13_CEC_Upload_Comparison_2026-10-26.md';path.write_text(report)
bundle=O/'DB13_CEC_Upload_Comparison_Evidence.zip';tmp=O/'Comparison_Evidence_Packaging.zip'
evidence=['comparison.json','final_comparison.json','manifest.json','change_evidence.json','validation.json','assembly_result.json','upload_inventory.json','upload_library_identities.json','visual_review.json']
scripts=['inspect_uploads.py','compare_uploads.py','prepare_update.py','assemble_master.py','verify_release.py','package_results.py']
with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(path,'Comparison_Report.md')
    for f in evidence:z.write(P/f,'evidence/'+f)
    for f in scripts:z.write(P/f,'scripts/db13/'+f)
    z.write('/tmp/2b67ca9a1d0b_db13_artifact/artifact_builder.mjs','scripts/db13/artifact_builder.mjs')
    z.write(P.parent/'db11/package_helpers.py','scripts/db11/package_helpers.py')
    z.write(P.parent/'db11/reviews/storage/verify_release_storage.py','scripts/db11/reviews/storage/verify_release_storage.py')
    for f in P.glob('previews/after_*.png'):z.write(f,'visual_samples/'+f.name)
    z.writestr('README.txt','Read Comparison_Report.md first. The updated master is supplied separately. Equipment and raw CEC records are unchanged. Source file identities and hashes are included; source workbooks are already the user uploads and are not re-imported. Reproduction uses the validated parent master, uploaded files, original CEC exports from the prior DB12 evidence bundle, and the bundled Codex primary runtime.\n')
with zipfile.ZipFile(tmp) as z:assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
tmp.replace(bundle)
out={'master':A['output'],'master_sha256':V['master_sha256'],'report':str(path),'report_sha256':digest(path),'evidence':str(bundle),'evidence_sha256':digest(bundle),'equipment_added':0}
(P/'delivery_manifest.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
