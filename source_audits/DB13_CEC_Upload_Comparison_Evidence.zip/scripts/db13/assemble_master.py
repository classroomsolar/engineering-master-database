"""Apply verified Artifact-authored audit values; preserve equipment parts exactly."""
from pathlib import Path
from collections import defaultdict
import hashlib,html,importlib.util,json,posixpath,re,zipfile
from xml.sax.saxutils import escape,quoteattr
from lxml import etree as E
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('helpers',P.parent/'db11/package_helpers.py')
H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)
M=json.loads((P/'manifest.json').read_text());I=json.loads((P/'authored/artifact_index.json').read_text())
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(M['parent'])==M['parent_sha256'] and digest(P/'manifest.json')==I['manifest_sha256'] and digest(I['output'])==I['output_sha256']
for f,sha in M['proof_files'].items():assert digest(P/f)==sha
auth=defaultdict(dict)
with zipfile.ZipFile(I['output']) as z:
    ss=[''.join(t.itertext()) for t in E.fromstring(z.read('xl/sharedStrings.xml'))] if 'xl/sharedStrings.xml' in z.namelist() else []
    rels={r.get('Id'):r.get('Target') for r in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    paths={s.get('name'):(rels[s.get('{'+H.REL+'}id')].lstrip('/') if rels[s.get('{'+H.REL+'}id')].startswith('/') else posixpath.normpath('xl/'+rels[s.get('{'+H.REL+'}id')])) for s in E.fromstring(z.read('xl/workbook.xml')).find('s:sheets',H.N)}
    for entry in I['patches']:
        sh=entry['sheet'];o=M['sheets'][sh];rowmap={r:i+2 for i,r in enumerate(entry['original_rows'])}
        rt=E.fromstring(z.read(paths[sh]));cells={c.get('r'):H.value(c,ss) for c in rt.findall('s:sheetData/s:row/s:c',H.N)}
        for a,v in o['cells'].items():
            local=re.sub(r'\d+$',str(rowmap[int(re.search(r'\d+$',a)[0])]),a);actual=cells.get(local)
            if isinstance(v,str) and actual=="'"+v and (v.startswith('=') or re.match(r'\d{4}-\d{2}-\d{2}T',v)):actual=v
            assert actual==v or actual is None and v=='',(sh,a,actual,v)
            auth[sh][a]=actual
        assert len(auth[sh])==len(o['cells'])

ROWS=re.compile(r'<(?P<q>(?:[\w.-]+:)?row)\b(?P<a>[^>]*?)(?:\s*/>|>(?P<b>.*?)</(?P=q)>)',re.S)
CELLS=re.compile(r'<(?P<q>(?:[\w.-]+:)?c)\b(?P<a>[^>]*?)(?:\s*/>|>(?P<b>.*?)</(?P=q)>)',re.S)
def patch(raw,o,values):
    prefix=re.search(r'<((?:[\w.-]+:)?)(?:worksheet)\b',raw)[1];tag=lambda t:prefix+t
    sd=re.search(r'<((?:[\w.-]+:)?sheetData)\b[^>]*>(.*?)</\1>',raw,re.S);assert sd
    byrow=defaultdict(dict)
    for a,v in values.items():byrow[int(re.search(r'\d+$',a)[0])][a]=v
    existing=list(ROWS.finditer(sd[2]));template={H.ci(H.attrs(c['a'])['r']):H.attrs(c['a']) for c in CELLS.finditer(existing[-1]['b'] or '')}
    seen=set()
    def make(a,v,old=None):
        at=H.attrs(old['a']) if old else {'r':a,'s':template.get(H.ci(a),{}).get('s','5')}
        at.pop('t',None);at['r']=a
        if v is None:body=''
        elif isinstance(v,str):at['t']='inlineStr';body=f'<{tag("is")}><{tag("t")} xml:space="preserve">{escape(v)}</{tag("t")}></{tag("is")}>'
        elif isinstance(v,bool):at['t']='b';body=f'<{tag("v")}>{int(v)}</{tag("v")}>'
        else:body=f'<{tag("v")}>{repr(v)}</{tag("v")}>'
        return '<'+tag('c')+' '+' '.join(k+'='+quoteattr(html.unescape(x)) for k,x in at.items())+'>'+body+'</'+tag('c')+'>'
    def edit(rm):
        nr=int(H.attrs(rm['a'])['r']);seen.add(nr);todo=dict(byrow.get(nr,{}))
        if not todo:return rm[0]
        body=rm['b'] or '';out=[];pos=0
        for cm in CELLS.finditer(body):
            a=H.attrs(cm['a'])['r'];out.append(body[pos:cm.start()])
            for na in sorted([x for x in todo if H.ci(x)<H.ci(a)],key=H.ci):out.append(make(na,todo.pop(na)))
            out.append(make(a,todo.pop(a),cm) if a in todo else cm[0]);pos=cm.end()
        out.append(body[pos:]);out.extend(make(a,todo[a]) for a in sorted(todo,key=H.ci))
        at=rm['a']
        if str(nr) in o['row_heights']:
            at=re.sub(r'\s(?:ht|customHeight)="[^"]*"','',at)+' ht="'+str(o['row_heights'][str(nr)])+'" customHeight="1"'
        return '<'+rm['q']+at+'>'+''.join(out)+'</'+rm['q']+'>'
    body=ROWS.sub(edit,sd[2])
    for nr in sorted(set(byrow)-seen):
        assert nr>o['old_last_row'];ht=o['row_heights'].get(str(nr),48)
        body+='<'+tag('row')+f' r="{nr}" ht="{ht}" customHeight="1">'+''.join(make(a,byrow[nr][a]) for a in sorted(byrow[nr],key=H.ci))+'</'+tag('row')+'>'
    raw=raw[:sd.start(2)]+body+raw[sd.end(2):]
    return re.sub(r'(<(?:[\w.-]+:)?dimension\b[^>]*\bref=")[^"]+(\")',lambda m:m[1]+o['new_ref']+m[2],raw,count=1).encode()

dst=P/'outputs/Engineering_Master_Database_Audited.xlsx';dst.parent.mkdir(exist_ok=True);tmp=dst.with_name('Master_Audit_Update_Packaging.xlsx')
changed={o['path']:(s,o) for s,o in M['sheets'].items()};tables={o['table_path']:o for o in M['sheets'].values()}
with zipfile.ZipFile(M['parent']) as before,zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as after:
    for part in before.infolist():
        data=before.read(part.filename)
        if part.filename in changed:
            sh,o=changed[part.filename];data=patch(data.decode(),o,auth[sh])
        elif part.filename in tables:
            o=tables[part.filename];data=H.change_table(data.decode(),{'old_ref':o['old_ref'],'new_ref':o['new_ref'],'headers':o.get('table_header_renames',{})}).encode()
        after.writestr(part,data)
with zipfile.ZipFile(tmp) as z:assert z.testzip() is None
tmp.replace(dst)
result={'output':str(dst),'sha256':digest(dst),'parent_sha256':M['parent_sha256'],'manifest_sha256':digest(P/'manifest.json'),'artifact_cells_verified':sum(len(v) for v in auth.values()),'equipment_added':0}
(P/'assembly_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
