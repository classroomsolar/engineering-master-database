import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {Workbook,SpreadsheetFile,FileBlob} from '@oai/artifact-tool';
const mode=process.argv[2],root=path.resolve(process.argv[3]);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const safe=v=>typeof v==='string'&&(v.startsWith('=')||/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:/.test(v))?`'${v}`:v;
const ci=a=>[...a.match(/^[A-Z]+/)[0]].reduce((n,c)=>n*26+c.charCodeAt(0)-64,0);
if(mode==='author'){
 const raw=await fs.readFile(path.join(root,'manifest.json')),m=JSON.parse(raw),w=Workbook.create(),patches=[];
 for(const [name,o] of Object.entries(m.sheets)){
  const s=w.worksheets.add(name),rows=[...new Set(Object.keys(o.cells).map(a=>Number(a.match(/\d+$/)[0])))].sort((a,b)=>a-b),rowMap=new Map(rows.map((r,i)=>[r,i+2]));
  const matrix=rows.map(()=>Array(o.headers.length).fill(null));
  for(const [a,v] of Object.entries(o.cells))matrix[rowMap.get(Number(a.match(/\d+$/)[0]))-2][ci(a)-1]=safe(v);
  s.getRange('A1').write([o.headers,...matrix]);patches.push({sheet:name,original_rows:rows,cells:Object.keys(o.cells).length});
 }
 w.recalculate();await fs.mkdir(path.join(root,'authored'),{recursive:true});
 const output=path.join(root,'authored/DB13_Artifact_Values.xlsx');await(await SpreadsheetFile.exportXlsx(w)).save(output);
 const result={manifest_sha256:hash(raw),output,output_sha256:hash(await fs.readFile(output)),patches};
 await fs.writeFile(path.join(root,'authored/artifact_index.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify({status:'AUTHORED',cells:patches.reduce((n,p)=>n+p.cells,0),sha256:result.output_sha256}));
}else if(mode==='render'){
 const spec=JSON.parse(await fs.readFile(process.argv[4],'utf8')),w=await SpreadsheetFile.importXlsx(await FileBlob.load(spec.input));await fs.mkdir(path.join(root,'previews'),{recursive:true});
 for(const v of spec.views){const b=await w.render({sheetName:v.sheet,range:v.range,scale:1,format:'png'});await fs.writeFile(path.join(root,'previews',v.name+'.png'),new Uint8Array(await b.arrayBuffer()));}
 await fs.writeFile(path.join(root,'previews',spec.tag+'_inspect.json'),JSON.stringify(await w.inspect({kind:'sheet',maxChars:2000}),null,2));
 console.log(JSON.stringify({status:'RENDERED',views:spec.views.map(v=>v.name)}));
}else throw Error('author|render');
