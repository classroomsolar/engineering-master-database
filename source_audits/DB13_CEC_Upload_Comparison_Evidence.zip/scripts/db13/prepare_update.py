"""Plan audit-only updates after full uploaded-list comparison; no XLSX edits."""
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import hashlib,importlib.util,json,math,posixpath,re,zipfile
from lxml import etree as E
P=Path(__file__).resolve().parent;DATE='2026-10-26'
spec=importlib.util.spec_from_file_location('reader',P.parent/'db11/reviews/storage/verify_release_storage.py')
R=importlib.util.module_from_spec(spec);spec.loader.exec_module(R)
SRC=P/'recovered/Engineering_Master_Database_Audited.xlsx';C=json.loads((P/'comparison.json').read_text())
assert C['status']=='PASS' and C['failed_executions']==0 and C['matched_registry_ids']==32295
assert not C['new_equipment_rows'] and not C['changed_source_rows']
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==C['master_sha256']
prior=json.loads((P/'prior_evidence/evidence/validation.json').read_text());counts=deepcopy(prior['counts'])
book=R.Book(SRC);names=['CEC_FILE_RECONCILIATION','AUDIT_README','REQUEST_AUDIT','CHANGE_LOG','SHEET_MAP','DATABASE_TABLE_INDEX','FIELD_AUDIT']
records={s:{nr:r for nr,r,_ in book.table(s)} for s in names};headers={s:list(next(book.rows(s))[1].values()) for s in names}
changes=defaultdict(dict);proof={};rowheights=defaultdict(dict)
def setv(s,n,h,v,why):
    assert h in headers[s]
    r=records[s][n];before=r.get(h)
    if R.eq(before,v) and type(before)==type(v):return
    a=R.col(headers[s].index(h)+1)+str(n)
    if s+'!'+a not in proof:proof[s+'!'+a]={'before':before,'reason':why}
    changes[s][a]=v;r[h]=v
def append(s,values,why):
    n=max(records[s])+1;records[s][n]={h:None for h in headers[s]}
    for h in headers[s]:setv(s,n,h,values.get(h),why)
    return n

files_by_original=defaultdict(list)
for f in C['files']:files_by_original[f['original_filename']].append(f)
repaired={r['Original CEC Filename']:r for r in C['correct_source_ledger']}
for n,r in records['CEC_FILE_RECONCILIATION'].items():
    original=r['Original CEC Filename'];correct=repaired[original]
    for h in ['Native Master Tables','Imported Listing Rows','Native Fields']:setv('CEC_FILE_RECONCILIATION',n,h,correct[h],'Derive source category from actual CEC field-map dataset and worksheet identity.')
    fs=files_by_original.get(original,[])
    if fs:
        hashes={f['sha256'] for f in fs};assert len(hashes)==1
        fn='\n'.join(f['filename'] for f in fs)
        status='MATCH_ALL_NATIVE_VALUES_DUPLICATE_COPY_IGNORED' if len(fs)>1 else 'MATCH_ALL_NATIVE_VALUES_ALREADY_PRESENT'
        for h,v in {'User Supplied Filename':fn,'User File SHA256':next(iter(hashes)),'User File Comparison Status':status}.items():setv('CEC_FILE_RECONCILIATION',n,h,v,'Record exact uploaded copies and completed native-field comparison; add no duplicate equipment.')
    elif original=='ArchivedInverterSimplified.xlsx':
        setv('CEC_FILE_RECONCILIATION',n,'User File Comparison Status','NOT_SUPPLIED_EQUIVALENT_FULL_ARCHIVE_CHECKED','A separate simplified copy was not supplied; its full archive listing data were compared.')

summary='10 uploaded files contain 9 unique file contents. All 32,295 listing memberships and 845,792 native field values match existing CEC records. No missing source rows, changed listing values or new equipment entries were found. One identical Grid Support upload is recorded once.'
boundary='The active PV module list, V2G list and PMRS list were not supplied in this batch. A separate simplified inverter archive was not supplied; the full archive was checked. Existing manufacturer, variant and electrical review flags remain.'
for n,r in records['AUDIT_README'].items():
    if r['Topic']=='Audit date':setv('AUDIT_README',n,'Details',DATE,'Date of uploaded-file reconciliation.')
    if r['Topic']=='DB12 CEC user-file comparison':
        setv('AUDIT_README',n,'Topic','CEC uploaded-file comparison','Keep the current comparison result visible.')
        setv('AUDIT_README',n,'Details',summary+' The two PCS source-file mappings in CEC_FILE_RECONCILIATION are corrected. '+boundary,'Replace the former pending-upload statement with the actual result and remaining coverage.')
for n,r in records['REQUEST_AUDIT'].items():
    if r['Request']=='Recheck suspect records and compare user-downloaded CEC files':
        for h,v in {'Disposition':'USER_FILE_COMPARISON_COMPLETE_FOR_10_UPLOADED_FILES','Work Completed':summary,'Evidence':'CEC_FILE_RECONCILIATION; DB13_CEC_Upload_Comparison_2026-10-26.md; field comparison evidence.','Remaining Boundary':boundary}.items():setv('REQUEST_AUDIT',n,h,v,'Close the received-file comparison while retaining source-authentication boundaries.')
append('REQUEST_AUDIT',{'Request':'Compare uploaded CEC lists with current database; add only missing equipment in its category.','Disposition':'COMPLETE_ZERO_MISSING_LISTINGS_ZERO_EQUIPMENT_ADDED','Work Completed':summary,'Evidence':'CEC_FILE_RECONCILIATION; DB13 uploaded-file comparison and original file hashes.','Remaining Boundary':f"Source-list coverage is confirmed for the supplied files. {len(C['existing_withheld_links'])} existing ambiguous manufacturer/variant links retain their explicit review dispositions; existing candidate IDs were checked."},'Record the current user request and result.')
append('CHANGE_LOG',{'Change':'DB13-UPLOADED-CEC-COMPARISON','Sheet':'CEC_FILE_RECONCILIATION / AUDIT_README / REQUEST_AUDIT','Cell / Range':'Uploaded-file comparison metadata','Before':'User-supplied file comparison pending.','After / Formula':summary,'Reason':'Complete user-file reconciliation without adding equipment already represented in the database.','Evidence ID':'DB13-CEC-UPLOADS','Review Date':DATE},'Document the completed source-file comparison.')
append('CHANGE_LOG',{'Change':'DB13-PCS-SOURCE-MAPPING','Sheet':'CEC_FILE_RECONCILIATION','Cell / Range':'PowerControlSystem.xlsx and CurrentPCS.xlsx source rows','Before':'The two source-file category/count/field mappings were swapped in this audit ledger.','After / Formula':'PowerControlSystem.xlsx maps to CEC_LEGACY_PCS (1,715 rows, 23 fields). CurrentPCS.xlsx maps to CEC_POWER_CONTROL (103 rows, 20 fields).','Reason':'Use actual source dataset/worksheet identities. Equipment and raw CEC tables were already categorized correctly and are unchanged.','Evidence ID':'DB13-CEC-SOURCE-MAP','Review Date':DATE},'Correct the source-file audit mapping without moving equipment.')
for s in names:counts[s]=len(records[s])
for n,r in records['SHEET_MAP'].items():
    if r.get('Sheet') in counts:setv('SHEET_MAP',n,'Data rows (2026-10-25)',counts[r['Sheet']],'Reconcile actual final audit row count.')
for n,r in records['DATABASE_TABLE_INDEX'].items():
    s=r.get('Database Sheet')
    if s in names:
        setv('DATABASE_TABLE_INDEX',n,'Database Records',counts[s],'Reconcile the native-table index.')
        setv('DATABASE_TABLE_INDEX',n,'Full Table Range','A1:'+R.col(len(headers[s]))+str(counts[s]+1),'Extend the range only for appended audit rows.')
for n,r in records['AUDIT_README'].items():
    if r['Topic']=='Coverage':setv('AUDIT_README',n,'Details',f'Current master: 117 worksheets, 116 native tables and {sum(counts.values()):,} nonempty data/audit/reference rows. These are not unique equipment counts. This update adds no equipment records.','Reconcile current coverage after audit-only additions.')
for n,r in records['FIELD_AUDIT'].items():
    s,h=r.get('Sheet'),r.get('Field')
    if s not in names or h not in headers[s] or s not in changes:continue
    vals=[v.get(h) for v in records[s].values()];pop=[v for v in vals if v is not None and v!='']
    stats={'Records':len(vals),'Populated':len(pop),'Blank':len(vals)-len(pop),'Completeness':len(pop)/len(vals) if vals else 0,'Numeric':sum(isinstance(v,(int,float)) and not isinstance(v,bool) for v in pop),'Numeric Text':sum(isinstance(v,str) and bool(re.fullmatch(r'[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?',v.strip())) for v in pop),'Zeros':sum(isinstance(v,(int,float)) and not isinstance(v,bool) and v==0 for v in pop)}
    for hh,v in stats.items():setv('FIELD_AUDIT',n,hh,v,'Refresh diagnostics for the updated request ledger.')

meta={}
with zipfile.ZipFile(SRC) as z:
    for s in names:
        path=book.sheets[s];rp=posixpath.dirname(path)+'/_rels/'+posixpath.basename(path)+'.rels'
        rels=E.fromstring(z.read(rp));target=next(r.get('Target') for r in rels if r.get('Type','').endswith('/table'))
        tp=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.dirname(path)+'/'+target);t=E.fromstring(z.read(tp))
        xml=z.read(path).decode();assert not re.search(r'<(?:[\w.-]+:)?f\b',xml)
        widths={i:8.43 for i in range(1,len(headers[s])+1)}
        for cm in re.finditer(r'<(?:[\w.-]+:)?col\b[^>]*/>',xml[:65536]):
            at=dict(re.findall(r'([\w:.-]+)="([^"]*)"',cm[0]))
            for i in range(int(at['min']),int(at['max'])+1):
                if i in widths:widths[i]=float(at.get('width','8.43'))
        for nr in {int(re.search(r'\d+$',a)[0]) for a in changes[s]}:
            if nr==1:continue
            row=records[s][nr];lines=max(sum(max(1,math.ceil(len(part)/max(6,widths[i+1]-2))) for part in str(row.get(h) or '').split('\n')) for i,h in enumerate(headers[s]))
            rowheights[s][str(nr)]=min(409,max(32,(lines+2)*15+8))
        meta[s]={'path':path,'table_path':tp,'table_name':t.get('name'),'table_id':t.get('id'),'old_ref':t.get('ref'),'new_ref':'A1:'+R.col(len(headers[s]))+str(counts[s]+1),'old_last_row':prior['counts'][s]+1,'new_last_row':counts[s]+1,'headers':headers[s],'cells':changes[s],'row_heights':rowheights[s]}
old='Data rows (2026-10-25)';new='Data rows (2026-10-26)'
changes['SHEET_MAP']['B1']=new;proof['SHEET_MAP!B1']={'before':old,'reason':'Current audit row-count date.'}
meta['SHEET_MAP']['headers'][1]=new;meta['SHEET_MAP']['table_header_renames']={old:new}
result={'parent':str(SRC),'parent_sha256':C['master_sha256'],'parent_library_version':12,'review_date':DATE,'sheets':{s:o for s,o in meta.items() if o['cells']},'counts':counts,'total_rows':sum(counts.values()),'equipment_added':0,'files_checked':10,'unique_contents':9,'matched_listing_memberships':32295,'proof_files':{'comparison.json':hashlib.sha256((P/'comparison.json').read_bytes()).hexdigest()},'uploaded_files':[{k:f[k] for k in ['filename','path','sha256']} for f in C['files']]}
(P/'manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(P/'change_evidence.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2));book.close()
print(json.dumps({'status':'PREPARED','sheets':len(result['sheets']),'cells':sum(len(o['cells']) for o in result['sheets'].values()),'equipment_added':0,'total_rows':result['total_rows']}))
