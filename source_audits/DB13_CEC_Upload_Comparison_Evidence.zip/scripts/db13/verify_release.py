"""Independently verify the audit-only edit and preservation of all equipment."""
from pathlib import Path
from collections import Counter
from copy import deepcopy
import hashlib,importlib.util,json,posixpath,re,zipfile
from lxml import etree as E
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('reader',P.parent/'db11/reviews/storage/verify_release_storage.py')
R=importlib.util.module_from_spec(spec);spec.loader.exec_module(R)
M=json.loads((P/'manifest.json').read_text());A=json.loads((P/'assembly_result.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(M['parent'])==M['parent_sha256'] and sha(A['output'])==A['sha256'] and sha(P/'manifest.json')==A['manifest_sha256']
C=R.Checks();test=C.test
rowrx=re.compile(r'<(?P<q>(?:[\w.-]+:)?row)\b[^>]*?(?:\s*/>|>.*?</(?P=q)>)',re.S)
cellrx=re.compile(r'<(?P<q>(?:[\w.-]+:)?c)\b[^>]*?(?:\s*/>|>.*?</(?P=q)>)',re.S)
def attrs(s):return dict(re.findall(r'([\w:.-]+)="([^"]*)"',s.split('>',1)[0]))
def cells(raw):return {attrs(m[0])['r']:m[0] for m in cellrx.finditer(raw)}
def outer(raw):
    raw=re.sub(r'<(?P<q>(?:[\w.-]+:)?sheetData)\b[^>]*>.*?</(?P=q)>','DATA',raw,flags=re.S)
    return re.sub(r'<(?:[\w.-]+:)?dimension\b[^>]*/>','DIMENSION',raw)
unchanged_parts=unplanned_cells=formulas=0
with zipfile.ZipFile(M['parent']) as old,zipfile.ZipFile(A['output']) as new:
    test(old.testzip() is None and new.testzip() is None,'ZIP_CRC')
    test(old.namelist()==new.namelist(),'NO_NEW_OR_REMOVED_PACKAGE_PARTS')
    allowed={o['path'] for o in M['sheets'].values()}|{o['table_path'] for o in M['sheets'].values()}
    for part in old.namelist():
        a,b=old.read(part),new.read(part)
        if a==b:unchanged_parts+=1
        test(a==b or part in allowed,'NO_UNPLANNED_PACKAGE_CHANGE',part)
    for sh,o in M['sheets'].items():
        before=old.read(o['path']).decode();after=new.read(o['path']).decode();a=cells(before);b=cells(after)
        for address,value in a.items():
            if address not in o['cells']:test(value==b.get(address),'UNPLANNED_CELL_XML_PRESERVED',(sh,address));unplanned_cells+=1
            else:test(attrs(value).get('s','0')==attrs(b.get(address,'')).get('s','0'),'EXISTING_CELL_STYLE_PRESERVED',(sh,address))
        test(not (set(b)-set(a)-set(o['cells'])),'NO_UNPLANNED_ADDED_CELLS',sh)
        test(outer(before)==outer(after),'WORKSHEET_FEATURES_PRESERVED',sh)
        ar={int(attrs(r[0])['r']):attrs(r[0]) for r in rowrx.finditer(before)};br={int(attrs(r[0])['r']):attrs(r[0]) for r in rowrx.finditer(after)}
        for nr,at in ar.items():
            expected=dict(at)
            if str(nr) in o['row_heights']:expected.update(ht=str(o['row_heights'][str(nr)]),customHeight='1')
            test(expected==br.get(nr),'ROW_ATTRIBUTES_PRESERVED',(sh,nr))
        t=E.fromstring(old.read(o['table_path']));u=E.fromstring(new.read(o['table_path']));t.set('ref',o['new_ref'])
        for f in t.findall('s:autoFilter',R.N):f.set('ref',o['new_ref'])
        for c in t.findall('s:tableColumns/s:tableColumn',R.N):
            if c.get('name') in o.get('table_header_renames',{}):c.set('name',o['table_header_renames'][c.get('name')])
        test(E.tostring(t)==E.tostring(u),'NATIVE_TABLE_IDENTITY_AND_FEATURES',sh)
    prior=json.loads((P/'prior_evidence/evidence/manifest.json').read_text())
    for part,count in prior['formula_dependency_scan']['formula_counts'].items():
        test(old.read(part)==new.read(part),'FORMULAS_AND_CACHES_BYTE_IDENTICAL',part)
        actual=len(E.fromstring(new.read(part)).findall('.//s:c/s:f',R.N));formulas+=actual
        test(actual==count,'ORIGINAL_FORMULA_COUNT',part)
    test(formulas==53117,'ALL_ORIGINAL_FORMULAS_PRESERVED')

book=R.Book(A['output']);base=R.Book(M['parent']);changed_records={};headers={};actual_counts=deepcopy(M['counts']);error_cells=0
for sh,o in M['sheets'].items():
    header=list(next(book.rows(sh))[1].values());headers[sh]=header;rows=[(nr,r) for nr,r,_ in book.table(sh)];changed_records[sh]=rows
    test(len(rows)==M['counts'][sh],'CHANGED_SHEET_ROW_COUNT',sh)
    actual={cc+str(nr):v for nr,cs,_ in book.rows(sh) for cc,v in cs.items()}
    for address,value in o['cells'].items():test(R.eq(actual.get(address),value),'ARTIFACT_AUTHORED_TYPED_VALUE',(sh,address))
    with book.z.open(o['path']) as f:
        for _,c in E.iterparse(f,events=['end'],tag='{'+R.NS+'}c'):
            if c.get('t')=='e':error_cells+=1
            test(c.find('s:f',R.N) is None,'AUDIT_VALUES_NOT_EXECUTABLE_FORMULAS',(sh,c.get('r')))
            c.clear()
            while c.getprevious() is not None:del c.getparent()[0]
test(error_cells==0,'NO_NEW_EXCEL_ERROR_CELLS')
sm={r['Sheet']:r for _,r in changed_records['SHEET_MAP']};idx={r['Database Sheet']:r for _,r in changed_records['DATABASE_TABLE_INDEX']}
test(len(book.sheets)==len(sm)==117 and len(idx)==116,'SHEET_AND_TABLE_INDEX_COVERAGE')
for sh,n in M['counts'].items():test(sm[sh]['Data rows (2026-10-26)']==n,'SHEET_MAP_COUNTS',sh)
table_ids=[];table_names=[]
for sh,part in book.sheets.items():
    rp=posixpath.dirname(part)+'/_rels/'+posixpath.basename(part)+'.rels'
    if rp not in book.z.namelist():continue
    for rel in E.fromstring(book.z.read(rp)):
        if not rel.get('Type','').endswith('/table'):continue
        target=rel.get('Target');tp=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.dirname(part)+'/'+target)
        t=E.fromstring(book.z.read(tp));table_ids.append(t.get('id'));table_names.append(t.get('name'))
        cols=[c.get('name') for c in t.findall('s:tableColumns/s:tableColumn',R.N)]
        expected=headers.get(sh) or list(next(book.rows(sh))[1].values())
        test(cols==expected,'TABLE_HEADERS_MATCH_WORKSHEET',sh)
        ref='A1:'+R.col(len(cols))+str(M['counts'][sh]+1)
        test(t.get('ref')==ref,'TABLE_FULL_RANGE',sh)
        test(idx[sh]['Structured Table Name']==t.get('name') and idx[sh]['Full Table Range']==ref and idx[sh]['Database Records']==M['counts'][sh],'TABLE_INDEX_COUNTS_AND_RANGES',sh)
test(len(table_ids)==len(set(table_ids))==len(set(table_names))==116,'UNIQUE_NATIVE_TABLE_IDENTITIES')
test(sum(actual_counts.values())==411285==M['total_rows'],'TOTAL_DATA_AUDIT_REFERENCE_ROWS')
ledger={r['Original CEC Filename']:r for _,r in changed_records['CEC_FILE_RECONCILIATION']}
test(ledger['PowerControlSystem.xlsx']['Native Master Tables']=='CEC_LEGACY_PCS' and ledger['PowerControlSystem.xlsx']['Imported Listing Rows']==1715 and ledger['PowerControlSystem.xlsx']['Native Fields']==23,'LEGACY_PCS_SOURCE_MAPPING_CORRECT')
test(ledger['CurrentPCS.xlsx']['Native Master Tables']=='CEC_POWER_CONTROL' and ledger['CurrentPCS.xlsx']['Imported Listing Rows']==103 and ledger['CurrentPCS.xlsx']['Native Fields']==20,'CURRENT_PCS_SOURCE_MAPPING_CORRECT')
initial=json.loads((P/'comparison.json').read_text());by_original={}
for item in initial['files']:by_original.setdefault(item['original_filename'],[]).append(item)
for filename,items in by_original.items():
    row=ledger[filename];test(row['User Supplied Filename']=='\n'.join(x['filename'] for x in items) and row['User File SHA256']==items[0]['sha256'] and row['User File Comparison Status'].startswith('MATCH_ALL_NATIVE_VALUES'),'UPLOADED_FILE_NAMES_HASHES_AND_MATCH_STATUS',filename)
test(len(by_original)==9,'NINE_SOURCE_FILES_MATCHED')
for f in M['uploaded_files']:test(sha(f['path'])==f['sha256'],'UPLOADED_FILE_UNMODIFIED',f['filename'])
post=json.loads((P/'final_comparison.json').read_text())
test(post['status']=='PASS' and post['failed_executions']==0 and post['master_sha256']==A['sha256'] and not post['source_ledger_repairs'] and post['matched_registry_ids']==32295 and not post['new_equipment_rows'] and not post['changed_source_rows'],'FINAL_FILE_RECOMPARES_TO_ALL_UPLOADS')
test(post['existing_withheld_links']==initial['existing_withheld_links'],'EXISTING_IDENTITY_REVIEW_DISPOSITIONS_PRESERVED')
latest_request=changed_records['REQUEST_AUDIT'][-1][1]
test(f"{len(post['existing_withheld_links'])} existing ambiguous manufacturer/variant links" in latest_request['Remaining Boundary'],'REVIEW_BOUNDARY_COUNTS_UNIQUE_LISTINGS_NOT_DUPLICATE_UPLOADS')
test(sha(A['output'])==A['sha256'] and sha(M['parent'])==M['parent_sha256'],'FINAL_AND_PARENT_HASHES_STABLE')
book.close();base.close()
result={'status':'PASS' if not C.failures else 'FAIL','master_sha256':A['sha256'],'parent_sha256':M['parent_sha256'],'equipment_added':0,'equipment_and_raw_source_parts':'BYTE_IDENTICAL_TO_VERSION_12','worksheets':117,'native_tables':116,'total_data_audit_reference_rows':411285,'formulas_preserved':53117,'source_lists_compared':32295,'unique_uploaded_file_contents':9,'files_received':10,'duplicate_uploads_ignored':1,'native_field_comparisons_unique_inputs':845792,'existing_ambiguous_links_retained':len(post['existing_withheld_links']),'unplanned_cells_xml_preserved':unplanned_cells,'unchanged_package_parts':unchanged_parts,**C.output()}
(P/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False),flush=True)
assert result['status']=='PASS',result['failure_examples']
