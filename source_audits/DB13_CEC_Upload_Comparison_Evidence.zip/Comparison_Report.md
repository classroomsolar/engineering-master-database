# CEC uploaded-file comparison — 26 October 2026

All 10 uploaded files have been checked against the current master. Their 9 unique file contents contain 32,295 listing memberships across 10 native CEC tables. Every supplied listing and native field value is already present. **No equipment records were added or changed.**

| Uploaded file | Listing rows in file | Existing category | Result |
| --- | ---: | --- | --- |
| [Batteries_Archive_ADA.xlsx](https://chatgpt.com/library?file_id=libfile_5022f4d7c17481919b93ac9014c3ba72&account_id=personal) | 16 | CEC_BATTERY_ARCHIVE | All listing fields already present; no addition |
| [Battery_List_Data_ADA.xlsx](https://chatgpt.com/library?file_id=libfile_f6d074c308cc8191b103ede8e59d5301&account_id=personal) | 999 | CEC_BATTERIES | All listing fields already present; no addition |
| [Energy_Storage_System_List_Data_ADA.xlsx](https://chatgpt.com/library?file_id=libfile_b36b015a4e088191814acb6be24335f2&account_id=personal) | 6,787 | CEC_ENERGY_STORAGE | All listing fields already present; no addition |
| [Grid_Support_Inverter_List_Full_Data_ADA (1).xlsm](https://chatgpt.com/library?file_id=libfile_02056cdcfd3481918609b1f7a7bce897&account_id=personal) | 3,379 | CEC_SOLAR_INVERTERS, CEC_BATTERY_INVERTERS | All listing fields already present; no addition |
| [Grid_Support_Inverter_List_Full_Data_ADA (2).xlsm](https://chatgpt.com/library?file_id=libfile_e2f5b34681a8819192cac8188016eadf&account_id=personal) | 3,379 | CEC_SOLAR_INVERTERS, CEC_BATTERY_INVERTERS | Duplicate copy of Grid Support (1); no additional import |
| [Inverter_and_Energy_Storage_System_PCS_List_ADA.xlsx](https://chatgpt.com/library?file_id=libfile_e1ad0aea1fec81919e59abe68c006d4f&account_id=personal) | 1,715 | CEC_LEGACY_PCS | All listing fields already present; no addition |
| [Meter_List_Data_ADA.xlsx](https://chatgpt.com/library?file_id=libfile_4819a0b11fb48191b10fd4ed3c40d618&account_id=personal) | 802 | CEC_METERS | All listing fields already present; no addition |
| [PV_Module-Archive_ADA.xlsx](https://chatgpt.com/library?file_id=libfile_adb349a51368819190a9903b26a57dec&account_id=personal) | 15,322 | CEC_PV_ARCHIVE | All listing fields already present; no addition |
| [Power_Control_System_List_ADA.xlsx](https://chatgpt.com/library?file_id=libfile_cd2be37e36b88191b968a442433b05d9&account_id=personal) | 103 | CEC_POWER_CONTROL | All listing fields already present; no addition |
| [Utility_Interactive_Inverter_List_Full_Data_ada.xlsm](https://chatgpt.com/library?file_id=libfile_1b44f92c33d881918a1bfc3fef904c78&account_id=personal) | 3,172 | CEC_INVERTER_ARCHIVE | All listing fields already present; no addition |

The Grid Support (1) and (2) files have the same SHA-256, so the second copy is not counted again. The 32,295 total excludes that duplicate upload. These are registry memberships, not a count of unique physical installations or equipment assemblies.

## What was checked

- 845,792 native field values across the 9 unique input contents, with all 313 native fields in the supplied categories covered. The second identical Grid Support file was also recognized and compared.
- Full listing coverage by native source rows, one-to-one matches to distinct existing registry IDs, and existing primary records or explicit candidate-ID review states.
- No missing listing rows and no changed listing values. The supplied listing headers also match the corresponding original exports.
- File names and hashes are recorded in CEC_FILE_RECONCILIATION. Data_Key, Dropdown and other reference worksheets were not imported as equipment.

Five unique input files are byte-identical to the original exports already used by the master. Four have different file hashes, while their listing headers and native equipment values still match. A different file hash alone was not treated as new equipment.

## Corrected source-file mapping

The earlier comparison ledger had two PCS source-file mappings swapped. The native equipment tables were already categorized correctly. The ledger now follows actual source dataset and worksheet identities:

| Original source file | Correct native category | Listing rows | Native fields |
| --- | --- | ---: | ---: |
| PowerControlSystem.xlsx | CEC_LEGACY_PCS | 1,715 | 23 |
| CurrentPCS.xlsx | CEC_POWER_CONTROL | 103 | 20 |

The uploaded Inverter_and_Energy_Storage_System_PCS_List_ADA file matches the legacy PCS source. The uploaded Power_Control_System_List_ADA file matches the current PCS source. No equipment records were moved or duplicated for this correction.

## Preserved review boundaries

496 matched registry listings already have explicit manufacturer/variant ambiguity dispositions. Their existing candidate IDs were verified and their review states preserved. Finding the listing in a source table does not resolve those physical-model identities. The existing electrical and manufacturer-publication qualifications also remain in place.

This batch did not include the active PV-module export, V2G export or PMRS export. It also did not include a separate simplified inverter archive; the full inverter archive was supplied and checked. Those distinctions are recorded in the existing file ledger. They do not represent missing entries found in the supplied files.

## Saved-master verification

The update changes comparison/audit metadata only: 85 authored cells and 3 appended audit rows. All equipment tables, raw CEC tables, listing links, model groups, source definitions and unrelated package members are byte-identical to the previous master. All 53,117 original formulas and their stored results are preserved.

The saved master was compared again against the uploads, and the independent preservation checks passed with zero failed checks. It retains 117 worksheets, 116 native tables, all 55,018 original CEC listings and 411,285 data/reference/audit rows. The last figure is not an equipment count.

Master SHA-256: `dcef1fb4a8b00edbfb5e420dc4e76e6f4a8975cd0599e2f3c7902c4ee44f9f52`  
Parent master SHA-256: `ee2903c751861b6f07d537d651fb7e60a22ee8496ac3d5f1748b5ab7a7202cb3`

The evidence ZIP contains the comparison results, input identities/hashes, exact audit changes, preservation results, render samples and the scripts used. Uploaded source files remain unchanged.
