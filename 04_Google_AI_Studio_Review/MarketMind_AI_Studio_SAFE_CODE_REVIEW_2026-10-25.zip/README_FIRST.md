# Privacy-minimised Google AI Studio review bundle

No private owner statements, original portfolio snapshot, personal market holdings, live credentials or actual current HTML UI are included. This is for second-opinion code, maths and architecture audits only, NOT a replacement for the full transferable website.

Read `AUDIT_PROMPT.md` and run/adapt supplied pure Python source and synthetic tests. No real trade execution. Compare formulas and report issues with line/file references, test case evidence and uncertainty.
